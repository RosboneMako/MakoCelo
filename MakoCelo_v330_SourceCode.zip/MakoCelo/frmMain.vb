﻿Public Class frmMain
  'R3.00 NEEDS
  'x NO IMAGE updated.
  'x Panel color updated.
  'x Y Scaling is off center upwards.
  'x Scaling Code needs new arrays to ignore pnlPlr labels.
  'x Default data to test the current setup.
  'x Adjust Text gradients to actual text height (not label height).
  '- Need to keep last match on when player restarts (goes blank). Check for empty players then put up old stats.
  'x Need to update LITE/DARK modes with new controls. 
  '- CFx3D needs changed to new vars?
  'x Pop still happens.
  'x Color background alpha lost on rank and Name when color changed.
  '- Last Test code needs looked at with new LOG_Scan code.

  Public Shared CDialogPick As Color

  Private bmpBuffer As Bitmap

  Private FLAG_Loading As Boolean    'R2.00 Flag that we are loading, so do not update.
  'Private FILE_LastLineUsed As Long
  Private ALPHA_Rank As String
  Private ALPHA_Name As String
  Private PATH_Game As String
  Private PATH_GamePath As String             'R2.00 Raw path for dialogs.
  Private PATH_BackgroundImage As String
  Private PATH_BackgroundImagePath As String  'R2.00 Raw path for dialogs.
  Private PATH_SaveStatsImage As String
  Private SCAN_Enabled As Boolean
  Private FONT_Rank As Font                   'R3.00 Added.
  Private FONT_Name As Font                   'R3.00 Added.
  Private FONT_Rank_Name As String
  Private FONT_Rank_Size As String
  Private FONT_Rank_Bold As String
  Private FONT_Rank_Italic As String
  Private FONT_Name_Name As String
  Private FONT_Name_Size As String
  Private FONT_Name_Bold As String
  Private FONT_Name_Italic As String
  Private COLOR_Background As Color
  Private COLOR_Back1 As Color           'R3.00 Future gradient on background. 
  Private COLOR_Back2 As Color           'R3.00 Future gradient on background. 
  Private COLOR_Back_Dir As Integer      'R3.00 Future gradient on background. 
  Private GUI_ColorMode As Integer            'R2.01 Color scheme number. 0-Lite,1-Dark
  Private PAGE_Size As String
  Private PAGE_LayoutY As String
  Private PAGE_LayoutX As String
  Private PAGE_Layout As String          'R2.00 Background image scaling.
  Private LAB_Width As Single            'R2.00 Height of labels.  
  Private LAB_Height As Single           'R2.00 Height of labels.
  Private LAB_Rank(0 To 8) As t_Box      'R2.00 Defs for current label layout. 
  Private LAB_Name(0 To 8) As t_Box
  Private LAB_Fact(0 To 8) As t_Box
  Private GUI_Mouse_PlrIndex As Integer  'R3.00 Which player we are moused over in the stats page.
  Private GUI_Active As Boolean          'R3.10 If TRUE, gui will redraw when mouse over events happen. May be too slow.
  Private PlrName(0 To 8) As String
  Private PlrRank(0 To 8) As String
  Private PlrFact(0 To 8) As String
  Private PlrSteam(0 To 8) As String
  Private PlrName_Last(0 To 8) As String
  Private PlrRank_Last(0 To 8) As String
  Private PlrFact_Last(0 To 8) As String
  Private PlrSteam_Last(0 To 8) As String
  Private CRankF1 As Color
  Private CRankF2 As Color
  Private CRankFDir As Integer
  Private CRankB1 As Color
  Private CRankB2 As Color
  Private CRankBDir As Integer
  Private CRank3D As String
  Private CRank3DC As Color
  Private CRank3Depth As String
  Private CNameF1 As Color
  Private CNameF2 As Color
  Private CNameFDir As Integer
  Private CNameB1 As Color
  Private CNameB2 As Color
  Private CNameBDir As Integer
  Private CName3D As String
  Private CName3DC As Color
  Private CName3Depth As String
  Private CFX3DActive(0 To 10) As Boolean
  Private CFX3DVar(0 To 10, 0 To 10) As String    'R3.10 1=Mode
  Private CFX3DC(0 To 10) As Color



  Private Sub cmCheckLog_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmCheckLog.Click

    Call LOG_Scan()
    Call GFX_DrawStats()

  End Sub

  Private Sub STATS_StoreLast()
    Dim t As Integer
    Dim Hit As Integer

    'R3.00 See if we have new valid data.
    For t = 1 To 8
      If PlrSteam(t) <> "" Then Hit = t : Exit For
    Next t

    'R3.000 We have new valid incoming data, so clear old data.
    If 0 < Hit Then
      For t = 1 To 8
        PlrRank_Last(t) = PlrRank(t)
        PlrName_Last(t) = PlrName(t)
        PlrSteam_Last(t) = PlrSteam(t)
        PlrFact_Last(t) = PlrFact(t)
      Next
    End If

  End Sub


  Private Sub LOG_Scan()
    Dim A, B As String
    Dim FindMatch As Boolean
    Dim FindPlayers As Boolean
    Dim MatchFound As Boolean
    Dim PlrCnt As Integer
    'Dim PlayerCount As Integer
    Dim LCnt As Long
    Dim test1 As Long
    Dim test2 As Long
    Dim tRank As Long
    Dim tPlrRank(0 To 9) As String     'R3.10 Added Storage to place old vals on screen if no new onesa are found.
    Dim tPlrName(0 To 9) As String
    Dim tPlrSteam(0 To 9) As String
    Dim tPlrFact(0 To 9) As String
    Dim MatchRID(0 To 9) As Long
    Dim GameRID(0 To 9) As Long

    'R3.20 Store the file time when these sections were found to verify they are close to each other in time.
    'Dim MatchTime As String = ""
    'Dim GameTime As String = ""

    lbError1.Text = ""
    lbError1.BackColor = Color.FromArgb(255, 192, 192, 192)
    lbError2.Text = ""
    lbError2.BackColor = Color.FromArgb(255, 192, 192, 192)

    'R1.00 If we dont have a valid log file path, exit with help notice.
    If Not (System.IO.File.Exists(PATH_Game)) Then
      MsgBox("Please locate the warnings.log file in your COH2 My Games directory." & vbCr & vbCr & "Click on FIND LOG FILE to search and select.", MsgBoxStyle.Information)
      Exit Sub
    End If

    'R3.00 Clear the Last Valid Match stats if necessary.
    Call STATS_StoreLast()

    'R3.10 Clear the current match and find new data below. 
    For t = 1 To 8
      tPlrRank(t) = PlrRank(t)
      tPlrName(t) = PlrName(t)
      tPlrSteam(t) = PlrSteam(t)
      tPlrFact(t) = PlrFact(t)
      PlrRank(t) = ""
      PlrName(t) = ""
      PlrSteam(t) = ""
      PlrFact(t) = ""
    Next

    lbStatus.Text = "Open file..." : Application.DoEvents()

    'R2.01 OPEN log file and start parsing.
    Dim fs = New IO.FileStream(PATH_Game, IO.FileMode.Open, IO.FileAccess.Read, IO.FileShare.ReadWrite)
    Dim sr = New IO.StreamReader(fs, System.Text.Encoding.UTF8)
    Using (sr)

      PlrCnt = 0
      LCnt = 0
      MatchFound = False
      FindMatch = False

      'R2.01 Loop thru the file looking for the match stats.
      While Not sr.EndOfStream
        A = sr.ReadLine()

        '**********************************************************************************
        'R3.20 If Match Started string is found, find all of the other match stats lines.
        '**********************************************************************************
        If InStr(A, "Match Started") Then
          FindMatch = True

          'R3.20 We have found a new section so clear the previous data.
          For t = 1 To 8
            PlrRank(t) = ""
            PlrSteam(t) = ""
            MatchRID(t) = 0
          Next

          'If MatchTime = "" Then MatchTime = Mid(A, 1, 8)
          'If (MatchTime <> "") And (GameTime <> "") Then
          ' If LOG_AreTimesInValid(MatchTime, GameTime) Then
          ' MsgBox("Invalid Data")
          ' End If
          'End if

          PlrCnt = 0
          While (Not sr.EndOfStream) And (FindMatch = True)
            PlrCnt += 1

            B = Trim(Mid(A, 98, 20))
            If (B = "-1") Or (B = "") Then    'R2.01 Added +1 to rank code. 
              B = "---"                       'R1.00 Show unranked as --       
            Else
              tRank = Val(B)
              B = CStr(tRank + 1)
            End If
            PlrRank(PlrCnt) = B

            'R3.20 Get SteamID. If valid, get RelicID also.
            PlrSteam(PlrCnt) = Mid(A, 57, 17)
            If Mid(PlrSteam(PlrCnt), 1, 4) <> "7656" Then
              PlrSteam(PlrCnt) = ""
              MatchRID(PlrCnt) = 0
            Else
              MatchRID(PlrCnt) = LOG_HexToLong(Mid(A, 41, 8))       'R3.20 <-- Convert.ToInt64(Mid(A, 41, 8), 16)
              If MatchRID(PlrCnt) = -1 Then MatchRID(PlrCnt) = 0
            End If

            'R3.20 Read the next line of the file and exit if all of the match lines have been found.
            A = sr.ReadLine()
            If InStr(A, "Match Started") = 0 Then FindMatch = False

          End While


        End If


        '**********************************************************************************
        '3.20 If we find a GAME Human Player string, find all of the other player stats.
        '**********************************************************************************
        If InStr(A, "GAME ") Then
          If (InStr(A, "Human Player")) Or (InStr(A, "AI Player")) Then
            FindPlayers = True

            'R3.20 We have found a new section so clear the previous data.
            For t = 1 To 8
              PlrName(t) = ""
              PlrFact(t) = ""
              GameRID(t) = 0
            Next

            PlrCnt = 0 : FindPlayers = True
            While (Not sr.EndOfStream) And (FindPlayers = True)
              PlrCnt += 1

              test1 = InStr(A, "Human Player")
              test2 = InStr(A, "AI Player")

              If test1 Then
                PlrName(PlrCnt) = LOG_FindPlayer(A, 39)   'R2.01 Names are not Delimited, need to search for end of name from the end of line.
                GameRID(PlrCnt) = LOG_Find_RelicID(A)     'R3.20 Get the RelicID for this player.  
              Else
                PlrName(PlrCnt) = LOG_FindPlayer(A, 36)   'R2.01 AI player.    
                GameRID(PlrCnt) = 0                       'R3.20 AI has no RelicID.
              End If

              If InStr(A, "german") Then PlrFact(PlrCnt) = "01"         'R3.00 "OST" 'R1.00 Must check first or you get OST for all german armies.
              If InStr(A, "west_german") Then PlrFact(PlrCnt) = "03"    'R3.00 "OKW"
              If InStr(A, "aef") Then PlrFact(PlrCnt) = "04"            'R3.00 "USF"
              If InStr(A, "soviet") Then PlrFact(PlrCnt) = "02"         'R3.00 "SOV"
              If InStr(A, "british") Then PlrFact(PlrCnt) = "05"        'R3.00 "BRT"


              'R3.20 Read the next line of the file.
              A = sr.ReadLine()
              test1 = InStr(A, "Human Player")
              test2 = InStr(A, "AI Player")
              If (test1 = 0) And (test2 = 0) Then FindPlayers = False

            End While

          End If
        End If

        'R3.20 We have found a SPECTATE line.
        If 0 < InStr(A, "WorldwideStartObservingAsync") Then
          '3.20 The next 25 or less lines should have the PLAYER stats.

          '3.20 Loop until we hit a player.
          While (InStr(A, "GAME -- Human Player") = 0)
            If (Not sr.EndOfStream) Then A = sr.ReadLine()
          End While

          '3.20 Loop until we hit a player.
          If (InStr(A, "GAME -- Human Player") <> 0) Then
            'R3.20 We have found a new section so clear the previous data.
            For t = 1 To 8
              PlrName(t) = ""
              PlrFact(t) = ""
              GameRID(t) = 0
            Next

            PlrCnt = 0 : FindPlayers = True
            While (Not sr.EndOfStream) And (FindPlayers = True)
              PlrCnt += 1

              test1 = InStr(A, "Human Player")
              test2 = InStr(A, "AI Player")

              If test1 Then
                PlrName(PlrCnt) = LOG_FindPlayer(A, 39)   'R2.01 Names are not Delimited, need to search for end of name from the end of line.
                GameRID(PlrCnt) = LOG_Find_RelicID(A)     'R3.20 Get the RelicID for this player.  
              Else
                PlrName(PlrCnt) = LOG_FindPlayer(A, 36)   'R2.01 AI player.    
                GameRID(PlrCnt) = 0                       'R3.20 AI has no RelicID.
              End If

              If InStr(A, "german") Then PlrFact(PlrCnt) = "01"         'R3.00 "OST" 'R1.00 Must check first or you get OST for all german armies.
              If InStr(A, "west_german") Then PlrFact(PlrCnt) = "03"    'R3.00 "OKW"
              If InStr(A, "aef") Then PlrFact(PlrCnt) = "04"            'R3.00 "USF"
              If InStr(A, "soviet") Then PlrFact(PlrCnt) = "02"         'R3.00 "SOV"
              If InStr(A, "british") Then PlrFact(PlrCnt) = "05"        'R3.00 "BRT"

              'R3.20 Read the next line of the file.
              A = sr.ReadLine()
              test1 = InStr(A, "Human Player")
              test2 = InStr(A, "AI Player")
              If (test1 = 0) And (test2 = 0) Then FindPlayers = False

            End While

            'R3.20 If SPECTATING We wont have match stats so pretend we do.
            For t = 1 To 8
              PlrSteam(t) = ""               'R3.20 We wont have Steam Stats.
              MatchRID(t) = GameRID(t)
              PlrRank(t) = "spec"
            Next
          End If
        End If

      End While

    End Using


    'R2.01 Close / Clean up  streams?
    sr.Close()
    sr.Dispose()
    fs.Close()
    fs.Dispose()

    'R3.20 Verify all of our data matches. Test against RelicID.
    Dim ValidData As Boolean = True
    For t = 1 To 8
      If (MatchRID(t) <> GameRID(t)) Then ValidData = False : Exit For
    Next

    'R3.20 The data is not valid, clear all data.
    If ValidData = False Then
      lbError1.Text = "Mismatched"
      lbError1.BackColor = Color.FromArgb(255, 255, 0, 0)
      lbError2.Text = "data error"
      lbError2.BackColor = Color.FromArgb(255, 255, 0, 0)
      For t = 1 To 8
        PlrName(t) = ""
        PlrRank(t) = "---"
        PlrSteam(t) = ""
        PlrFact(t) = ""
      Next
    End If

    'R3.10 See if any new vals were found.
    Dim NewCnt As Integer
    For t = 1 To 8
      If PlrRank(t) <> "" Then NewCnt += 1
      If PlrName(t) <> "" Then NewCnt += 1
      If PlrSteam(t) <> "" Then NewCnt += 1
      If PlrFact(t) <> "" Then NewCnt += 1
    Next t

    'R3.10 If no new data was found, show the old data.
    If NewCnt = 0 Then
      For t = 1 To 8
        PlrRank(t) = tPlrRank(t)
        PlrName(t) = tPlrName(t)
        PlrSteam(t) = tPlrSteam(t)
        PlrFact(t) = tPlrFact(t)
      Next
    End If


    'R1.00 Adjust RANKS.
    For t = 1 To 8
      If PlrRank(t) = "" Then PlrRank(t) = "---"
      If PlrName(t) = "" Then PlrRank(t) = ""
    Next t


    lbStatus.Text = "Render..." : Application.DoEvents()

    Call GFX_DrawStats()

    lbStatus.Text = "Ready" : Application.DoEvents()

  End Sub

  Private Function LOG_HexToLong(A As String) As Long
    Dim L As Long

    'R3.20 Convert a Hex String to a Long. If ERROR, set to ZERO.
    Try
      L = Convert.ToInt64(A, 16)
    Catch ex As Exception
      L = 0
    End Try

    LOG_HexToLong = L

  End Function


  Private Function LOG_AreTimesInValid(MatchTime As String, GameTime As String) As Boolean
    ''R3.20 Verify that the log file times where data was found are close to each other.
    Dim Hour1 As Long = 0
    Dim Hour2 As Long = 0
    Dim Min1 As Long = 0
    Dim Min2 As Long = 0
    Dim Tok As Boolean = False

    Hour1 = Val(Mid(MatchTime, 1, 2))
    Hour2 = Val(Mid(GameTime, 1, 2))
    Min1 = Val(Mid(MatchTime, 4, 2))
    Min2 = Val(Mid(GameTime, 4, 2))

    'R3.20 Did we cross midnight.
    If (Hour1 = 0) And (Hour2 = 23) Then Hour1 = 24
    If (Min1 = 0) And (Min2 = 59) Then Min1 = 60
    If (Hour2 = 0) And (Hour1 = 23) Then Hour2 = 24
    If (Min2 = 0) And (Min1 = 59) Then Min2 = 60

    If 2 < (Math.Abs(Hour1 - Hour2)) Then Tok = True
    If 2 < (Math.Abs(Min1 - Min2)) Then Tok = True

    LOG_AreTimesInValid = Tok

  End Function


  Private Function LOG_Find_RelicID(A As String) As Long
    Dim RID As Long = 0
    Dim C As String
    Dim T As Integer
    Dim Cnt As Integer
    Dim CharStart As Integer
    Dim CharEnd As Integer

    'R3.20 Get the RelicID number from the Player stats line.
    For T = Len(A) To 1 Step -1
      C = Mid(A, T, 1)
      If C = " " Then
        Cnt += 1

        If Cnt = 2 Then CharEnd = T

        If Cnt = 3 Then
          CharStart = T
          Exit For
        End If
      End If

    Next T

    If CharEnd Then RID = Val(Mid(A, CharStart, CharEnd - CharStart))

    LOG_Find_RelicID = RID

  End Function


  Private Function LOG_FindPlayer(A As String, CharStart As Integer) As String
    Dim C As String
    Dim T As Integer
    Dim Cnt As Integer
    Dim CharEnd As Integer

    For T = Len(A) To 1 Step -1
      C = Mid(A, T, 1)
      If C = " " Then Cnt = Cnt + 1
      If Cnt = 3 Then
        CharEnd = T
        Exit For
      End If
    Next T

    C = "None"
    If CharEnd Then C = Mid(A, CharStart, CharEnd - CharStart)

    LOG_FindPlayer = C

  End Function

  Private Function SETTINGS_Load_CheckVersion() As Boolean
    Dim tPath As String
    Dim FileOK As Boolean = False
    Dim A As String = ""

    tPath = Application.StartupPath() & "\MakoCelo_settings.dat"

    If Not (System.IO.File.Exists(tPath)) Then
      SETTINGS_Load_CheckVersion = FileOK
      Exit Function
    End If

    FileOpen(1, tPath, OpenMode.Input)

    Try

      Input(1, A)

      Select Case A
        Case "VERSION MC300"
          FileOK = True

        Case "VERSION MC400"
          FileOK = True

        Case Else
          A = "WARNING: The MakoCelo settings file seems to be from a previous version of code and will not be loaded." & vbCr & vbCr
          A = A & "This file will be updated automatically when making changes in the new version of the program."
          MsgBox(A, MsgBoxStyle.Information, "MakoCelo Startup Checks")

      End Select

    Catch ex As Exception
      MsgBox("ERROR: " & ex.Message & vbCr & vbCr & "Unable to read the saved settings." & vbCr & "The last known setup could not be loaded." & vbCr & vbCr & "If running a new version, this error may fix itself when a new setup is saved.", MsgBoxStyle.Critical, "MakoCelo - Setup Error")
    End Try

    FileClose(1)

    SETTINGS_Load_CheckVersion = FileOK

  End Function
  Private Sub SETTINGS_Load()
    Dim C As Color
    Dim tPath As String
    Dim A As String = ""
    Dim Ca, Cr, Cg, Cb As Integer
    Dim tFont_Type As Integer
    Dim Frev As Integer

    tPath = Application.StartupPath() & "\MakoCelo_settings.dat"

    If Not (System.IO.File.Exists(tPath)) Then Exit Sub

    Frev = 0
    FileOpen(1, tPath, OpenMode.Input)

    Try

      Input(1, A)
      Select Case A
        Case "VERSION MC200"
          Frev = 2
          Input(1, A)            'R2.00 Read extra header line.
        Case "VERSION MC300"
          Frev = 3
          Input(1, A)            'R2.00 Read extra header line.
        Case "VERSION MC400"
          Frev = 4
          Input(1, A)            'R2.00 Read extra header line.
      End Select

      Input(1, Ca)
      Input(1, Cr)
      Input(1, Cg)
      Input(1, Cb)
      C = Color.FromArgb(Ca, Cr, Cg, Cb)
      'COLOR_SetRankFore(C)  
      'COLOR_SetNameFore(C)  

      Input(1, A)    'R1.00 BACK COLOR
      Input(1, Ca)
      Input(1, Cr)
      Input(1, Cg)
      Input(1, Cb)
      C = Color.FromArgb(Ca, Cr, Cg, Cb)
      'COLOR_SetFactBack(C)  
      'COLOR_SetRankBack(C)
      'COLOR_SetNameBack(C)    

      Input(1, A)    'R1.00 ALPHA
      Input(1, A)
      ALPHA_Rank = Trim(A)

      Input(1, A)    'R1.00 BACK IMAGE 
      Input(1, A)
      If (System.IO.File.Exists(A)) Then
        bmpBuffer = New Bitmap(A)          'R3.00 Switched to memory based image management.
        PATH_BackgroundImage = A           'R3.00 Removed pnlPlr.BackgroundImage = Image.FromFile(A)
      Else
        'R3.30 Added notice if image is missing.
        If A <> "" Then MsgBox("ERROR: The User Settings background image no longer exists." & vbCr & vbCr & "File:" & A)
      End If

      Input(1, A)    'R1.00 GAME PATH
      Input(1, A)
      PATH_Game = Trim(A)
      lbPath.Text = PATH_Game

      Input(1, A)    'R1.00 FONT
      Input(1, A) : FONT_Rank_Name = Trim(A)
      Input(1, A) : FONT_Rank_Size = Trim(A)
      Input(1, A) : FONT_Rank_Bold = Trim(A)
      Input(1, A) : FONT_Rank_Italic = Trim(A)

      tFont_Type = 0
      If FONT_Rank_Bold = "True" Then tFont_Type = 1
      If FONT_Rank_Italic = "True" Then tFont_Type = 2

      FONT_Rank = New Font(FONT_Rank_Name, CSng(FONT_Rank_Size), FontStyle.Regular)
      If FONT_Rank_Bold = "True" Then FONT_Rank = New Font(FONT_Rank_Name, CSng(FONT_Rank_Size), FontStyle.Bold)
      If FONT_Rank_Italic = "True" Then FONT_Rank = New Font(FONT_Rank_Name, CSng(FONT_Rank_Size), FontStyle.Italic)

      'R3.10 Version 2.0 and above.
      If 0 < Frev Then
        Input(1, A)    'R1.00 FORE COLOR - DEPRECATED
        Input(1, Ca)
        Input(1, Cr)
        Input(1, Cg)
        Input(1, Cb)
        'R3.30 C = Color.FromArgb(Ca, Cr, Cg, Cb)

        Input(1, A)    'R1.00 BACK COLOR - DEPRECATED
        Input(1, Ca)
        Input(1, Cr)
        Input(1, Cg)
        Input(1, Cb)
        'R3.30 C = Color.FromArgb(Ca, Cr, Cg, Cb)

        Input(1, A)    'R1.00 ALPHA - DEPRECATED
        Input(1, A)
        'R3.30 ALPHA_Name = Trim(A)

        Input(1, A)    'R1.00 FONT
        Input(1, A) : FONT_Name_Name = Trim(A)
        Input(1, A) : FONT_Name_Size = Trim(A)
        Input(1, A) : FONT_Name_Bold = Trim(A)
        Input(1, A) : FONT_Name_Italic = Trim(A)

        tFont_Type = 0
        If FONT_Name_Bold = "True" Then tFont_Type = 1
        If FONT_Name_Italic = "True" Then tFont_Type = 2

        FONT_Name = New Font(FONT_Name_Name, CSng(FONT_Name_Size), FontStyle.Regular)
        If FONT_Name_Bold = "True" Then FONT_Name = New Font(FONT_Name_Name, CSng(FONT_Name_Size), FontStyle.Bold)
        If FONT_Name_Italic = "True" Then FONT_Name = New Font(FONT_Name_Name, CSng(FONT_Name_Size), FontStyle.Italic)

        Input(1, A) 'R2.00 SCREEN SIZE
        Input(1, A) : cboPageSize.Text = Trim(A)

        Input(1, A) 'R2.00 PAGE LAYOUT Y
        Input(1, A) : cboLayoutY.Text = Trim(A)

        Input(1, A) 'R2.00 PAGE LAYOUT X
        Input(1, A) : cboLayoutX.Text = Trim(A)

        Input(1, A)  'R2.00 PANEL BACK COLOR
        Input(1, Ca)
        Input(1, Cr)
        Input(1, Cg)
        Input(1, Cb)
        COLOR_Background = Color.FromArgb(Ca, Cr, Cg, Cb)

        Input(1, A) 'R2.00 IMAGE SCALING
        Input(1, A) : cboScaling.Text = Trim(A)

        If Not EOF(1) Then
          Input(1, A) 'R2.00 GUI COLOR SCHEME
          Input(1, A) : GUI_ColorMode = Val(Trim(A))
        Else
          GUI_ColorMode = 0
        End If

        'R3.00 Rev 3 and above.
        If 2 < Frev Then
          'R3.00 RANK LABEL VARS
          Input(1, A)      'R3.00 RANK FORE COLOR 1 
          Input(1, Ca)
          Input(1, Cr)
          Input(1, Cg)
          Input(1, Cb)
          CRankF1 = Color.FromArgb(Ca, Cr, Cg, Cb)

          Input(1, A)      'R3.00 RANK FORE COLOR 2 
          Input(1, Ca)
          Input(1, Cr)
          Input(1, Cg)
          Input(1, Cb)
          CRankF2 = Color.FromArgb(Ca, Cr, Cg, Cb)

          Input(1, A)      'R3.00 RANK FORE GRADIENT 
          Input(1, A)
          CRankFDir = A

          Input(1, A)      'R3.00 RANK BACK COLOR 1 
          Input(1, Ca)
          Input(1, Cr)
          Input(1, Cg)
          Input(1, Cb)
          CRankB1 = Color.FromArgb(Ca, Cr, Cg, Cb)

          Input(1, A)      'R3.00 RANK BACK COLOR 2 
          Input(1, Ca)
          Input(1, Cr)
          Input(1, Cg)
          Input(1, Cb)
          CRankB2 = Color.FromArgb(Ca, Cr, Cg, Cb)

          Input(1, A)      'R3.00 RANK BACK GRADIENT 
          Input(1, A)
          CRankBDir = A

          'R3.00 NAME LABEL VARS
          Input(1, A)      'R3.00 NAME FORE COLOR 1 
          Input(1, Ca)
          Input(1, Cr)
          Input(1, Cg)
          Input(1, Cb)
          CNameF1 = Color.FromArgb(Ca, Cr, Cg, Cb)

          Input(1, A)      'R3.00 NAME FORE COLOR 2 
          Input(1, Ca)
          Input(1, Cr)
          Input(1, Cg)
          Input(1, Cb)
          CNameF2 = Color.FromArgb(Ca, Cr, Cg, Cb)

          Input(1, A)      'R3.00 NAME FORE GRADIENT 
          Input(1, A)
          CNameFDir = A

          Input(1, A)      'R3.00 NAME BACK COLOR 1 
          Input(1, Ca)
          Input(1, Cr)
          Input(1, Cg)
          Input(1, Cb)
          CNameB1 = Color.FromArgb(Ca, Cr, Cg, Cb)

          Input(1, A)      'R3.00 NAME BACK COLOR 2 
          Input(1, Ca)
          Input(1, Cr)
          Input(1, Cg)
          Input(1, Cb)
          CNameB2 = Color.FromArgb(Ca, Cr, Cg, Cb)

          Input(1, A)      'R3.00 NAME BACK GRADIENT 
          Input(1, A)
          CNameBDir = A


          Input(1, A)      'R3.00 RANK SHADOW COLOR 
          Input(1, Ca)
          Input(1, Cr)
          Input(1, Cg)
          Input(1, Cb)
          CRank3DC = Color.FromArgb(Ca, Cr, Cg, Cb)

          Input(1, A)      'R3.00 RANK SHADOW DIR
          Input(1, A)
          CRank3D = A
          cboRank3D.Text = A

          Input(1, A)      'R3.00 RANK SHADOW DEPTH - Future
          Input(1, A)
          CRank3Depth = A

          Input(1, A)      'R3.00 NAME SHADOW COLOR 
          Input(1, Ca)
          Input(1, Cr)
          Input(1, Cg)
          Input(1, Cb)
          CName3DC = Color.FromArgb(Ca, Cr, Cg, Cb)

          Input(1, A)      'R3.00 NAME SHADOW DIR
          Input(1, A)
          CName3D = A
          cboName3D.Text = A

          Input(1, A)      'R3.00 NAME SHADOW DEPTH - Future
          Input(1, A)
          CName3Depth = A

          Input(1, A)      'R3.00 BACK GRADIENT COLOR 1 - Future
          Input(1, Ca)
          Input(1, Cr)
          Input(1, Cg)
          Input(1, Cb)
          COLOR_Back1 = Color.FromArgb(Ca, Cr, Cg, Cb)

          Input(1, A)      'R3.00 BACK GRADIENT COLOR 2 - Future
          Input(1, Ca)
          Input(1, Cr)
          Input(1, Cg)
          Input(1, Cb)
          COLOR_Back2 = Color.FromArgb(Ca, Cr, Cg, Cb)

          Input(1, A)      'R3.00 NAME SHADOW DIR - Future
          Input(1, A)
          COLOR_Back_Dir = A

          'R3.00 Rev 4 and above.
          If 3 < Frev Then

            Input(1, A)      'R3.10 FX COLORS
            For t = 1 To 10
              Input(1, Ca)
              Input(1, Cr)
              Input(1, Cg)
              Input(1, Cb)
              CFX3DC(t) = Color.FromArgb(Ca, Cr, Cg, Cb)
            Next

            Input(1, A)      'R3.10 FX VARS
            For N = 1 To 10
              For t = 1 To 10
                Input(1, A) : CFX3DVar(N, t) = Trim(A)
              Next
            Next

            Input(1, A)      'R3.10 FX ACTIVE
            For N = 1 To 10
              Input(1, A)
              If A = "True" Then
                CFX3DActive(N) = True
              Else
                CFX3DActive(N) = False
              End If
            Next

          End If   '<-- REV 4 END

        End If   '<-- REV 3 END

      End If    '<-- REV 2 END

    Catch ex As Exception
      MsgBox("ERROR: " & ex.Message & vbCr & vbCr & "Unable to read the saved settings." & vbCr & "The last known setup could not be loaded." & vbCr & vbCr & "If running a new version, this error may fix itself when a new setup is saved.", MsgBoxStyle.Critical, "MakoCelo - Setup Error")
    End Try

    Call FX_SetVarControls()

    FileClose(1)


  End Sub

  Private Sub SETTINGS_Save()
    Dim C As Color
    Dim tPath As String

    If FLAG_Loading Then Exit Sub

    'R3.20 Should not be needed anymore. Call FX_GetVarStrings()

    tPath = Application.StartupPath()

    FileOpen(1, tPath & "\MakoCelo_settings.dat", OpenMode.Output)

    Try

      WriteLine(1, "VERSION MC400")

      C = CNameF1  'R3.30 lbRank01.ForeColor
      WriteLine(1, "RANK FORE COLOR")
      WriteLine(1, C.A)
      WriteLine(1, C.R)
      WriteLine(1, C.G)
      WriteLine(1, C.B)

      C = CNameB1 'R3.30  lbRank01.BackColor
      WriteLine(1, "RANK BACK COLOR")
      WriteLine(1, C.A)
      WriteLine(1, C.R)
      WriteLine(1, C.G)
      WriteLine(1, C.B)

      WriteLine(1, "RANK ALPHA %")
      WriteLine(1, cboRankA1.Text)

      WriteLine(1, "BACK IMAGE")
      WriteLine(1, PATH_BackgroundImage)

      WriteLine(1, "LOG PATH")
      WriteLine(1, PATH_Game)

      WriteLine(1, "RANK FONT")
      WriteLine(1, FONT_Rank_Name)
      WriteLine(1, FONT_Rank_Size)
      WriteLine(1, FONT_Rank_Bold)
      WriteLine(1, FONT_Rank_Italic)

      C = CNameF1  'R3.30 lbName01.ForeColor
      WriteLine(1, "NAME FORE COLOR") : WriteLine(1, C.A) : WriteLine(1, C.R) : WriteLine(1, C.G) : WriteLine(1, C.B)

      C = CNameB1  'R3.30 lbName01.BackColor
      WriteLine(1, "NAME BACK COLOR") : WriteLine(1, C.A) : WriteLine(1, C.R) : WriteLine(1, C.G) : WriteLine(1, C.B)

      WriteLine(1, "NAME ALPHA %")
      WriteLine(1, cboNameA1.Text)

      WriteLine(1, "NAME FONT")
      WriteLine(1, FONT_Name_Name)
      WriteLine(1, FONT_Name_Size)
      WriteLine(1, FONT_Name_Bold)
      WriteLine(1, FONT_Name_Italic)

      WriteLine(1, "SCREEN SIZE")
      WriteLine(1, cboPageSize.Text)

      WriteLine(1, "PAGE LAYOUT Y")
      WriteLine(1, cboLayoutY.Text)

      WriteLine(1, "PAGE LAYOUT X")
      WriteLine(1, cboLayoutX.Text)

      C = pbStats.BackColor   'R3.30 pnlPlrz.BackColor
      WriteLine(1, "PANEL BACK COLOR") : WriteLine(1, C.A) : WriteLine(1, C.R) : WriteLine(1, C.G) : WriteLine(1, C.B)

      WriteLine(1, "IMAGE SCALING")
      WriteLine(1, cboScaling.Text)

      WriteLine(1, "GUI COLOR")
      WriteLine(1, GUI_ColorMode)

      C = CRankF1 : WriteLine(1, "RANK FORE COLOR 1") : WriteLine(1, C.A) : WriteLine(1, C.R) : WriteLine(1, C.G) : WriteLine(1, C.B)

      C = CRankF2 : WriteLine(1, "RANK FORE COLOR 2") : WriteLine(1, C.A) : WriteLine(1, C.R) : WriteLine(1, C.G) : WriteLine(1, C.B)

      WriteLine(1, "RANK FORE GRADIENT DIR")
      WriteLine(1, CRankFDir)

      C = CRankB1 : WriteLine(1, "RANK BACK COLOR 1") : WriteLine(1, C.A) : WriteLine(1, C.R) : WriteLine(1, C.G) : WriteLine(1, C.B)
      C = CRankB2 : WriteLine(1, "RANK BACK COLOR 2") : WriteLine(1, C.A) : WriteLine(1, C.R) : WriteLine(1, C.G) : WriteLine(1, C.B)

      WriteLine(1, "RANK BACK GRADIENT DIR")
      WriteLine(1, CRankBDir)


      C = CNameF1 : WriteLine(1, "NAME FORE COLOR 1") : WriteLine(1, C.A) : WriteLine(1, C.R) : WriteLine(1, C.G) : WriteLine(1, C.B)
      C = CNameF2 : WriteLine(1, "NAME FORE COLOR 2") : WriteLine(1, C.A) : WriteLine(1, C.R) : WriteLine(1, C.G) : WriteLine(1, C.B)

      WriteLine(1, "NAME FORE GRADIENT DIR")
      WriteLine(1, CNameFDir)

      C = CNameB1 : WriteLine(1, "NAME BACK COLOR 1") : WriteLine(1, C.A) : WriteLine(1, C.R) : WriteLine(1, C.G) : WriteLine(1, C.B)
      C = CNameB2 : WriteLine(1, "NAME BACK COLOR 2") : WriteLine(1, C.A) : WriteLine(1, C.R) : WriteLine(1, C.G) : WriteLine(1, C.B)

      WriteLine(1, "NAME BACK GRADIENT DIR")
      WriteLine(1, CNameBDir)

      C = CRank3DC : WriteLine(1, "RANK SHADOW COLOR") : WriteLine(1, C.A) : WriteLine(1, C.R) : WriteLine(1, C.G) : WriteLine(1, C.B)

      WriteLine(1, "RANK SHADOW DIR")
      WriteLine(1, CRank3D)

      WriteLine(1, "RANK SHADOW DEPTH")
      If CRank3Depth = Nothing Then CRank3Depth = ""
      WriteLine(1, CRank3Depth)

      C = CName3DC : WriteLine(1, "NAME SHADOW COLOR") : WriteLine(1, C.A) : WriteLine(1, C.R) : WriteLine(1, C.G) : WriteLine(1, C.B)

      WriteLine(1, "NAME SHADOW DIR")
      WriteLine(1, CName3D)

      WriteLine(1, "NAME SHADOW DEPTH - Future")
      If CName3Depth = Nothing Then CName3Depth = ""
      WriteLine(1, CName3Depth)

      C = COLOR_Back1 : WriteLine(1, "BACK GRADIENT COLOR 1 - Future") : WriteLine(1, C.A) : WriteLine(1, C.R) : WriteLine(1, C.G) : WriteLine(1, C.B)
      C = COLOR_Back2 : WriteLine(1, "BACK GRADIENT COLOR 2 - Future") : WriteLine(1, C.A) : WriteLine(1, C.R) : WriteLine(1, C.G) : WriteLine(1, C.B)

      WriteLine(1, "BACK GRADIENT DIR - Future")
      WriteLine(1, COLOR_Back_Dir)

      WriteLine(1, "FX COLORS")
      For t = 1 To 10
        C = CFX3DC(t) : WriteLine(1, C.A) : WriteLine(1, C.R) : WriteLine(1, C.G) : WriteLine(1, C.B)
      Next t

      WriteLine(1, "FX VARS")
      For N = 1 To 10
        For t = 1 To 10
          If CFX3DVar(N, t) = Nothing Then CFX3DVar(N, t) = ""
          WriteLine(1, CFX3DVar(N, t))
        Next
      Next

      WriteLine(1, "FX ACTIVE")
      For N = 1 To 10
        If CFX3DActive(N) Then
          WriteLine(1, "True")
        Else
          WriteLine(1, "False")
        End If
      Next

      'R3.10 Write some extra lines to stop file open fails on future revs.
      For t = 1 To 100
        WriteLine(1, "")
      Next t

    Catch ex As Exception
      MsgBox("ERROR: " & ex.Message & vbCr & vbCr & "Unable to save the last known setup.", MsgBoxStyle.Critical, "MakoCelo - Setup Error")

    End Try

    FileClose(1)


  End Sub

  Private Sub cmFormColor_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmFormColor.Click

    ColorDialog1.ShowDialog()
    'pnlPlrz.BackColor = ColorDialog1.Color
    pbStats.BackColor = ColorDialog1.Color
    Call SETTINGS_Save()
    Call GFX_DrawStats()

  End Sub


  Private Sub cmFormImage_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmFormImage.Click
    Dim fd As OpenFileDialog = New OpenFileDialog()

    fd.Title = "Background Image Dialog"
    If PATH_BackgroundImagePath <> "" Then fd.InitialDirectory = PATH_BackgroundImagePath
    fd.Filter = "Png (*.png)|*.png|Gif (*.gif)|*.gif|Jpeg (*.jpg)|*.jpg"
    fd.FilterIndex = 3

    If fd.ShowDialog() = DialogResult.OK Then
      bmpBuffer = New Bitmap(fd.FileName)
      'R3.30 Deprecated  pnlPlr.BackgroundImage = bmpBuffer     'R3.00 Image.FromFile(fd.FileName)
      PATH_BackgroundImage = fd.FileName
      Call SETTINGS_Save()

      'R2.00 Strip the filename off for init dir on dialog.  
      Dim N As Integer
      N = STRING_FindLastSlash(PATH_BackgroundImage)
      If 3 < N Then
        PATH_BackgroundImagePath = Mid(PATH_BackgroundImage, 1, N)
      Else
        PATH_BackgroundImagePath = ""
      End If
    End If

    Call GFX_DrawStats()
  End Sub

  Private Function STRING_FindLastSlash(A As String)
    Dim i As Integer
    Dim Hit As Integer

    Hit = 0
    For i = Len(A) To 1 Step -1
      If Mid(A, i, 1) = "\" Then Hit = i : Exit For
    Next

    STRING_FindLastSlash = Hit

  End Function


  Private Sub frmMain_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    FLAG_Loading = True         'R2.00 Tell Controls not to update. Most save settings as they update,

    GUI_Active = False          'R3.10 Default to NO active GUI elements.
    PATH_Game = ""              'R2.00 Initialize the var or we get error 448 in file.
    PATH_BackgroundImage = ""

    'R3.00 Setup default Ranks and Names
    For t = 1 To 8
      PlrName(t) = "Player " & CStr(t)
      PlrRank(t) = "---"
      PlrFact(t) = "01"
    Next

    'R3.30 Fill in the Combo Box list items.
    Call INIT_FillComboBoxes()

    'R3.30 Setup default FONTs for Rank and Name labels.
    FONT_Rank_Name = "Arial"
    FONT_Rank_Size = "14"
    FONT_Rank_Bold = "True"
    FONT_Rank_Italic = "False"
    FONT_Rank = New Font(FONT_Rank_Name, CSng(FONT_Rank_Size), FontStyle.Bold)
    FONT_Name_Name = "Arial"
    FONT_Name_Size = "16"
    FONT_Name_Bold = "True"
    FONT_Name_Italic = "False"
    FONT_Name = New Font(FONT_Name_Name, CSng(FONT_Name_Size), FontStyle.Bold)

    'R3.30 Default label gradient color setups.
    CRankF1 = Color.FromArgb(255, 255, 255, 64)
    CRankF2 = Color.FromArgb(255, 192, 192, 48)
    CRankFDir = 0
    CRankB1 = Color.FromArgb(255, 64, 64, 64)
    CRankB2 = Color.FromArgb(25, 0, 0, 0)
    CRankBDir = 0
    CRank3DC = Color.FromArgb(255, 0, 0, 0)
    CNameF1 = Color.FromArgb(255, 255, 255, 255)
    CNameF2 = Color.FromArgb(255, 192, 192, 192)
    CNameFDir = 0
    CNameB1 = Color.FromArgb(255, 64, 64, 64)
    CNameB2 = Color.FromArgb(25, 0, 0, 0)
    CNameBDir = 1
    CName3DC = Color.FromArgb(255, 0, 0, 0)


    '***********************************************************************************************************
    'R3.00 Load the base USER settings. Do not load older files that Windows did not cleanup when uninstalled.
    '***********************************************************************************************************
    If SETTINGS_Load_CheckVersion() = True Then Call SETTINGS_Load()


    'R3.00 Set GUI color scheme.
    Select Case GUI_ColorMode
      Case 0 : Call GUI_SetLite()
      Case 1 : Call GUI_SetDark()
    End Select

    'R2.00 Try to set some defaults in case we cant read settings.
    cboRankA1.Text = ALPHA_CalcPercent(CRankB1.A)
    cboRankA2.Text = ALPHA_CalcPercent(CRankB2.A)
    cboNameA1.Text = ALPHA_CalcPercent(CNameB1.A)
    cboNameA2.Text = ALPHA_CalcPercent(CNameB2.A)
    If cboPageSize.Text = "" Then cboPageSize.Text = "3 - Normal 1050px"
    If cboLayoutY.Text = "" Then cboLayoutY.Text = "3 - 90% tight"
    If cboLayoutX.Text = "" Then cboLayoutX.Text = "3 - 90% tight"
    If cboRankA1.Text = "" Then cboRankA1.Text = "100%"
    If cboRankA2.Text = "" Then cboRankA2.Text = "100%"
    If cboNameA1.Text = "" Then cboNameA1.Text = "100%"
    If cboNameA2.Text = "" Then cboNameA2.Text = "100%"
    If cboScaling.Text = "" Then cboScaling.Text = "2 - Fit"
    If cboRank3D.Text = "" Then
      cboRank3D.Text = "270°"
      CRank3D = "270°"
    End If
    If cboName3D.Text = "" Then
      cboName3D.Text = "270°"
      CName3D = "270°"
    End If
    If cboFXVar2.Text = "" Then
      cboFXVar2.Text = "270°"
      'CFX3D = "270°"
    End If
    If cboFxVar3.Text = "" Then cboFxVar3.Text = "80%"
    If cboFxVar4.Text = "" Then cboFxVar4.Text = "2.0%"
    If cboFXVar1.Text = "" Then cboFXVar1.Text = "None"

    'R2.00 Strip the filename off for init dir on dialog.  
    Dim N As Integer = InStr(PATH_Game, "warnings")
    If 3 < N Then
      PATH_GamePath = Mid(PATH_Game, 1, N - 1)
    Else
      PATH_GamePath = ""
    End If

    'R2.00 Strip the filename off for init dir on dialog.  
    N = STRING_FindLastSlash(PATH_BackgroundImage)
    If 3 < N Then
      PATH_BackgroundImagePath = Mid(PATH_BackgroundImage, 1, N)
    Else
      PATH_BackgroundImagePath = ""
    End If

    FLAG_Loading = False

    STATS_DefineY()

  End Sub

  Private Sub INIT_FillComboBoxes()

    'R3.20 Setup some default FX values.
    CFX3DVar(1, 2) = "270°"
    CFX3DVar(1, 3) = "70%"
    CFX3DVar(1, 4) = "5.0%"
    CFX3DVar(2, 2) = "270°"
    CFX3DVar(2, 3) = "50%"
    CFX3DVar(2, 4) = "5.0%"
    CFX3DVar(3, 2) = "270°"
    CFX3DVar(3, 3) = "50%"
    CFX3DVar(3, 4) = "2.0%"

    'R3.00 Fill in Combo Boxes with selection items. 
    cboRankA1.Items.Add("100%")
    cboRankA1.Items.Add("90%")
    cboRankA1.Items.Add("80%")
    cboRankA1.Items.Add("70%")
    cboRankA1.Items.Add("60%")
    cboRankA1.Items.Add("50%")
    cboRankA1.Items.Add("40%")
    cboRankA1.Items.Add("30%")
    cboRankA1.Items.Add("20%")
    cboRankA1.Items.Add("10%")
    cboRankA1.Items.Add("0%")

    cboRankA2.Items.Add("100%")
    cboRankA2.Items.Add("90%")
    cboRankA2.Items.Add("80%")
    cboRankA2.Items.Add("70%")
    cboRankA2.Items.Add("60%")
    cboRankA2.Items.Add("50%")
    cboRankA2.Items.Add("40%")
    cboRankA2.Items.Add("30%")
    cboRankA2.Items.Add("20%")
    cboRankA2.Items.Add("10%")
    cboRankA2.Items.Add("0%")

    cboNameA1.Items.Add("100%")
    cboNameA1.Items.Add("90%")
    cboNameA1.Items.Add("80%")
    cboNameA1.Items.Add("70%")
    cboNameA1.Items.Add("60%")
    cboNameA1.Items.Add("50%")
    cboNameA1.Items.Add("40%")
    cboNameA1.Items.Add("30%")
    cboNameA1.Items.Add("20%")
    cboNameA1.Items.Add("10%")
    cboNameA1.Items.Add("0%")

    cboNameA2.Items.Add("100%")
    cboNameA2.Items.Add("90%")
    cboNameA2.Items.Add("80%")
    cboNameA2.Items.Add("70%")
    cboNameA2.Items.Add("60%")
    cboNameA2.Items.Add("50%")
    cboNameA2.Items.Add("40%")
    cboNameA2.Items.Add("30%")
    cboNameA2.Items.Add("20%")
    cboNameA2.Items.Add("10%")
    cboNameA2.Items.Add("0%")

    cboPageSize.Items.Add("0 - Normal 630px")
    cboPageSize.Items.Add("1 - Normal 735px")
    cboPageSize.Items.Add("2 - Normal 840px")
    cboPageSize.Items.Add("3 - Normal 1050px")
    cboPageSize.Items.Add("4 - Thin 630px")
    cboPageSize.Items.Add("5 - Thin 735px")
    cboPageSize.Items.Add("6 - Thin 840px")
    cboPageSize.Items.Add("7 - Thin 1050px")

    cboLayoutY.Items.Add("0 - 60% tight")
    cboLayoutY.Items.Add("1 - 70% tight")
    cboLayoutY.Items.Add("2 - 80% tight")
    cboLayoutY.Items.Add("3 - 90% tight")
    cboLayoutY.Items.Add("4 - 60% spread")
    cboLayoutY.Items.Add("5 - 70% spread")
    cboLayoutY.Items.Add("6 - 80% spread")
    cboLayoutY.Items.Add("7 - 90% spread")

    cboLayoutX.Items.Add("0 - 60% tight")
    cboLayoutX.Items.Add("1 - 70% tight")
    cboLayoutX.Items.Add("2 - 80% tight")
    cboLayoutX.Items.Add("3 - 90% tight")
    cboLayoutX.Items.Add("4 - 60% spread")
    cboLayoutX.Items.Add("5 - 70% spread")
    cboLayoutX.Items.Add("6 - 80% spread")
    cboLayoutX.Items.Add("7 - 90% spread")

    cboScaling.Items.Add("0 - Normal")
    cboScaling.Items.Add("1 - Tile")
    cboScaling.Items.Add("2 - Fit")

    cboRank3D.Items.Add("--")
    cboRank3D.Items.Add("45°")
    cboRank3D.Items.Add("90°")
    cboRank3D.Items.Add("135°")
    cboRank3D.Items.Add("180°")
    cboRank3D.Items.Add("225°")
    cboRank3D.Items.Add("270°")
    cboRank3D.Items.Add("315°")
    cboRank3D.Items.Add("360°")

    cboName3D.Items.Add("--")
    cboName3D.Items.Add("45°")
    cboName3D.Items.Add("90°")
    cboName3D.Items.Add("135°")
    cboName3D.Items.Add("180°")
    cboName3D.Items.Add("225°")
    cboName3D.Items.Add("270°")
    cboName3D.Items.Add("315°")
    cboName3D.Items.Add("360°")

    cboFXVar1.Items.Add("None")
    cboFXVar1.Items.Add("Shadow")
    cboFXVar1.Items.Add("Emboss")
    cboFXVar1.Items.Add("Lab Blur")

    cboFXVar2.Items.Add("--")
    cboFXVar2.Items.Add("45°")
    cboFXVar2.Items.Add("90°")
    cboFXVar2.Items.Add("135°")
    cboFXVar2.Items.Add("180°")
    cboFXVar2.Items.Add("225°")
    cboFXVar2.Items.Add("270°")
    cboFXVar2.Items.Add("315°")
    cboFXVar2.Items.Add("360°")

    cboFxVar4.Items.Add("0.0%")
    cboFxVar4.Items.Add("1.0%")
    cboFxVar4.Items.Add("2.0%")
    cboFxVar4.Items.Add("3.0%")
    cboFxVar4.Items.Add("4.0%")
    cboFxVar4.Items.Add("5.0%")
    cboFxVar4.Items.Add("6.0%")
    cboFxVar4.Items.Add("7.0%")
    cboFxVar4.Items.Add("8.0%")
    cboFxVar4.Items.Add("9.0%")
    cboFxVar4.Items.Add("10.0%")

    cboFxVar3.Items.Add("40%")
    cboFxVar3.Items.Add("45%")
    cboFxVar3.Items.Add("50%")
    cboFxVar3.Items.Add("55%")
    cboFxVar3.Items.Add("60%")
    cboFxVar3.Items.Add("65%")
    cboFxVar3.Items.Add("70%")
    cboFxVar3.Items.Add("75%")
    cboFxVar3.Items.Add("80%")
    cboFxVar3.Items.Add("85%")
    cboFxVar3.Items.Add("90%")
    cboFxVar3.Items.Add("95%")

  End Sub


  Private Function ALPHA_CalcPercent(tAlpha As Integer) As String
    Dim N1 As Integer
    Dim A As String

    'R3.00 We are saving Alpha in 0-255, but listing it from 0%-100% in combo list.
    N1 = tAlpha / 2.55
    A = CStr(N1) & "%"

    ALPHA_CalcPercent = A

  End Function

  Private Sub cboRankA1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboRankA1.SelectedIndexChanged
    If FLAG_Loading Then Exit Sub
    CRankB1 = Color.FromArgb(255 * (Val(cboRankA1.Text) * 0.01), CRankB1.R, CRankB1.G, CRankB1.B)
    SETTINGS_Save()
    Call GFX_DrawStats()
  End Sub
  Private Sub cboRankA2_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboRankA2.SelectedIndexChanged
    If FLAG_Loading Then Exit Sub
    CRankB2 = Color.FromArgb(255 * (Val(cboRankA2.Text) * 0.01), CRankB2.R, CRankB2.G, CRankB2.B)
    SETTINGS_Save()
    Call GFX_DrawStats()
  End Sub

  Private Sub cmNoImage_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmNoImage.Click
    bmpBuffer = Nothing                 'R3.00 Clear the saved background image from memory.
    PATH_BackgroundImage = ""           'R2.00 Clear the saved filename.
    Call SETTINGS_Save()                  'R1.00 Save the cleared filename.  
    Call GFX_DrawStats()
  End Sub

  Private Sub cmFindLog_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmFindLog.Click
    Dim fd As OpenFileDialog = New OpenFileDialog()
    Dim A As String

    'R2.00 Find the LOG file. Try top help get to the right location if possible.
    fd.Title = "FIND: Warnings.Log in My Games\Company of Heroes 2"
    If PATH_GamePath <> "" Then
      fd.InitialDirectory = PATH_GamePath
    Else
      A = Microsoft.VisualBasic.FileIO.SpecialDirectories.MyDocuments & "\My Games\Company of Heroes 2\"
      If System.IO.Directory.Exists(A) Then
        fd.InitialDirectory = A
      Else
        fd.InitialDirectory = Microsoft.VisualBasic.FileIO.SpecialDirectories.MyDocuments
      End If
    End If
    fd.Filter = "Log Files (*.log)|*.log"
    fd.FilterIndex = 1

    If fd.ShowDialog() = DialogResult.OK Then
      PATH_Game = fd.FileName
      lbPath.Text = PATH_Game
      Call SETTINGS_Save()

      'R2.00 Strip the filename off for init dir on dialog.  
      Dim N As Integer = InStr(PATH_Game, "warnings")
      If 3 < N Then
        PATH_GamePath = Mid(PATH_Game, 1, N - 1)
      Else
        PATH_GamePath = ""
      End If
    End If

  End Sub


  Private Sub cmScanLog_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmScanLog.Click
    'R2.10 If we dont have a valid log file path, exit with help notice.
    If Not (System.IO.File.Exists(PATH_Game)) Then
      MsgBox("Please locate the warnings.log file in your COH2 My Games directory." & vbCr & vbCr & "Click on FIND LOG FILE to search and select.", MsgBoxStyle.Information)
      Exit Sub
    End If

    SCAN_Enabled = Not SCAN_Enabled

    If SCAN_Enabled Then
      cmScanLog.Text = "Scanning..."
      lbStatus.BackColor = Color.FromArgb(255, 192, 255, 192)
      CONTROLS_Enabled(False)
      Timer1.Enabled = True
    Else
      Timer1.Enabled = False
      lbStatus.BackColor = Color.FromArgb(255, 192, 192, 192)
      lbStatus.Text = "Ready"
      cmScanLog.Text = "Scan log every 10s"
      Call CONTROLS_Enabled(True)               'R3.20 Turn ON all controls.
      Call GFX_UpdateScreenControls()           'R3.20 Turn off the controls for FX that should not be on now.
    End If

  End Sub

  Private Sub CONTROLS_Enabled(tState As Boolean)

    'R1.00 Turn OFF all Controls while scanning on timer.
    cmCheckLog.Enabled = tState
    cmFindLog.Enabled = tState
    cmTestData.Enabled = tState

    cmFormColor.Enabled = tState
    cmFormImage.Enabled = tState
    cmNoImage.Enabled = tState
    'cmCopy.Enabled = tState       'R3.30 Leave this available.
    cmAbout.Enabled = tState

    cboPageSize.Enabled = tState
    cboLayoutY.Enabled = tState
    cboLayoutX.Enabled = tState
    cboScaling.Enabled = tState

    cmGUILite.Enabled = tState
    cmGUIDark.Enabled = tState

    cmRankF1.Enabled = tState
    cmRankF2.Enabled = tState
    cmRankFD.Enabled = tState
    cmRankFR.Enabled = tState
    cmRankB1.Enabled = tState
    cmRankB2.Enabled = tState
    cmRankBD.Enabled = tState
    cmRankBR.Enabled = tState
    cmRank3DC.Enabled = tState
    cboRankA1.Enabled = tState
    cboRankA2.Enabled = tState
    cboRank3D.Enabled = tState
    cmRankFont.Enabled = tState

    cmNameF1.Enabled = tState
    cmNameF2.Enabled = tState
    cmNameFD.Enabled = tState
    cmNameFR.Enabled = tState
    cmNameB1.Enabled = tState
    cmNameB2.Enabled = tState
    cmNameBD.Enabled = tState
    cmNameBR.Enabled = tState
    cmName3DC.Enabled = tState
    cboNameA1.Enabled = tState
    cboNameA2.Enabled = tState
    cboName3D.Enabled = tState
    cmNameFont.Enabled = tState

    cboFXVar1.Enabled = tState
    chkFX.Enabled = tState
    cmFX3DC.Enabled = tState
    cboFXVar2.Enabled = tState
    cboFxVar3.Enabled = tState
    cboFxVar4.Enabled = tState

    cmFXModeHelp.Enabled = tState

  End Sub

  Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
    Static SecCnt As Long

    SecCnt += 1

    If 10 < SecCnt Then
      Call LOG_Scan()
      SecCnt = 0
    Else
      lbStatus.Text = "Scan in " & 11 - SecCnt & "s"
    End If


  End Sub


  Private Sub cmCopy_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmCopy.Click
    'R3.00 Copy Picturebox image data to the clipboard.
    Dim tmpImg As New Bitmap(pbStats.Image, pbStats.Width, pbStats.Height)

    Clipboard.Clear()
    Clipboard.SetImage(tmpImg)

    tmpImg.Dispose()

  End Sub


  Private Sub cmRankFont_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmRankFont.Click
    Dim fontDialog1 As FontDialog = New FontDialog

    'R1.00 Get current font.
    fontDialog1.Font = FONT_Rank    'R3.00 lbRank01.Font    

    'R1.00 Get user selected font, store it, and redraw controls.
    If fontDialog1.ShowDialog() <> DialogResult.Cancel Then
      FONT_Rank = fontDialog1.Font                           'R3.00 Moved Font tracking to a VAR now.
      FONT_Rank_Name = fontDialog1.Font.Name
      FONT_Rank_Size = fontDialog1.Font.Size
      FONT_Rank_Bold = fontDialog1.Font.Bold
      FONT_Rank_Italic = fontDialog1.Font.Italic
      SETTINGS_Save()

    End If

    'R3.00 Update the screen stats area.
    Call GFX_DrawStats()

  End Sub

  Private Sub cmAbout_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmAbout.Click

    frmAbout.ShowDialog()

  End Sub

  Private Sub STATS_DefineY()
    Dim i As Integer
    Dim YStart As Single
    Dim YStep As Single
    Dim Y As Single

    Select Case Val(cboLayoutY.Text)
      Case 0
        YStart = 0.2 : YStep = 0.6 / 4
      Case 1
        YStart = 0.15 : YStep = 0.7 / 4
      Case 2
        YStart = 0.1 : YStep = 0.8 / 4
      Case 3
        YStart = 0.05 : YStep = 0.9 / 4
      Case 4
        YStart = 0.2 : YStep = 0.6 / 4
      Case 5
        YStart = 0.15 : YStep = 0.7 / 4
      Case 6
        YStart = 0.1 : YStep = 0.8 / 4
      Case 7
        YStart = 0.05 : YStep = 0.9 / 4
    End Select

    'R2.00 Force YStart and Ystep to an integer pixel value or we get spaces between labels.
    i = YStep * pbStats.Height    'R3.30 Deprecated pnlPlr.Height
    YStep = i / pbStats.Height
    i = YStart * pbStats.Height
    YStart = i / pbStats.Height

    Select Case Val(cboLayoutY.Text)
      Case 0
        Y = YStart : LAB_Height = YStep
      Case 1
        Y = YStart : LAB_Height = YStep
      Case 2
        Y = YStart : LAB_Height = YStep
      Case 3
        Y = YStart : LAB_Height = YStep
      Case 4
        Y = YStart + YStep * 0.075 : LAB_Height = YStep * 0.8
      Case 5
        Y = YStart + YStep * 0.075 : LAB_Height = YStep * 0.8
      Case 6
        Y = YStart + YStep * 0.075 : LAB_Height = YStep * 0.8
      Case 7
        Y = YStart + YStep * 0.075 : LAB_Height = YStep * 0.8
    End Select

    For i = 1 To 7 Step 2
      LAB_Rank(i).Y = Y * pbStats.Height
      LAB_Rank(i).Height = LAB_Height * pbStats.Height
      LAB_Rank(i).Ycenter = LAB_Rank(i).Y + LAB_Rank(i).Height / 2

      LAB_Name(i).Y = Y * pbStats.Height
      LAB_Name(i).Height = LAB_Height * pbStats.Height
      LAB_Name(i).Ycenter = LAB_Name(i).Y + LAB_Name(i).Height / 2

      LAB_Fact(i).Y = Y * pbStats.Height
      LAB_Fact(i).Height = LAB_Height * pbStats.Height
      LAB_Fact(i).Ycenter = LAB_Fact(i).Y + LAB_Fact(i).Height / 2


      LAB_Rank(i + 1).Y = Y * pbStats.Height
      LAB_Rank(i + 1).Height = LAB_Height * pbStats.Height
      LAB_Rank(i + 1).Ycenter = LAB_Rank(i + 1).Y + LAB_Rank(i + 1).Height / 2

      LAB_Name(i + 1).Y = Y * pbStats.Height
      LAB_Name(i + 1).Height = LAB_Height * pbStats.Height
      LAB_Name(i + 1).Ycenter = LAB_Name(i + 1).Y + LAB_Name(i + 1).Height / 2

      LAB_Fact(i + 1).Y = Y * pbStats.Height
      LAB_Fact(i + 1).Height = LAB_Height * pbStats.Height
      LAB_Fact(i + 1).Ycenter = LAB_Fact(i + 1).Y + LAB_Fact(i + 1).Height / 2

      Y += YStep
    Next i

  End Sub

  Private Sub STATS_DefineX()
    '**************************************************************************************
    'R2.00 Should always calc SIZE, LayoutY, and then LayoutX so faction pics are square.
    '**************************************************************************************
    Dim i As Integer
    Dim XC1, XCoff As Integer   'R2.00 Center of each teams labels.
    Dim XF, XR, XP As Integer   'R2.00 Faction, Rank, and Player name positions.  
    Dim XWid As Integer         'R2.00 Width of label group (left or Right). 
    Dim Hgt As Integer          'R2.00 Height of Faction image so we can make it square. 
    Dim Xoff As Integer         'R2.00 Space between labels.
    Dim XRankWidth As Single    'R2.00 Width in percent of space between XR and end of name label.
    Hgt = LAB_Fact(1).Height    'lbRank01.Height      'R2.00 Get width of Faction image to make it square.
    XC1 = pbStats.Width / 4     'R2.00 Center of left Label group.
    XCoff = pbStats.Width / 2   'R2.00 Offset to Center of right side group. 

    'R2.00 Get the width of the label groups and space between labels.
    Select Case Val(cboLayoutX.Text)
      Case 0 : XWid = 0.6 * (pbStats.Width / 2) : Xoff = 0 : XRankWidth = 0.35
      Case 1 : XWid = 0.7 * (pbStats.Width / 2) : Xoff = 0 : XRankWidth = 0.3
      Case 2 : XWid = 0.8 * (pbStats.Width / 2) : Xoff = 0 : XRankWidth = 0.25
      Case 3 : XWid = 0.9 * (pbStats.Width / 2) : Xoff = 0 : XRankWidth = 0.2
      Case 4 : XWid = 0.6 * (pbStats.Width / 2) : Xoff = 4 : XRankWidth = 0.35
      Case 5 : XWid = 0.7 * (pbStats.Width / 2) : Xoff = 6 : XRankWidth = 0.3
      Case 6 : XWid = 0.8 * (pbStats.Width / 2) : Xoff = 8 : XRankWidth = 0.25
      Case 7 : XWid = 0.9 * (pbStats.Width / 2) : Xoff = 10 : XRankWidth = 0.2
    End Select

    'R2.00 Calc Xfaction, Xrank, and Xplayername.
    XF = XC1 - XWid * 0.5
    XR = Xoff + (XF + Hgt)
    XP = Xoff + (XR + (XWid - XR) * XRankWidth)  'R2.00 Make RANK label some % of remaining width.

    For i = 1 To 7 Step 2
      'R2.00 Adjust Left Group X values.
      LAB_Fact(i).X = XF
      LAB_Rank(i).X = XR
      LAB_Name(i).X = XP
      LAB_Fact(i).Width = Hgt
      LAB_Rank(i).Width = (XP - XR - Xoff)
      LAB_Name(i).Width = ((XC1 + XWid * 0.5) - XP - Xoff)

      'R2.00 Adjust Right Group X values. All values are pushed right by XCoff for right side group.
      LAB_Fact(i + 1).X = (XF + XCoff)
      LAB_Rank(i + 1).X = (XR + XCoff)
      LAB_Name(i + 1).X = (XP + XCoff)
      LAB_Fact(i + 1).Width = Hgt
      LAB_Rank(i + 1).Width = (XP - XR - Xoff)
      LAB_Name(i + 1).Width = ((XC1 + XWid * 0.5) - XP - Xoff)
    Next i

  End Sub

  Private Sub STATS_Size()

    Select Case Val(cboPageSize.Text)
      Case 0 : pbStats.Width = 630 : pbStats.Height = 150
      Case 1 : pbStats.Width = 735 : pbStats.Height = 175
      Case 2 : pbStats.Width = 840 : pbStats.Height = 200
      Case 3 : pbStats.Width = 1050 : pbStats.Height = 250
      Case 4 : pbStats.Width = 630 : pbStats.Height = 120
      Case 5 : pbStats.Width = 735 : pbStats.Height = 140
      Case 6 : pbStats.Width = 840 : pbStats.Height = 160
      Case 7 : pbStats.Width = 1050 : pbStats.Height = 200
    End Select

  End Sub

  Private Sub cboPageSize_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboPageSize.SelectedIndexChanged
    If FLAG_Loading Then Exit Sub

    STATS_Size()
    STATS_DefineY()
    STATS_DefineX()

    SETTINGS_Save()
    Call GFX_DrawStats()
  End Sub

  Private Sub cboLayoutY_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboLayoutY.SelectedIndexChanged
    If FLAG_Loading Then Exit Sub

    STATS_DefineY()
    STATS_DefineX()  'R2.00 X gets adjusted to Y size for faction images.

    SETTINGS_Save()
    Call GFX_DrawStats()
  End Sub

  Private Sub cboLayoutX_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboLayoutX.SelectedIndexChanged
    If FLAG_Loading Then Exit Sub

    STATS_DefineY()
    STATS_DefineX()  'R2.00 X gets adjusted to Y size for faction images.

    SETTINGS_Save()
    Call GFX_DrawStats()
  End Sub

  Private Sub cmSizeRefresh_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmSizeRefresh.Click

    STATS_Size()
    STATS_DefineY()
    STATS_DefineX()  'R2.00 X gets adjusted to Y size for faction images.
    Call GFX_DrawStats()

  End Sub

  Private Sub cmNameFont_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmNameFont.Click
    Dim fontDialog1 As FontDialog = New FontDialog

    'R1.00 Get current font.
    fontDialog1.Font = FONT_Name   '3.00 lbName01.Font    

    'R1.00 Get user selected font, store it, and redraw controls.
    If fontDialog1.ShowDialog() <> DialogResult.Cancel Then
      FONT_Name = fontDialog1.Font                           'R3.00 Moved Font tracking to a VAR now.
      FONT_Name_Name = fontDialog1.Font.Name
      FONT_Name_Size = fontDialog1.Font.Size
      FONT_Name_Bold = fontDialog1.Font.Bold
      FONT_Name_Italic = fontDialog1.Font.Italic
      SETTINGS_Save()
    End If

    'R3.00 Update the screen stats area.
    Call GFX_DrawStats()

  End Sub

  Private Sub frmMain_Shown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shown
    FLAG_Loading = True   'R2.00 Tell Controls not to update.

    STATS_Size()
    STATS_DefineY()
    STATS_DefineX()      'R2.00 X gets adjusted to Y size for faction images.
    Call GFX_DrawStats()

    FLAG_Loading = False             'R3.00 Tell Controls its OK to update.

  End Sub

  Private Sub cboScaling_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboScaling.SelectedIndexChanged
    If FLAG_Loading Then Exit Sub

    Call SETTINGS_Save()
    Call GFX_DrawStats()

  End Sub

  Private Sub cmGUIDark_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmGUIDark.Click

    Call GUI_SetDark()
    GUI_ColorMode = 1
    Call SETTINGS_Save()

  End Sub

  Private Sub cmGUILite_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmGUILite.Click

    Call GUI_SetLite()
    GUI_ColorMode = 0
    Call SETTINGS_Save()

  End Sub

  Private Sub GUI_SetDark()
    Dim CHover As Color
    Dim CFore As Color
    Dim CBack As Color
    Dim CGroupFore As Color
    Dim CLabFore As Color

    CGroupFore = Color.FromArgb(255, 255, 255, 255)
    CLabFore = Color.FromArgb(255, 192, 192, 192)

    CFore = Color.FromArgb(255, 232, 232, 232)
    CBack = Color.FromArgb(255, 32, 32, 32)
    CHover = Color.FromArgb(255, 48, 64, 48)

    Me.BackColor = Color.FromArgb(255, 32, 32, 42)
    Me.ForeColor = Color.FromArgb(255, 232, 232, 232)

    lbPath.BackColor = Color.FromArgb(255, 0, 0, 0)
    lbPath.ForeColor = Color.FromArgb(255, 232, 232, 255)
    lbHelp01.ForeColor = Color.FromArgb(255, 232, 232, 255)

    Call GUI_SetColor(CFore, CBack, CHover, CGroupFore, CLabFore)

  End Sub

  Private Sub GUI_SetLite()
    Dim CHover As Color
    Dim CFore As Color
    Dim CBack As Color
    Dim CGroupFore As Color
    Dim CLabFore As Color

    CGroupFore = Color.FromArgb(255, 0, 0, 0)
    CLabFore = Color.FromArgb(255, 32, 32, 32)

    CFore = Color.FromArgb(255, 0, 0, 0)
    CBack = Color.FromArgb(255, 232, 232, 232)
    CHover = Color.FromArgb(255, 232, 255, 232)

    Me.BackColor = Color.FromArgb(255, 232, 232, 242)
    Me.ForeColor = Color.FromArgb(255, 0, 0, 0)

    lbPath.BackColor = Color.FromArgb(255, 192, 192, 192)
    lbPath.ForeColor = Color.FromArgb(255, 0, 0, 0)
    lbHelp01.ForeColor = Color.FromArgb(255, 64, 64, 64)

    Call GUI_SetColor(CFore, CBack, CHover, CGroupFore, CLabFore)

  End Sub

  Private Sub GUI_SetColor(CFore As Color, CBack As Color, CHover As Color, CGroupFore As Color, CLabFore As Color)
    Dim Butt As Button
    Dim Labe As Label

    gbRank.ForeColor = CGroupFore
    gbName.ForeColor = CGroupFore
    gbBack.ForeColor = CGroupFore
    gbLayout.ForeColor = CGroupFore
    gbFX.ForeColor = CGroupFore

    lbR3.ForeColor = CLabFore
    lbF4.ForeColor = CLabFore
    Label7.ForeColor = CLabFore
    Label3.ForeColor = CLabFore
    Label4.ForeColor = CLabFore
    Label6.ForeColor = CLabFore

    For Each cntrl As Control In gbRank.Controls
      If TypeOf cntrl Is Label Then
        Labe = CType(cntrl, Label)
        Labe.ForeColor = CLabFore
      End If
    Next
    For Each cntrl As Control In gbName.Controls
      If TypeOf cntrl Is Label Then
        Labe = CType(cntrl, Label)
        Labe.ForeColor = CLabFore
      End If
    Next
    For Each cntrl As Control In gbFX.Controls
      If TypeOf cntrl Is Label Then
        Labe = CType(cntrl, Label)
        Labe.ForeColor = CLabFore
      End If
    Next

    For Each cntrl As Control In Me.Controls
      If TypeOf cntrl Is Button Then
        Butt = CType(cntrl, Button)
        Butt.BackColor = CBack
        Butt.ForeColor = CFore
        Butt.FlatAppearance.MouseOverBackColor = CHover
      End If
    Next
    For Each cntrl As Control In gbRank.Controls
      If TypeOf cntrl Is Button Then
        Butt = CType(cntrl, Button)
        Butt.BackColor = CBack
        Butt.ForeColor = CFore
        Butt.FlatAppearance.MouseOverBackColor = CHover
      End If
    Next
    For Each cntrl As Control In gbName.Controls
      If TypeOf cntrl Is Button Then
        Butt = CType(cntrl, Button)
        Butt.BackColor = CBack
        Butt.ForeColor = CFore
        Butt.FlatAppearance.MouseOverBackColor = CHover
      End If
    Next
    For Each cntrl As Control In gbBack.Controls
      If TypeOf cntrl Is Button Then
        Butt = CType(cntrl, Button)
        Butt.BackColor = CBack
        Butt.ForeColor = CFore
        Butt.FlatAppearance.MouseOverBackColor = CHover
      End If
    Next
    For Each cntrl As Control In gbLayout.Controls
      If TypeOf cntrl Is Button Then
        Butt = CType(cntrl, Button)
        Butt.BackColor = CBack
        Butt.ForeColor = CFore
        Butt.FlatAppearance.MouseOverBackColor = CHover
      End If
    Next
    For Each cntrl As Control In gbFX.Controls
      If TypeOf cntrl Is Button Then
        Butt = CType(cntrl, Button)
        Butt.BackColor = CBack
        Butt.ForeColor = CFore
        Butt.FlatAppearance.MouseOverBackColor = CHover
      End If
    Next

  End Sub

  Private Sub FX_GetVarStrings()
    Dim N As Integer

    N = cboFXVar1.SelectedIndex

    If 0 < N Then
      CFX3DVar(N, 1) = cboFXVar1.Text
      CFX3DVar(N, 2) = cboFXVar2.Text
      CFX3DVar(N, 3) = cboFxVar3.Text
      CFX3DVar(N, 4) = cboFxVar4.Text
    End If

  End Sub

  Private Sub FX_SetVarControls()
    Dim N As Integer

    N = cboFXVar1.SelectedIndex

    If 0 < N Then
      cboFXVar1.Text = CFX3DVar(N, 1)
      cboFXVar2.Text = CFX3DVar(N, 2)
      cboFxVar3.Text = CFX3DVar(N, 3)
      cboFxVar4.Text = CFX3DVar(N, 4)
    End If

  End Sub

  Private Sub GFX_DrawStats()
    Dim tPic As PictureBox
    Dim tLabHgt As Integer
    Dim Cx, Cy, Cx2, Cy2, Chgt As Integer
    Dim linGrBrush = New System.Drawing.Drawing2D.LinearGradientBrush(New Point(0, 0), New Point(20, 0), Color.FromArgb(255, 255, 0, 0), Color.FromArgb(255, 0, 0, 255))
    Dim tX, tY As Integer
    Dim tFont As Font = FONT_Rank
    Dim TextHgt12 As Integer
    Dim POP(0 To 8) As Integer

    'R3.00 Precalc some vars for readability in code.
    tLabHgt = LAB_Rank(1).Height \ 2

    'R3.00 NEEDS work.
    'R3.00 Create a bitmap memory image to draw stats to. 
    pbStats.Width = pbStats.Width
    pbStats.Height = pbStats.Height
    Dim BM As Bitmap = New Bitmap(pbStats.Width, pbStats.Height)
    Dim BM2 As Bitmap = New Bitmap(pbStats.Width, pbStats.Height)
    Dim Gfx As Graphics = Graphics.FromImage(BM)
    Dim Gfx2 As Graphics = Graphics.FromImage(BM2)

    '*****************************************************************
    'R3.00 Draw the stats page background.
    '*****************************************************************
    If bmpBuffer Is Nothing Then
      'R3.00 No image available so draw a solid color background.
      Gfx.FillRectangle(New SolidBrush(pbStats.BackColor), 0, 0, pbStats.Width, pbStats.Height)
    Else
      'R3.00 Scale and Draw the background image.
      Select Case Val(cboScaling.Text)
        Case 0   'R3.00 Normal Scaling
          Gfx.DrawImage(bmpBuffer, 0, 0, bmpBuffer.Width, bmpBuffer.Height)
        Case 1   'R3.00 Tiled Scaling
          For tY = 0 To BM.Height Step bmpBuffer.Height
            For tX = 0 To BM.Width Step bmpBuffer.Width
              Gfx.DrawImage(bmpBuffer, tX, tY, bmpBuffer.Width, bmpBuffer.Height)
            Next
          Next
        Case 2 'R3.00 Stretch/Fit Scaling
          Gfx.DrawImage(bmpBuffer, 0, 0, BM.Width, BM.Height)
      End Select
    End If


    '*****************************************************************
    'R3.10 Call any background based FX MODE options like SHADOW, etc
    '*****************************************************************
    If CFX3DActive(FXMode.LabelBlur) Then Call GFX_FX_LabBlur(Gfx, BM)


    '*****************************************************************
    'R3.10 Draw the Rank background rectangles
    '*****************************************************************
    Dim tBrush As SolidBrush = New SolidBrush(CRankB1)        'R3.30  lbRank01.BackColor)
    Dim tBrushFore As SolidBrush = New SolidBrush(CRankF1)    'R3.30  lbRank01.ForeColor)
    Dim tBrushShadow As SolidBrush

    For T = 1 To 8
      'R3.00 Draw the RANK background rectangle.
      If CRankBDir = 0 Then
        linGrBrush = New System.Drawing.Drawing2D.LinearGradientBrush(New Point(0, LAB_Rank(T).Y - 1), New Point(0, LAB_Rank(T).Y + LAB_Rank(T).Height + 1), CRankB1, CRankB2)
      Else
        linGrBrush = New System.Drawing.Drawing2D.LinearGradientBrush(New Point(LAB_Rank(T).X - 1, 0), New Point(LAB_Rank(T).X + LAB_Rank(T).Width + 1, 0), CRankB1, CRankB2)
      End If
      Gfx.FillRectangle(linGrBrush, LAB_Rank(T).X, LAB_Rank(T).Y, LAB_Rank(T).Width, LAB_Rank(T).Height)
    Next

    '*****************************************************************
    'R3.10 Draw the Name background rectangles
    '*****************************************************************  
    tBrush = New SolidBrush(CNameB1)          'R3.30  lbName01.BackColor)
    tBrushFore = New SolidBrush(CNameF1)      'R3.30 lbName01.ForeColor)

    For T = 1 To 8
      'R3.00 Draw the NAME background rectangle.
      If CNameBDir = 0 Then
        linGrBrush = New System.Drawing.Drawing2D.LinearGradientBrush(New Point(0, LAB_Name(T).Y - 1), New Point(0, LAB_Name(T).Y + LAB_Name(T).Height + 1), CNameB1, CNameB2)
      Else
        linGrBrush = New System.Drawing.Drawing2D.LinearGradientBrush(New Point(LAB_Name(T).X - 1, 0), New Point(LAB_Name(T).X + LAB_Name(T).Width + 1, 0), CNameB1, CNameB2)
      End If
      Gfx.FillRectangle(linGrBrush, LAB_Name(T).X, LAB_Name(T).Y, LAB_Name(T).Width, LAB_Name(T).Height)
    Next

    '*****************************************************************
    'R3.10 Call any background based FX MODE options like SHADOW, etc
    '*****************************************************************
    If CFX3DActive(FXMode.Shadow) Then Call GFX_FX_Shadow(Gfx)


    '*****************************************************************
    'R3.00 Define paint/fill brushes for the RANK stats.
    '*****************************************************************
    tBrush = New SolidBrush(CRankF1)      'R3.30 lbRank01.BackColor)
    tBrushFore = New SolidBrush(CRankF1)  'R3.30 lbRank01.ForeColor)
    'dim tBrushShadow as SolidBrush = new SolidBrush(CRank3DC)
    tBrushShadow = New SolidBrush(CRank3DC)
    TextHgt12 = Gfx.MeasureString("X", FONT_Rank).Height / 2    'R3.30 Calc height of gradient color.  'R3.30Changed from Xq.

    For T = 1 To 8
      'R3.00 Create a clipping area so names do not draw past the rectangle.
      Gfx.Clip = New Region(New Rectangle(LAB_Rank(T).X + 1, LAB_Rank(T).Y, LAB_Rank(T).Width - 2, LAB_Rank(T).Height))

      'R3.00 Draw the RANK Shadow text.
      Cx = LAB_Rank(T).X + 2 + (LAB_Rank(T).Width / 2) - (Gfx.MeasureString(PlrRank(T), FONT_Rank).Width / 2)
      Cy = LAB_Rank(T).Y + 2 + (LAB_Rank(T).Height / 2) - (Gfx.MeasureString(PlrRank(T), FONT_Rank).Height / 2)
      'Chgt = Gfx.MeasureString(PlrRank(T), tFont).Height / 2
      Select Case CRank3D
        Case "45°" : Cx2 = 0 : Cy2 = -4
        Case "90°" : Cx2 = -2 : Cy2 = -4
        Case "135°" : Cx2 = -4 : Cy2 = -4
        Case "180°" : Cx2 = -4 : Cy2 = -2
        Case "225°" : Cx2 = -4 : Cy2 = 0
        Case "270°" : Cx2 = -2 : Cy2 = 0
        Case "315°" : Cx2 = 0 : Cy2 = 0
        Case "360°" : Cx2 = 0 : Cy2 = -2
        Case Else : Cx = 0 : Cy = 0
      End Select
      If (0 < Cx) Then Gfx.DrawString(PlrRank(T), FONT_Rank, tBrushShadow, Cx + Cx2, Cy + Cy2)

      'R3.00 Draw the RANK text.
      Cx = LAB_Rank(T).X + (LAB_Rank(T).Width / 2) - (Gfx.MeasureString(PlrRank(T), FONT_Rank).Width / 2)
      Cy = LAB_Rank(T).Y + (LAB_Rank(T).Height / 2) - (Gfx.MeasureString(PlrRank(T), FONT_Rank).Height / 2)
      If CRankFDir = 0 Then
        linGrBrush = New System.Drawing.Drawing2D.LinearGradientBrush(New Point(0, LAB_Rank(T).Ycenter - TextHgt12), New Point(0, LAB_Rank(T).Ycenter + TextHgt12), Color.FromArgb(255, CRankF1.R, CRankF1.G, CRankF1.B), Color.FromArgb(255, CRankF2.R, CRankF2.G, CRankF2.B))
      Else
        linGrBrush = New System.Drawing.Drawing2D.LinearGradientBrush(New Point(LAB_Rank(T).X, 0), New Point(LAB_Rank(T).X + LAB_Rank(T).Width, 0), Color.FromArgb(255, CRankF1.R, CRankF1.G, CRankF1.B), Color.FromArgb(255, CRankF2.R, CRankF2.G, CRankF2.B))
      End If
      Gfx.DrawString(PlrRank(T), FONT_Rank, linGrBrush, Cx, Cy)

      'R3.00 Clear the clipping area.
      Gfx.Clip = New Region(New Rectangle(0, 0, BM.Width, BM.Height))
    Next

    '*****************************************************************
    'Draw the Faction images to the stats page.
    '***************************************************************** 
    'Dim POP(0 To 8) As Integer
    If 0 < GUI_Mouse_PlrIndex Then POP(GUI_Mouse_PlrIndex) = LAB_Fact(1).Height / 6

    For t = 1 To 8
      If PlrFact(t) <> "" Then
        tPic = CType(Me.Controls("pbFact" & PlrFact(t)), PictureBox)
        'Gfx.DrawImage(tPic.Image, LAB_Fact(t).X - POP(t), LAB_Fact(t).Y - POP(t), LAB_Fact(t).Width + POP(t) * 2, LAB_Fact(t).Height + POP(t) * 2)  'R3.20 Pop removed.
        Gfx.DrawImage(tPic.Image, LAB_Fact(t).X, LAB_Fact(t).Y, LAB_Fact(t).Width, LAB_Fact(t).Height)
      End If
    Next

    '*****************************************************************
    'R3.00 Define paint/fill brushes for the NAME stats.
    '*****************************************************************  
    tBrush = New SolidBrush(CNameF1)          'R3.30 lbName01.BackColor)
    tBrushFore = New SolidBrush(CNameF1)      'R3.30lbName01.ForeColor)
    tBrushShadow = New SolidBrush(CName3DC)
    tFont = FONT_Name
    TextHgt12 = Gfx.MeasureString("X", tFont).Height / 2       'R3.30 Changed from Xq.

    For T = 1 To 8
      'R3.00 Create a clipping area so names do not draw past the rectangle.
      Gfx.Clip = New Region(New Rectangle(LAB_Name(T).X + 1, LAB_Name(T).Y, LAB_Name(T).Width - 2, LAB_Name(T).Height))

      'R3.00 Draw the NAME shadow text.
      Chgt = Gfx.MeasureString(PlrName(T), tFont).Height / 2
      Select Case CName3D
        Case "45°" : Cx = LAB_Name(T).X + 3 : Cy = LAB_Name(T).Y - 2 + tLabHgt - Chgt
        Case "90°" : Cx = LAB_Name(T).X + 1 : Cy = LAB_Name(T).Y - 2 + tLabHgt - Chgt
        Case "135°" : Cx = LAB_Name(T).X - 1 : Cy = LAB_Name(T).Y - 2 + tLabHgt - Chgt
        Case "180°" : Cx = LAB_Name(T).X - 1 : Cy = LAB_Name(T).Y + 0 + tLabHgt - Chgt
        Case "225°" : Cx = LAB_Name(T).X - 1 : Cy = LAB_Name(T).Y + 2 + tLabHgt - Chgt
        Case "270°" : Cx = LAB_Name(T).X + 1 : Cy = LAB_Name(T).Y + 2 + tLabHgt - Chgt
        Case "315°" : Cx = LAB_Name(T).X + 3 : Cy = LAB_Name(T).Y + 2 + tLabHgt - Chgt
        Case "360°" : Cx = LAB_Name(T).X + 3 : Cy = LAB_Name(T).Y + 0 + tLabHgt - Chgt
        Case Else : Cx = 0 : Cy = 0
      End Select
      If (0 < Cx) Then Gfx.DrawString(PlrName(T), FONT_Name, tBrushShadow, Cx, Cy)

      'R3.00 Draw the NAME Text.
      Cx = LAB_Name(T).X + 1
      Cy = LAB_Name(T).Y + (tLabHgt) - (Gfx.MeasureString(PlrName(T), tFont).Height / 2)
      If CNameFDir = 0 Then
        linGrBrush = New System.Drawing.Drawing2D.LinearGradientBrush(New Point(0, LAB_Name(T).Ycenter - TextHgt12), New Point(0, LAB_Name(T).Ycenter + TextHgt12), Color.FromArgb(255, CNameF1.R, CNameF1.G, CNameF1.B), Color.FromArgb(255, CNameF2.R, CNameF2.G, CNameF2.B))
      Else
        linGrBrush = New System.Drawing.Drawing2D.LinearGradientBrush(New Point(LAB_Name(T).X, 0), New Point(LAB_Name(T).X + LAB_Name(T).Width, 0), Color.FromArgb(255, CNameF1.R, CNameF1.G, CNameF1.B), Color.FromArgb(255, CNameF2.R, CNameF2.G, CNameF2.B))
      End If
      Gfx.DrawString(PlrName(T), FONT_Name, linGrBrush, Cx, Cy)

      'R3.00 Clear the clipping area.
      Gfx.Clip = New Region(New Rectangle(0, 0, BM.Width, BM.Height))
    Next

    '*****************************************************************
    'R3.10 Call any background based FX MODE options like SHADOW, etc
    '*****************************************************************
    If CFX3DActive(FXMode.Emboss) Then Call GFX_FX_Emboss(Gfx, BM)

    pbStats.Image = BM

    'R3.00 Dispose Not recommended, caused fatal errors in VB runtime if BM was disposed. Gonn let GC cleanup.

  End Sub

  Private Sub GFX_FX_LabBlur(Gfx As Graphics, BM As Bitmap)
    'R3.20  Lock the bitmap's bits.
    Dim rect As New Rectangle(0, 0, BM.Width, BM.Height)
    Dim bmpData As System.Drawing.Imaging.BitmapData = BM.LockBits(rect, Drawing.Imaging.ImageLockMode.ReadWrite, BM.PixelFormat)
    Dim ptr As IntPtr = bmpData.Scan0                  ' Get the address of the first line.
    Dim Stride As Integer = bmpData.Stride
    Dim bytes As Integer = BM.Width * BM.Height * 4  ' Declare an array to hold the bytes of the bitmap.
    Dim rgbValues(bytes - 1) As Byte                   ' This code is specific to a bitmap with 32 bits per pixels.
    Dim t As Integer
    Dim BlurBias As Single
    Dim Blur As Single


    If 1 < Len(CFX3DVar(FXMode.LabelBlur, FXVarDefs.ShadeBias)) Then
      BlurBias = 1 + Val(Mid(CFX3DVar(FXMode.LabelBlur, FXVarDefs.ShadeBias), 1, Len(CFX3DVar(FXMode.LabelBlur, FXVarDefs.ShadeBias)) - 1)) * 0.01
    Else
      BlurBias = 1
    End If
    If BlurBias < 1 Then BlurBias = 1
    If 1.1 < BlurBias Then BlurBias = 1.1

    If 1 < Len(CFX3DVar(FXMode.LabelBlur, FXVarDefs.ShadeAmount)) Then
      Blur = Val(Mid(CFX3DVar(FXMode.LabelBlur, FXVarDefs.ShadeAmount), 1, Len(CFX3DVar(FXMode.LabelBlur, FXVarDefs.ShadeAmount)) - 1)) * 0.01
    Else
      Blur = 0.4
    End If
    If Blur = 0 Then Blur = 0.8

    ' Copy the RGB values into the array.
    System.Runtime.InteropServices.Marshal.Copy(ptr, rgbValues, 0, bytes)

    For t = 1 To 8
      Call FX_BlurRect(rgbValues, Stride, Blur, BlurBias, LAB_Rank(t).X, LAB_Rank(t).Y, LAB_Rank(t).Width, LAB_Rank(t).Height)
      Call FX_BlurRect(rgbValues, Stride, Blur, BlurBias, LAB_Name(t).X, LAB_Name(t).Y, LAB_Name(t).Width, LAB_Name(t).Height)
    Next t

    ' Copy the RGB values back to the bitmap
    System.Runtime.InteropServices.Marshal.Copy(rgbValues, 0, ptr, bytes)

    ' Unlock the bits so they can be used.
    BM.UnlockBits(bmpData)

    ' Draw the modified image.
    Gfx.DrawImage(BM, 0, 0)

  End Sub


  Private Sub GFX_FX_Shadow(Gfx As Graphics)
    Dim tPic As PictureBox
    Dim tLabHgt As Integer
    Dim Cx, Cy, Cx2, Cy2, Chgt As Integer
    Dim linGrBrush = New System.Drawing.Drawing2D.LinearGradientBrush(New Point(0, 0), New Point(20, 0), Color.FromArgb(255, 255, 0, 0), Color.FromArgb(255, 0, 0, 255))
    Dim tFont As Font = FONT_Rank
    Dim TextHgt12 As Integer
    Dim Idx As Integer
    Dim BM2 As Bitmap = New Bitmap(pbStats.Width, pbStats.Height)
    Dim Gfx2 As Graphics = Graphics.FromImage(BM2)

    'R3.10 Precalc some vars for readability in code.
    tLabHgt = LAB_Rank(1).Height \ 2

    '*****************************************************************
    'R3.10 Draw the Faction images to the stats page.
    '***************************************************************** 
    Dim POP(0 To 8) As Integer
    'R3.20 Removed If 0 < GUI_Mouse_PlrIndex Then POP(GUI_Mouse_PlrIndex) = LAB_Fact(1).Height / 6

    For t = 1 To 8
      If PlrFact(t) <> "" Then
        tPic = CType(Me.Controls("pbFact" & PlrFact(t)), PictureBox)
        'R3.20 Removed Gfx2.DrawImage(tPic.Image, LAB_Fact(t).X - POP(t), LAB_Fact(t).Y - POP(t), LAB_Fact(t).Width + POP(t) * 2, LAB_Fact(t).Height + POP(t) * 2)
        Gfx2.DrawImage(tPic.Image, LAB_Fact(t).X, LAB_Fact(t).Y, LAB_Fact(t).Width, LAB_Fact(t).Height)
      End If
    Next

    '*****************************************************************
    'R3.00 Paint a blurred shadow.
    '*****************************************************************
    Dim tBrushShadow As SolidBrush = New SolidBrush(Color.FromArgb(255, 0, 0, 0))
    tBrushShadow = New SolidBrush(Color.FromArgb(255, 0, 0, 0))
    TextHgt12 = Gfx2.MeasureString("Xq", tFont).Height / 2

    For T = 1 To 8
      'R3.00 Create a clipping area so names do not draw past the rectangle.
      Gfx2.Clip = New Region(New Rectangle(LAB_Rank(T).X + 1, LAB_Rank(T).Y, LAB_Rank(T).Width - 2, LAB_Rank(T).Height))

      'R3.00 Draw the RANK Shadow text.
      Cx = LAB_Rank(T).X + 2 + (LAB_Rank(T).Width / 2) - (Gfx2.MeasureString(PlrRank(T), FONT_Rank).Width / 2)
      Cy = LAB_Rank(T).Y + 2 + (LAB_Rank(T).Height / 2) - (Gfx2.MeasureString(PlrRank(T), FONT_Rank).Height / 2)
      Chgt = Gfx2.MeasureString(PlrRank(T), FONT_Rank).Height / 2
      Select Case CFX3DVar(FXMode.Shadow, FXVarDefs.ShadeAng)
        Case "45°" : Cx2 = 0 : Cy2 = -4
        Case "90°" : Cx2 = -2 : Cy2 = -4
        Case "135°" : Cx2 = -4 : Cy2 = -4
        Case "180°" : Cx2 = -4 : Cy2 = -2
        Case "225°" : Cx2 = -4 : Cy2 = 0
        Case "270°" : Cx2 = -2 : Cy2 = 0
        Case "315°" : Cx2 = 0 : Cy2 = 0
        Case "360°" : Cx2 = 0 : Cy2 = -2
        Case Else : Cx2 = 0 : Cy2 = 0
      End Select
      If CFX3DVar(FXMode.Shadow, FXVarDefs.ShadeAng) <> "--" Then Gfx2.DrawString(PlrRank(T), FONT_Rank, tBrushShadow, Cx + Cx2, Cy + Cy2)

      'R3.00 Clear the clipping area.
      Gfx2.Clip = New Region(New Rectangle(0, 0, BM2.Width, BM2.Height))
    Next
    For T = 1 To 8
      'R3.00 Create a clipping area so names do not draw past the rectangle.
      Gfx2.Clip = New Region(New Rectangle(LAB_Name(T).X + 1, LAB_Name(T).Y, LAB_Name(T).Width - 2, LAB_Name(T).Height))

      'R3.00 Draw the RANK Shadow text.
      Chgt = Gfx2.MeasureString(PlrName(T), FONT_Name).Height / 2
      Select Case CFX3DVar(FXMode.Shadow, FXVarDefs.ShadeAng)
        Case "45°" : Cx = LAB_Name(T).X + 3 : Cy = LAB_Name(T).Y - 2 + tLabHgt - Chgt
        Case "90°" : Cx = LAB_Name(T).X + 1 : Cy = LAB_Name(T).Y - 2 + tLabHgt - Chgt
        Case "135°" : Cx = LAB_Name(T).X - 1 : Cy = LAB_Name(T).Y - 2 + tLabHgt - Chgt
        Case "180°" : Cx = LAB_Name(T).X - 1 : Cy = LAB_Name(T).Y + 0 + tLabHgt - Chgt
        Case "225°" : Cx = LAB_Name(T).X - 1 : Cy = LAB_Name(T).Y + 2 + tLabHgt - Chgt
        Case "270°" : Cx = LAB_Name(T).X + 1 : Cy = LAB_Name(T).Y + 2 + tLabHgt - Chgt
        Case "315°" : Cx = LAB_Name(T).X + 3 : Cy = LAB_Name(T).Y + 2 + tLabHgt - Chgt
        Case "360°" : Cx = LAB_Name(T).X + 3 : Cy = LAB_Name(T).Y + 0 + tLabHgt - Chgt
        Case Else : Cx = LAB_Name(T).X : Cy = LAB_Name(T).Y + 0 + tLabHgt - Chgt
      End Select
      If CFX3DVar(FXMode.Shadow, FXVarDefs.ShadeAng) <> "--" Then Gfx2.DrawString(PlrName(T), FONT_Name, tBrushShadow, Cx, Cy)

      'R3.00 Clear the clipping area.
      Gfx2.Clip = New Region(New Rectangle(0, 0, BM2.Width, BM2.Height))
    Next

    ' Lock the bitmap's bits.
    Dim rect As New Rectangle(0, 0, BM2.Width, BM2.Height)
    Dim bmpData As System.Drawing.Imaging.BitmapData = BM2.LockBits(rect, Drawing.Imaging.ImageLockMode.ReadWrite, BM2.PixelFormat)
    Dim ptr As IntPtr = bmpData.Scan0                  ' Get the address of the first line.
    Dim Stride As Integer = bmpData.Stride
    Dim ScanY As Integer
    Dim bytes As Integer = BM2.Width * BM2.Height * 4  ' Declare an array to hold the bytes of the bitmap.
    Dim rgbValues(bytes - 1) As Byte                   ' This code is specific to a bitmap with 32 bits per pixels.

    ' Copy the RGB values into the array.
    System.Runtime.InteropServices.Marshal.Copy(ptr, rgbValues, 0, bytes)

    ' R3.10 Blur to the right.
    Dim Ca, Ca2 As Integer
    Dim Blr1, Blr2 As Single

    'R3.10 Blur Amount
    Dim BlrFac As Single
    If 1 < Len(CFX3DVar(FXMode.Shadow, FXVarDefs.ShadeBias)) Then
      BlrFac = 1 + Val(Mid(CFX3DVar(FXMode.Shadow, FXVarDefs.ShadeBias), 1, Len(CFX3DVar(FXMode.Shadow, FXVarDefs.ShadeBias)) - 1)) * 0.01
    Else
      BlrFac = 1
    End If
    If BlrFac < 1 Then BlrFac = 1
    If 1.1 < BlrFac Then BlrFac = 1.1

    If 1 < Len(CFX3DVar(FXMode.Shadow, FXVarDefs.ShadeAmount)) Then
      Blr1 = Val(Mid(CFX3DVar(FXMode.Shadow, FXVarDefs.ShadeAmount), 1, Len(CFX3DVar(FXMode.Shadow, FXVarDefs.ShadeAmount)) - 1)) * 0.01
    Else
      Blr1 = 0.5
    End If
    If Blr1 = 0 Then Blr1 = 0.8
    Blr2 = 1 - Blr1

    'R3.00 Fill in the SHADOW color, and smooth the alpha channel to make it bigger or smaller.
    For y As Integer = 2 To BM2.Height - 2
      ScanY = (y * Stride)
      Idx = ScanY + (2 * 4)
      For x As Integer = 2 To BM2.Width - 2
        Idx = ScanY + (x * 4)
        rgbValues(Idx) = CFX3DC(1).B       'R3.30 Fill in SOLID color RGB.
        rgbValues(Idx + 1) = CFX3DC(1).G
        rgbValues(Idx + 2) = CFX3DC(1).R
        Ca2 = Int(Ca * Blr1 + rgbValues(Idx + 3) * Blr2) * BlrFac
        If 255 < Ca2 Then Ca2 = 255
        rgbValues(Idx + 3) = Ca2
        'Cb = rgbValues(Idx)              'R3.30 We are only BLURRING alpha channel.
        'Cg = rgbValues(Idx + 1)
        'Cr = rgbValues(Idx + 2)
        Ca = rgbValues(Idx + 3)
      Next x
    Next y
    For y As Integer = 2 To BM2.Height - 2
      ScanY = (y * Stride)
      Idx = ScanY + (2 * 4)
      For x As Integer = BM2.Width - 2 To 2 Step -1
        Idx = ScanY + (x * 4)
        Ca2 = Int(Ca * Blr1 + rgbValues(Idx + 3) * Blr2) * BlrFac
        If 255 < Ca2 Then Ca2 = 255
        rgbValues(Idx + 3) = Ca2
        'Cb = rgbValues(Idx)
        'Cg = rgbValues(Idx + 1)
        'Cr = rgbValues(Idx + 2)
        Ca = rgbValues(Idx + 3)
      Next x
    Next y
    For x As Integer = 2 To BM2.Width - 2
      For y As Integer = 2 To BM2.Height - 2
        ScanY = (y * Stride)
        Idx = ScanY + (x * 4)
        Ca2 = Int(Ca * Blr1 + rgbValues(Idx + 3) * Blr2) * 1.02
        If 255 < Ca2 Then Ca2 = 255
        rgbValues(Idx + 3) = Ca2
        'Cb = rgbValues(Idx)
        'Cg = rgbValues(Idx + 1)
        'Cr = rgbValues(Idx + 2)
        Ca = rgbValues(Idx + 3)
      Next y
    Next x
    For x As Integer = 2 To BM2.Width - 2
      For y As Integer = BM2.Height - 2 To 2 Step -1
        ScanY = (y * Stride)
        Idx = ScanY + (x * 4)
        Ca2 = Int(Ca * Blr1 + rgbValues(Idx + 3) * Blr2) * 1.02
        If 255 < Ca2 Then Ca2 = 255
        rgbValues(Idx + 3) = Ca2
        'Cb = rgbValues(Idx)
        'Cg = rgbValues(Idx + 1)
        'Cr = rgbValues(Idx + 2)
        Ca = rgbValues(Idx + 3)
      Next y
    Next x

    'R3.00 Copy the RGB values back to the bitmap
    System.Runtime.InteropServices.Marshal.Copy(rgbValues, 0, ptr, bytes)

    'R3.00 Unlock the bits so they can be used.
    BM2.UnlockBits(bmpData)

    'R3.00 Draw the modified image.
    Gfx.DrawImage(BM2, 0, 0)


  End Sub

  Private Sub GFX_FX_Emboss(Gfx As Graphics, BM As Bitmap)
    Dim tPic As PictureBox
    Dim tLabHgt As Integer
    Dim Cx, Cy, Cx2, Cy2, Chgt As Integer
    Dim linGrBrush = New System.Drawing.Drawing2D.LinearGradientBrush(New Point(0, 0), New Point(20, 0), Color.FromArgb(255, 255, 0, 0), Color.FromArgb(255, 0, 0, 255))
    Dim tFont As Font = FONT_Rank
    Dim TextHgt12 As Integer
    Dim Idx As Integer

    Dim BM2 As Bitmap = New Bitmap(BM.Width, BM.Height)
    Dim Gfx2 As Graphics = Graphics.FromImage(BM2)

    'R3.10 Precalc some vars for readability in code.
    tLabHgt = LAB_Rank(1).Height \ 2

    '*****************************************************************
    'R3.10 Draw the Faction images to the stats page.
    '***************************************************************** 
    'Dim POP(0 To 8) As Integer
    'If 0 < GUI_Mouse_PlrIndex Then POP(GUI_Mouse_PlrIndex) = LAB_Fact(1).Height / 6

    For t = 1 To 8
      If PlrFact(t) <> "" Then
        tPic = CType(Me.Controls("pbFact" & PlrFact(t)), PictureBox)
        Gfx2.DrawImage(tPic.Image, LAB_Fact(t).X, LAB_Fact(t).Y, LAB_Fact(t).Width, LAB_Fact(t).Height)
      End If
    Next

    '*****************************************************************
    'R3.00 Print the RANK and NAME text on the blank bitmap.
    '*****************************************************************
    Dim tBrushShadow As SolidBrush = New SolidBrush(Color.FromArgb(255, 0, 0, 0))
    tBrushShadow = New SolidBrush(Color.FromArgb(255, 0, 0, 0))
    TextHgt12 = Gfx2.MeasureString("X", FONT_Rank).Height / 2           'R3.30 Was Xq.

    For T = 1 To 8
      'R3.00 Create a clipping area so names do not draw past the rectangle/label.
      Gfx2.Clip = New Region(New Rectangle(LAB_Rank(T).X + 1, LAB_Rank(T).Y, LAB_Rank(T).Width - 2, LAB_Rank(T).Height))

      'R3.00 Draw the RANK Shadow text.
      Cx = LAB_Rank(T).X + 2 + (LAB_Rank(T).Width / 2) - (Gfx2.MeasureString(PlrRank(T), FONT_Rank).Width / 2)
      Cy = LAB_Rank(T).Y + 2 + (LAB_Rank(T).Height / 2) - (Gfx2.MeasureString(PlrRank(T), FONT_Rank).Height / 2)
      Cx2 = 0 : Cy2 = -2
      Gfx2.DrawString(PlrRank(T), FONT_Rank, tBrushShadow, Cx + Cx2, Cy + Cy2)

      'R3.00 Clear the clipping area.
      Gfx2.Clip = New Region(New Rectangle(0, 0, BM2.Width, BM2.Height))
    Next

    TextHgt12 = Gfx2.MeasureString("X", FONT_Name).Height / 2           'R3.30 Was Xq.
    For T = 1 To 8
      'R3.00 Create a clipping area so names do not draw past the rectangle.
      Gfx2.Clip = New Region(New Rectangle(LAB_Name(T).X + 1, LAB_Name(T).Y, LAB_Name(T).Width - 2, LAB_Name(T).Height))

      'R3.00 Draw the NAME Shadow text.
      Chgt = Gfx2.MeasureString(PlrName(T), FONT_Name).Height / 2
      Cx = LAB_Name(T).X + 3 : Cy = LAB_Name(T).Y + 0 + tLabHgt - Chgt
      Gfx2.DrawString(PlrName(T), FONT_Name, tBrushShadow, Cx, Cy)

      'R3.00 Clear the clipping area.
      Gfx2.Clip = New Region(New Rectangle(0, 0, BM2.Width, BM2.Height))
    Next


    '********************************************************************************************
    ' R3.10 Setup high speed memory operations.
    '********************************************************************************************
    Dim rect As New Rectangle(0, 0, BM2.Width, BM2.Height)
    Dim bmpData As System.Drawing.Imaging.BitmapData = BM.LockBits(rect, Drawing.Imaging.ImageLockMode.ReadWrite, BM.PixelFormat)
    Dim bmpData2 As System.Drawing.Imaging.BitmapData = BM2.LockBits(rect, Drawing.Imaging.ImageLockMode.ReadWrite, BM2.PixelFormat)
    Dim ptr As IntPtr = bmpData.Scan0                  'R3.10 Get the address of the Original data.
    Dim ptr2 As IntPtr = bmpData2.Scan0                'R3.10 Get the address of the Embossed data.
    Dim Stride As Integer = bmpData2.Stride
    Dim ScanY As Integer
    Dim bytes As Integer = BM2.Width * BM2.Height * 4  'R3.30 Declare an array to hold the bytes of the bitmap.
    Dim rgbValues(bytes - 1) As Byte                   'R3.30 This code is specific to a bitmap with 32 bits per pixels.
    Dim rgbOrg(bytes - 1) As Byte

    'R3.10 Copy the BGRA values into arrays we can modify.
    System.Runtime.InteropServices.Marshal.Copy(ptr2, rgbValues, 0, bytes)
    System.Runtime.InteropServices.Marshal.Copy(ptr, rgbOrg, 0, bytes)

    ' R3.10 Blur to the right.
    Dim Cb, Ca, Ca2 As Integer
    Dim Blr1, Blr2 As Single
    Dim B1, B2 As Integer

    ''Convert to all colors to Black.
    'For y As Integer = 2 To BM2.Height - 2
    '  ScanY = (y * Stride)
    '  Idx = ScanY + (2 * 4)
    '  For x As Integer = 2 To BM2.Width - 2
    '    Idx = ScanY + (x * 4)

    '    'R3.10 Leave the Alpha we will key off that later.
    '    rgbValues(Idx) = 0
    '    rgbValues(Idx + 1) = 0
    '    rgbValues(Idx + 2) = 0
    '  Next x
    'Next y

    'R3.30 Convert image to BLACK. DO NOT adjust Alpha channel.
    'For Y = 0 To bytes - 1 Step 4
    ' rgbValues(Y) = 0 : rgbValues(Y + 1) = 0 : rgbValues(Y + 2) = 0
    ' Next


    'R3.10 Create GreyScale Embossed bitmap (315 degree) on BLUE channel only.
    'R3.30 Need options for B2 to get other Emboss angles. B2 here is X+1, Y+1.
    For y As Integer = 2 To BM2.Height - 2
      ScanY = (y * Stride)
      Idx = ScanY + (2 * 4)
      For x As Integer = 2 To BM2.Width - 2
        Idx = ScanY + (x * 4)

        'R3.30 Calc emboss on ALPHA channel.
        B1 = rgbValues(Idx + 3)                 'R3.10  (1.0 * rgbValues(Idx) + rgbValues(Idx + 1) + rgbValues(Idx + 2)) / 3
        B2 = rgbValues(Idx + 3 + Stride + 4)    'R3.10  (1.0 * rgbValues(Idx + Stride + 4) + rgbValues(Idx + Stride + 5) + rgbValues(Idx + Stride + 6)) / 3    'R3.100 315 deg

        'R3.10 Calc EMBOSS pixels (Red only). This could be much better.
        Select Case B1 - B2
          Case Is = 0
            rgbValues(Idx) = 128          'R3.10 CFX3DC(1).B   'User Defined color.
            'rgbValues(Idx + 1) = 128     'R3.10 CFX3DC(1).G
            'rgbValues(Idx + 2) = 128     'R3.10 CFX3DC(1).R
          Case Is < 0
            rgbValues(Idx) = 255
            'rgbValues(Idx + 1) = 255
            'rgbValues(Idx + 2) = 255
          Case Is > 0
            rgbValues(Idx) = 0
            'rgbValues(Idx + 1) = 0
            'rgbValues(Idx + 2) = 0
        End Select
      Next x
    Next y

    '********************************************************************
    'R3.10 Blur the Embossed bitmap. Low blur works best for emboss.
    '********************************************************************
    Dim BlrFac As Single

    If 1 < Len(CFX3DVar(FXMode.Emboss, FXVarDefs.ShadeBias)) Then
      BlrFac = 1 + Val(Mid(CFX3DVar(FXMode.Emboss, FXVarDefs.ShadeBias), 1, Len(CFX3DVar(FXMode.Emboss, FXVarDefs.ShadeBias)) - 1)) * 0.01
    Else
      BlrFac = 1
    End If
    If BlrFac < 1 Then BlrFac = 1
    If 1.5 < BlrFac Then BlrFac = 1.5

    If 1 < Len(CFX3DVar(FXMode.Emboss, FXVarDefs.ShadeAmount)) Then
      Blr1 = Val(Mid(CFX3DVar(FXMode.Emboss, FXVarDefs.ShadeAmount), 1, Len(CFX3DVar(FXMode.Emboss, FXVarDefs.ShadeAmount)) - 1)) * 0.01
    Else
      Blr1 = 0.4
    End If
    If Blr1 = 0 Then Blr1 = 0.8
    Blr2 = 1 - Blr1

    '********************************************************************
    'R3.10 Smooth the EMBOSSED image.
    '********************************************************************
    For y As Integer = 2 To BM2.Height - 2
      ScanY = (y * Stride)
      For x As Integer = 2 To BM2.Width - 2
        Idx = ScanY + (x * 4)

        Ca2 = Int(Cb * Blr1 + rgbValues(Idx) * Blr2) * BlrFac
        If 255 < Ca2 Then Ca2 = 255
        rgbValues(Idx) = Ca2

        Cb = rgbValues(Idx)
      Next x
    Next y
    For y As Integer = 2 To BM2.Height - 2
      ScanY = (y * Stride)
      For x As Integer = BM2.Width - 2 To 2 Step -1
        Idx = ScanY + (x * 4)

        Ca2 = Int(Cb * Blr1 + rgbValues(Idx) * Blr2) * BlrFac
        If 255 < Ca2 Then Ca2 = 255
        rgbValues(Idx) = Ca2

        Cb = rgbValues(Idx)
      Next x
    Next y
    For x As Integer = 2 To BM2.Width - 2
      For y As Integer = 2 To BM2.Height - 2
        ScanY = (y * Stride)
        Idx = ScanY + (x * 4)

        Ca2 = Int(Cb * Blr1 + rgbValues(Idx) * Blr2) * BlrFac
        If 255 < Ca2 Then Ca2 = 255
        rgbValues(Idx) = Ca2

        Cb = rgbValues(Idx)
      Next y
    Next x
    For x As Integer = 2 To BM2.Width - 2
      For y As Integer = BM2.Height - 2 To 2 Step -1
        ScanY = (y * Stride)
        Idx = ScanY + (x * 4)

        Ca2 = Int(Cb * Blr1 + rgbValues(Idx) * Blr2) * BlrFac
        If 255 < Ca2 Then Ca2 = 255
        rgbValues(Idx) = Ca2

        Cb = rgbValues(Idx)
      Next y
    Next x

    'R3.10 Multiply the Original data times the Emboss bitmap.
    For y As Integer = 2 To BM2.Height - 2
      ScanY = (y * Stride)
      For x As Integer = 2 To BM2.Width - 2
        Idx = ScanY + (x * 4)

        Ca = rgbOrg(Idx) * (rgbValues(Idx) / 255.0)
        If 255 < Ca Then Ca = 255
        rgbOrg(Idx) = Ca

        Ca = rgbOrg(Idx + 1) * (rgbValues(Idx) / 255.0)   'R3.10 Only use BLUE from Emboss map.
        If 255 < Ca Then Ca = 255
        rgbOrg(Idx + 1) = Ca

        Ca = rgbOrg(Idx + 2) * (rgbValues(Idx) / 255.0)   'R3.10 Only use BLUE from Emboss map.
        If 255 < Ca Then Ca = 255
        rgbOrg(Idx + 2) = Ca
      Next x
    Next y

    'R3.10 Copy the original (now modified) RGB values back to the bitmap memory. It gets drawn in caller.
    System.Runtime.InteropServices.Marshal.Copy(rgbOrg, 0, ptr, bytes)

    'R3.10 Unlock the bitmap memory so it can be used.
    BM2.UnlockBits(bmpData2)
    BM.UnlockBits(bmpData)

    Application.DoEvents()

    'R3.10 Draw the modified value Bitmap. (Not used here)
    'Gfx.DrawImage(BM, 0, 0)


  End Sub

  Private Sub FX_BlurRect(ByRef rgbValues() As Byte, Stride As Integer, BlurAmount As Single, BlurBias As Single, Left As Integer, Top As Integer, Width As Integer, Height As Integer)
    Dim Blr1, Blr2 As Single
    Dim ScanY As Integer
    Dim Idx As Integer
    Dim Ca, Cr, Cg, Cb As Integer
    Dim tC As Integer
    Dim BlrFac As Single

    Blr1 = BlurAmount         'R3.20 How blurry are we 0 - 1.00.
    Blr2 = 1 - Blr1
    BlrFac = BlurBias         'R3.20 Brighten the a little.


    'R3.30 BLUR the selected rectangle area.
    For y As Integer = Top To Top + Height
      ScanY = (y * Stride)
      Idx = ScanY + (2 * 4)
      For x As Integer = Left To Left + Width
        Idx = ScanY + (x * 4)
        tC = Int(Cb * Blr1 + rgbValues(Idx) * Blr2) * BlrFac
        If 255 < tC Then tC = 255
        rgbValues(Idx) = tC
        Cb = rgbValues(Idx)
        tC = Int(Cg * Blr1 + rgbValues(Idx + 1) * Blr2) * BlrFac
        If 255 < tC Then tC = 255
        rgbValues(Idx + 1) = tC
        Cg = rgbValues(Idx + 1)
        tC = Int(Cr * Blr1 + rgbValues(Idx + 2) * Blr2) * BlrFac
        If 255 < tC Then tC = 255
        rgbValues(Idx + 2) = tC
        Cr = rgbValues(Idx + 2)
        tC = Int(Ca * Blr1 + rgbValues(Idx + 3) * Blr2) * BlrFac
        If 255 < tC Then tC = 255
        rgbValues(Idx + 3) = tC
        Ca = rgbValues(Idx + 3)
      Next x
    Next y
    For y As Integer = Top To Top + Height
      ScanY = (y * Stride)
      Idx = ScanY + (2 * 4)
      For x As Integer = Left + Width To Left Step -1
        Idx = ScanY + (x * 4)

        tC = Int(Cb * Blr1 + rgbValues(Idx) * Blr2) * BlrFac
        If 255 < tC Then tC = 255
        rgbValues(Idx) = tC
        Cb = rgbValues(Idx)
        tC = Int(Cg * Blr1 + rgbValues(Idx + 1) * Blr2) * BlrFac
        If 255 < tC Then tC = 255
        rgbValues(Idx + 1) = tC
        Cg = rgbValues(Idx + 1)
        tC = Int(Cr * Blr1 + rgbValues(Idx + 2) * Blr2) * BlrFac
        If 255 < tC Then tC = 255
        rgbValues(Idx + 2) = tC
        Cr = rgbValues(Idx + 2)
        tC = Int(Ca * Blr1 + rgbValues(Idx + 3) * Blr2) * BlrFac
        If 255 < tC Then tC = 255
        rgbValues(Idx + 3) = tC
        Ca = rgbValues(Idx + 3)
      Next x
    Next y
    For x As Integer = Left To Left + Width
      For y As Integer = Top To Top + Height
        ScanY = (y * Stride)
        Idx = ScanY + (x * 4)

        tC = Int(Cb * Blr1 + rgbValues(Idx) * Blr2) * BlrFac
        If 255 < tC Then tC = 255
        rgbValues(Idx) = tC
        Cb = rgbValues(Idx)
        tC = Int(Cg * Blr1 + rgbValues(Idx + 1) * Blr2) * BlrFac
        If 255 < tC Then tC = 255
        rgbValues(Idx + 1) = tC
        Cg = rgbValues(Idx + 1)
        tC = Int(Cr * Blr1 + rgbValues(Idx + 2) * Blr2) * BlrFac
        If 255 < tC Then tC = 255
        rgbValues(Idx + 2) = tC
        Cr = rgbValues(Idx + 2)
        tC = Int(Ca * Blr1 + rgbValues(Idx + 3) * Blr2) * BlrFac
        If 255 < tC Then tC = 255
        rgbValues(Idx + 3) = tC
        Ca = rgbValues(Idx + 3)
      Next y
    Next x
    For x As Integer = Left To Left + Width
      For y As Integer = Top + Height To Top Step -1
        ScanY = (y * Stride)
        Idx = ScanY + (x * 4)

        tC = Int(Cb * Blr1 + rgbValues(Idx) * Blr2) * BlrFac
        If 255 < tC Then tC = 255
        rgbValues(Idx) = tC
        Cb = rgbValues(Idx)
        tC = Int(Cg * Blr1 + rgbValues(Idx + 1) * Blr2) * BlrFac
        If 255 < tC Then tC = 255
        rgbValues(Idx + 1) = tC
        Cg = rgbValues(Idx + 1)
        tC = Int(Cr * Blr1 + rgbValues(Idx + 2) * Blr2) * BlrFac
        If 255 < tC Then tC = 255
        rgbValues(Idx + 2) = tC
        Cr = rgbValues(Idx + 2)
        tC = Int(Ca * Blr1 + rgbValues(Idx + 3) * Blr2) * BlrFac
        If 255 < tC Then tC = 255
        rgbValues(Idx + 3) = tC
        Ca = rgbValues(Idx + 3)
      Next y
    Next x


  End Sub


#Region "GUI Rank and Name Control Routines"

  Private Sub cmRankF1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmRankF1.Click
    ColorDialog1.Color = CRankF1 : ColorDialog1.ShowDialog() :
    CRankF1 = ColorDialog1.Color : Call GFX_DrawStats() : Call SETTINGS_Save()
  End Sub

  Private Sub cmRankF2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmRankF2.Click
    ColorDialog1.Color = CRankF2 : ColorDialog1.ShowDialog() :
    CRankF2 = ColorDialog1.Color : Call GFX_DrawStats() : Call SETTINGS_Save()
  End Sub

  Private Sub cmRankFD_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmRankFD.Click
    CRankFDir = 0 : Call GFX_DrawStats() : Call SETTINGS_Save()
  End Sub

  Private Sub cmRankFR_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmRankFR.Click
    CRankFDir = 1 : Call GFX_DrawStats() : Call SETTINGS_Save()
  End Sub


  Private Sub cmRankB1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmRankB1.Click
    ColorDialog1.Color = CRankB1 : ColorDialog1.ShowDialog()
    CRankB1 = ColorDialog1.Color
    CRankB1 = Color.FromArgb(Val(cboRankA1.Text) * 0.01 * 255, CRankB1.R, CRankB1.G, CRankB1.B)   'R3.20 Add selected Alpha.
    Call GFX_DrawStats()
    Call SETTINGS_Save()
  End Sub

  Private Sub cmRankB2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmRankB2.Click
    ColorDialog1.Color = CRankB2 : ColorDialog1.ShowDialog()
    CRankB2 = ColorDialog1.Color
    CRankB2 = Color.FromArgb(Val(cboRankA2.Text) * 0.01 * 255, CRankB2.R, CRankB2.G, CRankB2.B)   'R3.20 Add selected Alpha.
    Call GFX_DrawStats()
    Call SETTINGS_Save()
  End Sub

  Private Sub cmRankBD_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmRankBD.Click
    CRankBDir = 0 : Call GFX_DrawStats() : Call SETTINGS_Save()
  End Sub

  Private Sub cmRankBR_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmRankBR.Click
    CRankBDir = 1 : Call GFX_DrawStats() : Call SETTINGS_Save()
  End Sub

  Private Sub cmNameF1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmNameF1.Click
    ColorDialog1.Color = CNameF1 : ColorDialog1.ShowDialog() :
    CNameF1 = ColorDialog1.Color : Call GFX_DrawStats() : Call SETTINGS_Save()
  End Sub

  Private Sub cmNameF2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmNameF2.Click
    ColorDialog1.Color = CNameF2 : ColorDialog1.ShowDialog() :
    CNameF2 = ColorDialog1.Color : Call GFX_DrawStats() : Call SETTINGS_Save()
  End Sub

  Private Sub cmNameFD_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmNameFD.Click
    CNameFDir = 0 : Call GFX_DrawStats() : Call SETTINGS_Save()
  End Sub

  Private Sub cmNameFR_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmNameFR.Click
    CNameFDir = 1 : Call GFX_DrawStats() : Call SETTINGS_Save()
  End Sub

  Private Sub cmNameB1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmNameB1.Click
    ColorDialog1.Color = CNameB1 : ColorDialog1.ShowDialog()
    CNameB1 = ColorDialog1.Color
    CNameB1 = Color.FromArgb(Val(cboNameA1.Text) * 0.01 * 255, CNameB1.R, CNameB1.G, CNameB1.B)   'R3.20 Add selected Alpha.
    Call GFX_DrawStats()
    Call SETTINGS_Save()
  End Sub

  Private Sub cmNameB2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmNameB2.Click
    ColorDialog1.Color = CNameB2 : ColorDialog1.ShowDialog()
    CNameB2 = ColorDialog1.Color
    CNameB2 = Color.FromArgb(Val(cboNameA2.Text) * 0.01 * 255, CNameB2.R, CNameB2.G, CNameB2.B)   'R3.20 Add selected Alpha.
    Call GFX_DrawStats()
    Call SETTINGS_Save()
  End Sub

  Private Sub cmNameBD_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmNameBD.Click
    CNameBDir = 0 : Call GFX_DrawStats() : Call SETTINGS_Save()
  End Sub

  Private Sub cmNameBR_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmNameBR.Click
    CNameBDir = 1 : Call GFX_DrawStats() : Call SETTINGS_Save()
  End Sub

  Private Sub cboNameA1_SelectedIndexChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboNameA1.SelectedIndexChanged
    If FLAG_Loading Then Exit Sub
    CNameB1 = Color.FromArgb(255 * (Val(cboNameA1.Text) * 0.01), CNameB1.R, CNameB1.G, CNameB1.B)
    Call GFX_DrawStats()
    Call SETTINGS_Save()
  End Sub

  Private Sub cboNameA2_SelectedIndexChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboNameA2.SelectedIndexChanged
    If FLAG_Loading Then Exit Sub
    CNameB2 = Color.FromArgb(255 * (Val(cboNameA2.Text) * 0.01), CNameB2.R, CNameB2.G, CNameB2.B)
    Call GFX_DrawStats()
    Call SETTINGS_Save()
  End Sub

  Private Sub cmRank3DC_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmRank3DC.Click
    ColorDialog1.Color = CRank3DC : ColorDialog1.ShowDialog() :
    CRank3DC = ColorDialog1.Color : Call GFX_DrawStats() : Call SETTINGS_Save()
  End Sub

  Private Sub cmName3DC_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmName3DC.Click
    ColorDialog1.Color = CName3DC : ColorDialog1.ShowDialog() :
    CName3DC = ColorDialog1.Color : Call GFX_DrawStats() : Call SETTINGS_Save()
  End Sub

  Private Sub cboRank3D_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboRank3D.SelectedIndexChanged
    If FLAG_Loading Then Exit Sub
    CRank3D = cboRank3D.Text
    SETTINGS_Save()
    Call GFX_DrawStats()
  End Sub

  Private Sub cboName3D_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboName3D.SelectedIndexChanged
    If FLAG_Loading Then Exit Sub
    CName3D = cboName3D.Text
    SETTINGS_Save()
    Call GFX_DrawStats()
  End Sub

#End Region

  Private Sub cmTestData_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmTestData.Click
    Dim A As String

    A = "Selecting this button will place worst case scenario data on the stats page to test your setup." & vbCr & vbCr
    A = A & "Steam names are usually limited to 32 characters." & vbCr
    A = A & "Ranks are usually limited to 5 digits." & vbCr & vbCr
    A = A & "Do you wish to continue?"
    If MsgBox(A, MsgBoxStyle.Information + MsgBoxStyle.DefaultButton1 + MsgBoxStyle.YesNo) = MsgBoxResult.No Then Exit Sub

    'R3.00 Create some worst case scenario data to show n user setup.
    For t = 1 To 8
      PlrName(t) = "12345678901234567890123456789012"
      PlrRank(t) = "88888"
      PlrFact(t) = "05"
    Next

    Call GFX_DrawStats()

  End Sub

  Private Sub pbStats_Click(sender As Object, e As EventArgs) Handles pbStats.Click
    'R3.30 This is only here to get us close when clicking controls in EDIT mode.
  End Sub

  Private Sub pbStats_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles pbStats.MouseDown
    Dim T As Integer
    Dim Hit As Integer

    For T = 1 To 8
      If (LAB_Name(T).Y < e.Y) And (e.Y < LAB_Name(T).Y + LAB_Name(T).Height) Then
        If (LAB_Name(T).X < e.X) And (e.X < LAB_Name(T).X + LAB_Name(T).Width) Then
          Hit = T : Exit For
        End If
      End If
    Next

    If Hit = 0 Then Exit Sub

    'R3.30 Direct user to a STATS web page when mouse is clicked.
    'R2.20 Added CTRL Google Translate lookup.
    If 0 < (Control.ModifierKeys And Keys.Control) Then

      If e.Button = Windows.Forms.MouseButtons.Left Then
        'R2.20 May need this for weird chars. Google doesnt seem to care. System.Uri.EscapeDataString(lbName01.Text)
        If PlrName(T) <> "" Then Process.Start("https://translate.google.com/#view=home&op=translate&sl=auto&tl=en&text=" + PlrName(Hit))
      Else
        'R3.20 Go to Coh2.Org main player card page.
        If PlrSteam(T) <> "" Then Process.Start("https://www.coh2.org/ladders/playercard/steamid/" + PlrSteam(Hit))
      End If

    Else

        If e.Button = Windows.Forms.MouseButtons.Right Then
        If PlrSteam(T) <> "" Then
          'R3.20 Try to select the correct STATS page from.org.
          Select Case PLR_Count()
            Case 4 : Process.Start("https://www.coh2.org/ladders/playercard/viewBoard/2/steamid/" + PlrSteam(Hit))
            Case 6 : Process.Start("https://www.coh2.org/ladders/playercard/viewBoard/3/steamid/" + PlrSteam(Hit))
            Case 8 : Process.Start("https://www.coh2.org/ladders/playercard/viewBoard/4/steamid/" + PlrSteam(Hit))
            Case Else : Process.Start("https://www.coh2.org/ladders/playercard/steamid/" + PlrSteam(Hit))
          End Select
        End If
      Else
        If PlrSteam(T) <> "" Then Process.Start("http://www.companyofheroes.com/leaderboards#profile/steam/" + PlrSteam(Hit) + "/standings")
      End If

    End If

  End Sub

  Private Sub pbStats_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles pbStats.MouseLeave
    If GUI_Active = False Then Exit Sub

    'R3.00 We are not hovering over any players.
    GUI_Mouse_PlrIndex = 0

    Call GFX_DrawStats()
  End Sub


  Private Sub pbStats_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles pbStats.MouseMove
    Dim T As Integer
    Dim Hit As Integer
    Dim LastPlr As Integer


    'R3.00 Store the player we were hovering over if any.
    LastPlr = GUI_Mouse_PlrIndex

    'R3.00 Clear the index to which plr we are moused over.
    GUI_Mouse_PlrIndex = 0

    'R3.00 Loop thru player labels to see if we are hovering on one.
    For T = 1 To 8
      If (LAB_Name(T).Y < e.Y) And (e.Y < LAB_Name(T).Y + LAB_Name(T).Height) Then
        If (LAB_Name(T).X < e.X) And (e.X < LAB_Name(T).X + LAB_Name(T).Width) Then
          Hit = T : Exit For
        End If
      End If
    Next

    'R3.00 If we are hovering a player, Store player # and change mouse cursor.
    If Hit Then
      GUI_Mouse_PlrIndex = Hit
      pbStats.Cursor = Cursors.Hand
    Else
      pbStats.Cursor = Cursors.Default
    End If

    'R3.00 Cut down on Screen Draws. Only update screen when necessary.
    If GUI_Active = True Then
      If (LastPlr <> GUI_Mouse_PlrIndex) Then Call GFX_DrawStats()
    End If

  End Sub

  Private Function PLR_Count() As Integer
    Dim Cnt As Integer
    Dim t As Integer

    For t = 1 To 8
      If PlrName(t) <> "" Then Cnt = Cnt + 1
    Next t

    PLR_Count = Cnt
  End Function

  Private Sub cmLastMatch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmLastMatch.Click
    Dim t As Integer

    For t = 1 To 8
      PlrName(t) = PlrName_Last(t)
      PlrRank(t) = PlrRank_Last(t)
      PlrFact(t) = PlrFact_Last(t)
      PlrSteam(t) = PlrSteam_Last(t)
    Next

    Call GFX_DrawStats()

  End Sub


  Private Sub cmFX3DC_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmFX3DC.Click
    Dim N As Integer

    If FLAG_Loading Then Exit Sub

    ColorDialog1.Color = CFX3DC(1) : ColorDialog1.ShowDialog()

    N = cboFXVar1.SelectedIndex
    If 0 < N Then CFX3DC(N) = ColorDialog1.Color

    Call GFX_DrawStats()
    Call SETTINGS_Save()

  End Sub

  Private Sub cboFX3D_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboFXVar2.SelectedIndexChanged
    Dim N As Integer

    If FLAG_Loading Then Exit Sub

    N = cboFXVar1.SelectedIndex
    If 0 < N Then
      CFX3DVar(N, 2) = cboFXVar2.Text
    End If

    Call GFX_DrawStats()
    Call SETTINGS_Save()

  End Sub

  Private Sub cboFxVar3_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboFxVar3.SelectedIndexChanged
    Dim N As Integer

    If FLAG_Loading Then Exit Sub

    N = cboFXVar1.SelectedIndex
    If 0 < N Then
      CFX3DVar(N, 3) = cboFxVar3.Text
    End If

    Call GFX_DrawStats()
    Call SETTINGS_Save()

  End Sub

  Private Sub cboFxVar4_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboFxVar4.SelectedIndexChanged
    Dim N As Integer

    If FLAG_Loading Then Exit Sub

    N = cboFXVar1.SelectedIndex
    If 0 < N Then
      CFX3DVar(N, 4) = cboFxVar4.Text
    End If

    Call GFX_DrawStats()
    Call SETTINGS_Save()

  End Sub

  Private Sub cboFXMode_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboFXVar1.SelectedIndexChanged
    Dim N As Integer

    If FLAG_Loading Then Exit Sub

    FLAG_Loading = True

    'R3.20 Get the updated FX settings.
    N = cboFXVar1.SelectedIndex

    If 0 < N Then
      cboFXVar2.Text = CFX3DVar(N, 2)
      cboFxVar3.Text = CFX3DVar(N, 3)
      cboFxVar4.Text = CFX3DVar(N, 4)
    End If

    Call GFX_UpdateScreenControls()

    FLAG_Loading = False

  End Sub

  Private Sub GFX_UpdateScreenControls()
    Dim N As Integer

    'R3.20 Dont save data as we are making screen changes only.
    FLAG_Loading = True

    'R3.20 Get the selected FX index (1 - 10).
    N = cboFXVar1.SelectedIndex
    If 0 < N Then
      If CFX3DActive(N) Then
        chkFX.Checked = True
      Else
        chkFX.Checked = False
      End If

      If CFX3DVar(N, 2) = Nothing Then CFX3DVar(N, 2) = cboFXVar2.Items.Item(1)
      cboFXVar2.Text = CFX3DVar(N, 2)

      If CFX3DVar(N, 3) = Nothing Then CFX3DVar(N, 3) = cboFxVar3.Items.Item(1)
      cboFxVar3.Text = CFX3DVar(N, 3)

      If CFX3DVar(N, 4) = Nothing Then CFX3DVar(N, 4) = cboFxVar4.Items.Item(1)
      cboFxVar4.Text = CFX3DVar(N, 4)

    Else
      'R3.20 We have no settings for this yet.
      chkFX.Checked = False
      cboFXVar2.Text = ""
      cboFxVar3.Text = ""
      cboFxVar4.Text = ""
    End If

    'R3.10 This should always be MODE.
    'lbFXVar1.Text = "Mode"

    'R3.10 Reset all FX controls to ON.
    cmFX3DC.Enabled = True
    cboFXVar2.Enabled = True
    cboFxVar3.Enabled = True
    cboFxVar4.Enabled = True

    'R3.10 Adjust screen controls to match  FX mode.
    Select Case cboFXVar1.Text
      Case "None"
        lbFXVar2.Text = "--"
        lbFXVar3.Text = "--"
        lbFXVar4.Text = "--"
        cmFX3DC.Enabled = False
        cboFXVar2.Enabled = False
        cboFxVar3.Enabled = False
        cboFxVar4.Enabled = False
        chkFX.Enabled = False
      Case "Shadow"
        lbFXVar2.Text = "Color/Ang"
        lbFXVar3.Text = "Blur Size"
        lbFXVar4.Text = "Bias"
        chkFX.Enabled = True
      Case "Emboss"
        lbFXVar2.Text = "--"
        lbFXVar3.Text = "Blur Size"
        lbFXVar4.Text = "Bias"
        cmFX3DC.Enabled = False
        cboFXVar2.Enabled = False
        chkFX.Enabled = True
      Case "Lab Blur"
        lbFXVar2.Text = "--"
        lbFXVar3.Text = "Blur Size"
        lbFXVar4.Text = "Bias"
        cmFX3DC.Enabled = False
        cboFXVar2.Enabled = False
        chkFX.Enabled = True
    End Select

    'R3.20 Restore the OK to save settings flag.
    FLAG_Loading = False

  End Sub

  Private Sub cmFXModeHelp_Click(sender As Object, e As EventArgs) Handles cmFXModeHelp.Click
    Dim A As String = ""

    Select Case cboFXVar1.Text
      Case "None"
        A = "No FX mode has been selected. FX setups allow for image based adjustments that may just add that cool touch to your stats text." & vbCr & vbCr
        A += "Each added FX slows the render time. This only happens when selected and updating the stats. While editing, the GUI may feel sluggish on slower PCs."
      Case "Shadow"
        A = "Shadow places a blurred shadow under all text. This helps text pop out more. Depending on the color and angle chosen, the shadow can be dark for a deep shadow or it can be bright giving the effect of light behind the text glowing." & vbCr & vbCr
        A = A & "Blur Size adjust how blurry the shadow is. BIAS adds some brightness and contrast to punch up a neutral shadow." & vbCr & vbCr
        A += "Good start points are: BLUR SIZE (70%), BIAS(5.0%)"
      Case "Emboss"
        A = "Emboss tries to add some 3D depth to the text on screen.  Blurring the embossed image can make the embossing larger and smoother." & vbCr & vbCr
        A += "Embossing multiplies a B/W image and the normal screen. This will always darken the image. Bias Is used to brighten up the darkened image." & vbCr & vbCr
        A += "Using less Blur helps create a a stronger embossing effect." & vbCr & vbCr
        A += "Good start points are: BLUR SIZE (50%), BIAS(5.0%)"
      Case "Lab Blur"
        A = "The rectangles under the rank and player name will be blurred." & vbCr & vbCr
        A += "This tries to make the text stand out from the background a little more." & vbCr & vbCr
        A += "Doing this effect in an image processing progam and used as a background image could create a better image." & vbCr & vbCr
        A += "Good start points are: BLUR SIZE (50%), BIAS(2.0%) and using low background opacity values."
    End Select

    MsgBox(A, MsgBoxStyle.Information, "FX MODE HELP")

  End Sub

  Private Sub chkFX_CheckedChanged(sender As Object, e As EventArgs) Handles chkFX.CheckedChanged
    Dim tState As Boolean
    Dim N As Integer

    If FLAG_Loading Then Exit Sub

    If chkFX.Checked Then
      tState = True
    Else
      tState = False
    End If

    N = cboFXVar1.SelectedIndex

    CFX3DActive(N) = tState

    Call GFX_DrawStats()
    Call SETTINGS_Save()

  End Sub

  Private Sub cmSave_Click(sender As Object, e As EventArgs) Handles cmSave.Click
    Dim fd As SaveFileDialog = New SaveFileDialog()

    fd.Title = "Save Stats Image"
    If PATH_SaveStatsImage <> "" Then fd.InitialDirectory = PATH_SaveStatsImage
    fd.Filter = "Png (*.png)|*.png|Gif (*.gif)|*.gif|Jpeg (*.jpg)|*.jpg"
    fd.FilterIndex = 3

    If fd.ShowDialog() = DialogResult.OK Then

      'R3.30 Save the current stats image to selected filename.
      Try
        pbStats.Image.Save(fd.FileName)
      Catch
        MsgBox("ERROR:" & Err.Description & vbCr & vbCr & "Unable to save the stats image.", vbCritical)
      End Try

      'R3.30 Save the directory we are using for images saves.
      PATH_SaveStatsImage = fd.FileName

      'R3.30 Strip the filename off for init dir on dialog.  
      Dim N As Integer
      N = STRING_FindLastSlash(PATH_SaveStatsImage)
      If 3 < N Then
        PATH_SaveStatsImage = Mid(PATH_SaveStatsImage, 1, N)
      Else
        PATH_SaveStatsImage = ""
      End If

    End If

  End Sub

End Class
