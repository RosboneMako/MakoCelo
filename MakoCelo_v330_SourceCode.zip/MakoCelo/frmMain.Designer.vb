﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMain))
        Me.cmCheckLog = New System.Windows.Forms.Button()
        Me.lbFact01 = New System.Windows.Forms.Label()
        Me.lbFact02 = New System.Windows.Forms.Label()
        Me.lbFact03 = New System.Windows.Forms.Label()
        Me.lbFact04 = New System.Windows.Forms.Label()
        Me.lbFact08 = New System.Windows.Forms.Label()
        Me.lbFact07 = New System.Windows.Forms.Label()
        Me.lbFact06 = New System.Windows.Forms.Label()
        Me.lbFact05 = New System.Windows.Forms.Label()
        Me.lbStatus = New System.Windows.Forms.Label()
        Me.pbFact01 = New System.Windows.Forms.PictureBox()
        Me.pbFact02 = New System.Windows.Forms.PictureBox()
        Me.pbFact03 = New System.Windows.Forms.PictureBox()
        Me.pbFact04 = New System.Windows.Forms.PictureBox()
        Me.pbFact05 = New System.Windows.Forms.PictureBox()
        Me.lbSteam01 = New System.Windows.Forms.Label()
        Me.lbSteam02 = New System.Windows.Forms.Label()
        Me.lbSteam03 = New System.Windows.Forms.Label()
        Me.lbSteam04 = New System.Windows.Forms.Label()
        Me.lbSteam05 = New System.Windows.Forms.Label()
        Me.lbSteam06 = New System.Windows.Forms.Label()
        Me.lbSteam07 = New System.Windows.Forms.Label()
        Me.lbSteam08 = New System.Windows.Forms.Label()
        Me.ColorDialog1 = New System.Windows.Forms.ColorDialog()
        Me.cmFormColor = New System.Windows.Forms.Button()
        Me.cmFormImage = New System.Windows.Forms.Button()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.lbR3 = New System.Windows.Forms.Label()
        Me.cboRankA1 = New System.Windows.Forms.ComboBox()
        Me.cmNoImage = New System.Windows.Forms.Button()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.lbPath = New System.Windows.Forms.Label()
        Me.cmFindLog = New System.Windows.Forms.Button()
        Me.lbHelp01 = New System.Windows.Forms.Label()
        Me.cmScanLog = New System.Windows.Forms.Button()
        Me.cmCopy = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.cmRankFont = New System.Windows.Forms.Button()
        Me.FontDialog1 = New System.Windows.Forms.FontDialog()
        Me.pbPanelDefault01 = New System.Windows.Forms.PictureBox()
        Me.cmAbout = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.cboPageSize = New System.Windows.Forms.ComboBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.cboLayoutY = New System.Windows.Forms.ComboBox()
        Me.gbRank = New System.Windows.Forms.GroupBox()
        Me.cmRank3DC = New System.Windows.Forms.Button()
        Me.lbR5 = New System.Windows.Forms.Label()
        Me.cboRank3D = New System.Windows.Forms.ComboBox()
        Me.cboRankA2 = New System.Windows.Forms.ComboBox()
        Me.lbR4 = New System.Windows.Forms.Label()
        Me.cmRankBR = New System.Windows.Forms.Button()
        Me.cmRankBD = New System.Windows.Forms.Button()
        Me.cmRankFR = New System.Windows.Forms.Button()
        Me.cmRankFD = New System.Windows.Forms.Button()
        Me.cmRankB2 = New System.Windows.Forms.Button()
        Me.cmRankB1 = New System.Windows.Forms.Button()
        Me.lbR2 = New System.Windows.Forms.Label()
        Me.cmRankF2 = New System.Windows.Forms.Button()
        Me.cmRankF1 = New System.Windows.Forms.Button()
        Me.lbR1 = New System.Windows.Forms.Label()
        Me.gbName = New System.Windows.Forms.GroupBox()
        Me.cboNameA2 = New System.Windows.Forms.ComboBox()
        Me.cboNameA1 = New System.Windows.Forms.ComboBox()
        Me.cmName3DC = New System.Windows.Forms.Button()
        Me.lbF5 = New System.Windows.Forms.Label()
        Me.cboName3D = New System.Windows.Forms.ComboBox()
        Me.lbF4 = New System.Windows.Forms.Label()
        Me.lbF3 = New System.Windows.Forms.Label()
        Me.cmNameBR = New System.Windows.Forms.Button()
        Me.cmNameBD = New System.Windows.Forms.Button()
        Me.cmNameFR = New System.Windows.Forms.Button()
        Me.cmNameFD = New System.Windows.Forms.Button()
        Me.cmNameB2 = New System.Windows.Forms.Button()
        Me.cmNameB1 = New System.Windows.Forms.Button()
        Me.lbF2 = New System.Windows.Forms.Label()
        Me.cmNameF2 = New System.Windows.Forms.Button()
        Me.cmNameFont = New System.Windows.Forms.Button()
        Me.cmNameF1 = New System.Windows.Forms.Button()
        Me.lbF1 = New System.Windows.Forms.Label()
        Me.gbBack = New System.Windows.Forms.GroupBox()
        Me.cboScaling = New System.Windows.Forms.ComboBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.gbLayout = New System.Windows.Forms.GroupBox()
        Me.cmSizeRefresh = New System.Windows.Forms.Button()
        Me.cboLayoutX = New System.Windows.Forms.ComboBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.cmGUILite = New System.Windows.Forms.Button()
        Me.cmGUIDark = New System.Windows.Forms.Button()
        Me.pbStats = New System.Windows.Forms.PictureBox()
        Me.cmTestData = New System.Windows.Forms.Button()
        Me.cmLastMatch = New System.Windows.Forms.Button()
        Me.gbFX = New System.Windows.Forms.GroupBox()
        Me.chkFX = New System.Windows.Forms.CheckBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.cmFXModeHelp = New System.Windows.Forms.Button()
        Me.cboFXVar1 = New System.Windows.Forms.ComboBox()
        Me.lbFXVar1 = New System.Windows.Forms.Label()
        Me.cboFxVar3 = New System.Windows.Forms.ComboBox()
        Me.lbFXVar3 = New System.Windows.Forms.Label()
        Me.cboFxVar4 = New System.Windows.Forms.ComboBox()
        Me.cmFX3DC = New System.Windows.Forms.Button()
        Me.cboFXVar2 = New System.Windows.Forms.ComboBox()
        Me.lbFXVar2 = New System.Windows.Forms.Label()
        Me.lbFXVar4 = New System.Windows.Forms.Label()
        Me.lbError1 = New System.Windows.Forms.Label()
        Me.lbError2 = New System.Windows.Forms.Label()
        Me.cmSave = New System.Windows.Forms.Button()
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
        CType(Me.pbFact01, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbFact02, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbFact03, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbFact04, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbFact05, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbPanelDefault01, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gbRank.SuspendLayout()
        Me.gbName.SuspendLayout()
        Me.gbBack.SuspendLayout()
        Me.gbLayout.SuspendLayout()
        CType(Me.pbStats, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gbFX.SuspendLayout()
        Me.SuspendLayout()
        '
        'cmCheckLog
        '
        Me.cmCheckLog.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmCheckLog.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmCheckLog.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmCheckLog.ForeColor = System.Drawing.Color.Black
        Me.cmCheckLog.Location = New System.Drawing.Point(10, 52)
        Me.cmCheckLog.Name = "cmCheckLog"
        Me.cmCheckLog.Size = New System.Drawing.Size(111, 26)
        Me.cmCheckLog.TabIndex = 1
        Me.cmCheckLog.Text = "Check Log File"
        Me.cmCheckLog.UseVisualStyleBackColor = False
        '
        'lbFact01
        '
        Me.lbFact01.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lbFact01.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbFact01.Location = New System.Drawing.Point(1199, 12)
        Me.lbFact01.Name = "lbFact01"
        Me.lbFact01.Size = New System.Drawing.Size(50, 23)
        Me.lbFact01.TabIndex = 9
        Me.lbFact01.Text = "OKW"
        Me.lbFact01.Visible = False
        '
        'lbFact02
        '
        Me.lbFact02.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lbFact02.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbFact02.Location = New System.Drawing.Point(1199, 35)
        Me.lbFact02.Name = "lbFact02"
        Me.lbFact02.Size = New System.Drawing.Size(50, 23)
        Me.lbFact02.TabIndex = 10
        Me.lbFact02.Text = "Brit"
        Me.lbFact02.Visible = False
        '
        'lbFact03
        '
        Me.lbFact03.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lbFact03.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbFact03.Location = New System.Drawing.Point(1199, 58)
        Me.lbFact03.Name = "lbFact03"
        Me.lbFact03.Size = New System.Drawing.Size(50, 23)
        Me.lbFact03.TabIndex = 11
        Me.lbFact03.Text = "Brit"
        Me.lbFact03.Visible = False
        '
        'lbFact04
        '
        Me.lbFact04.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lbFact04.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbFact04.Location = New System.Drawing.Point(1199, 81)
        Me.lbFact04.Name = "lbFact04"
        Me.lbFact04.Size = New System.Drawing.Size(50, 23)
        Me.lbFact04.TabIndex = 12
        Me.lbFact04.Text = "Brit"
        Me.lbFact04.Visible = False
        '
        'lbFact08
        '
        Me.lbFact08.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lbFact08.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbFact08.Location = New System.Drawing.Point(1255, 81)
        Me.lbFact08.Name = "lbFact08"
        Me.lbFact08.Size = New System.Drawing.Size(49, 23)
        Me.lbFact08.TabIndex = 24
        Me.lbFact08.Text = "Brit"
        Me.lbFact08.Visible = False
        '
        'lbFact07
        '
        Me.lbFact07.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lbFact07.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbFact07.Location = New System.Drawing.Point(1255, 58)
        Me.lbFact07.Name = "lbFact07"
        Me.lbFact07.Size = New System.Drawing.Size(49, 23)
        Me.lbFact07.TabIndex = 23
        Me.lbFact07.Text = "Brit"
        Me.lbFact07.Visible = False
        '
        'lbFact06
        '
        Me.lbFact06.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lbFact06.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbFact06.Location = New System.Drawing.Point(1255, 35)
        Me.lbFact06.Name = "lbFact06"
        Me.lbFact06.Size = New System.Drawing.Size(49, 23)
        Me.lbFact06.TabIndex = 22
        Me.lbFact06.Text = "Brit"
        Me.lbFact06.Visible = False
        '
        'lbFact05
        '
        Me.lbFact05.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lbFact05.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbFact05.Location = New System.Drawing.Point(1255, 12)
        Me.lbFact05.Name = "lbFact05"
        Me.lbFact05.Size = New System.Drawing.Size(49, 23)
        Me.lbFact05.TabIndex = 21
        Me.lbFact05.Text = "OKW"
        Me.lbFact05.Visible = False
        '
        'lbStatus
        '
        Me.lbStatus.BackColor = System.Drawing.Color.Silver
        Me.lbStatus.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lbStatus.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbStatus.ForeColor = System.Drawing.Color.Black
        Me.lbStatus.Location = New System.Drawing.Point(924, 29)
        Me.lbStatus.Name = "lbStatus"
        Me.lbStatus.Size = New System.Drawing.Size(131, 18)
        Me.lbStatus.TabIndex = 25
        Me.lbStatus.Text = "Ready."
        Me.lbStatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'pbFact01
        '
        Me.pbFact01.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.pbFact01.Image = CType(resources.GetObject("pbFact01.Image"), System.Drawing.Image)
        Me.pbFact01.Location = New System.Drawing.Point(1131, 114)
        Me.pbFact01.Name = "pbFact01"
        Me.pbFact01.Size = New System.Drawing.Size(23, 23)
        Me.pbFact01.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbFact01.TabIndex = 26
        Me.pbFact01.TabStop = False
        Me.pbFact01.Visible = False
        '
        'pbFact02
        '
        Me.pbFact02.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.pbFact02.Image = CType(resources.GetObject("pbFact02.Image"), System.Drawing.Image)
        Me.pbFact02.Location = New System.Drawing.Point(1160, 114)
        Me.pbFact02.Name = "pbFact02"
        Me.pbFact02.Size = New System.Drawing.Size(23, 23)
        Me.pbFact02.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbFact02.TabIndex = 27
        Me.pbFact02.TabStop = False
        Me.pbFact02.Visible = False
        '
        'pbFact03
        '
        Me.pbFact03.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.pbFact03.Image = CType(resources.GetObject("pbFact03.Image"), System.Drawing.Image)
        Me.pbFact03.Location = New System.Drawing.Point(1189, 114)
        Me.pbFact03.Name = "pbFact03"
        Me.pbFact03.Size = New System.Drawing.Size(23, 23)
        Me.pbFact03.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbFact03.TabIndex = 28
        Me.pbFact03.TabStop = False
        Me.pbFact03.Visible = False
        '
        'pbFact04
        '
        Me.pbFact04.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.pbFact04.Image = CType(resources.GetObject("pbFact04.Image"), System.Drawing.Image)
        Me.pbFact04.Location = New System.Drawing.Point(1218, 114)
        Me.pbFact04.Name = "pbFact04"
        Me.pbFact04.Size = New System.Drawing.Size(23, 23)
        Me.pbFact04.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbFact04.TabIndex = 29
        Me.pbFact04.TabStop = False
        Me.pbFact04.Visible = False
        '
        'pbFact05
        '
        Me.pbFact05.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.pbFact05.Image = CType(resources.GetObject("pbFact05.Image"), System.Drawing.Image)
        Me.pbFact05.Location = New System.Drawing.Point(1247, 114)
        Me.pbFact05.Name = "pbFact05"
        Me.pbFact05.Size = New System.Drawing.Size(23, 23)
        Me.pbFact05.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbFact05.TabIndex = 30
        Me.pbFact05.TabStop = False
        Me.pbFact05.Visible = False
        '
        'lbSteam01
        '
        Me.lbSteam01.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lbSteam01.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbSteam01.Location = New System.Drawing.Point(1325, 12)
        Me.lbSteam01.Name = "lbSteam01"
        Me.lbSteam01.Size = New System.Drawing.Size(50, 23)
        Me.lbSteam01.TabIndex = 39
        Me.lbSteam01.Visible = False
        '
        'lbSteam02
        '
        Me.lbSteam02.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lbSteam02.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbSteam02.Location = New System.Drawing.Point(1325, 35)
        Me.lbSteam02.Name = "lbSteam02"
        Me.lbSteam02.Size = New System.Drawing.Size(50, 23)
        Me.lbSteam02.TabIndex = 40
        Me.lbSteam02.Visible = False
        '
        'lbSteam03
        '
        Me.lbSteam03.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lbSteam03.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbSteam03.Location = New System.Drawing.Point(1325, 58)
        Me.lbSteam03.Name = "lbSteam03"
        Me.lbSteam03.Size = New System.Drawing.Size(50, 23)
        Me.lbSteam03.TabIndex = 41
        Me.lbSteam03.Visible = False
        '
        'lbSteam04
        '
        Me.lbSteam04.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lbSteam04.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbSteam04.Location = New System.Drawing.Point(1325, 81)
        Me.lbSteam04.Name = "lbSteam04"
        Me.lbSteam04.Size = New System.Drawing.Size(50, 23)
        Me.lbSteam04.TabIndex = 42
        Me.lbSteam04.Visible = False
        '
        'lbSteam05
        '
        Me.lbSteam05.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lbSteam05.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbSteam05.Location = New System.Drawing.Point(1379, 12)
        Me.lbSteam05.Name = "lbSteam05"
        Me.lbSteam05.Size = New System.Drawing.Size(50, 23)
        Me.lbSteam05.TabIndex = 43
        Me.lbSteam05.Visible = False
        '
        'lbSteam06
        '
        Me.lbSteam06.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lbSteam06.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbSteam06.Location = New System.Drawing.Point(1379, 35)
        Me.lbSteam06.Name = "lbSteam06"
        Me.lbSteam06.Size = New System.Drawing.Size(50, 23)
        Me.lbSteam06.TabIndex = 44
        Me.lbSteam06.Visible = False
        '
        'lbSteam07
        '
        Me.lbSteam07.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lbSteam07.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbSteam07.Location = New System.Drawing.Point(1379, 58)
        Me.lbSteam07.Name = "lbSteam07"
        Me.lbSteam07.Size = New System.Drawing.Size(50, 23)
        Me.lbSteam07.TabIndex = 45
        Me.lbSteam07.Visible = False
        '
        'lbSteam08
        '
        Me.lbSteam08.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lbSteam08.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbSteam08.Location = New System.Drawing.Point(1379, 81)
        Me.lbSteam08.Name = "lbSteam08"
        Me.lbSteam08.Size = New System.Drawing.Size(50, 23)
        Me.lbSteam08.TabIndex = 46
        Me.lbSteam08.Visible = False
        '
        'cmFormColor
        '
        Me.cmFormColor.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmFormColor.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmFormColor.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmFormColor.ForeColor = System.Drawing.Color.Black
        Me.cmFormColor.Location = New System.Drawing.Point(6, 19)
        Me.cmFormColor.Name = "cmFormColor"
        Me.cmFormColor.Size = New System.Drawing.Size(118, 26)
        Me.cmFormColor.TabIndex = 11
        Me.cmFormColor.Text = "Panel Color"
        Me.cmFormColor.UseVisualStyleBackColor = False
        '
        'cmFormImage
        '
        Me.cmFormImage.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmFormImage.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmFormImage.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmFormImage.ForeColor = System.Drawing.Color.Black
        Me.cmFormImage.Location = New System.Drawing.Point(6, 51)
        Me.cmFormImage.Name = "cmFormImage"
        Me.cmFormImage.Size = New System.Drawing.Size(118, 26)
        Me.cmFormImage.TabIndex = 12
        Me.cmFormImage.Text = "Panel Image"
        Me.cmFormImage.UseVisualStyleBackColor = False
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'lbR3
        '
        Me.lbR3.AutoSize = True
        Me.lbR3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.lbR3.Location = New System.Drawing.Point(6, 68)
        Me.lbR3.Name = "lbR3"
        Me.lbR3.Size = New System.Drawing.Size(52, 13)
        Me.lbR3.TabIndex = 53
        Me.lbR3.Text = "Opacity 1"
        '
        'cboRankA1
        '
        Me.cboRankA1.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.cboRankA1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboRankA1.ForeColor = System.Drawing.Color.White
        Me.cboRankA1.FormattingEnabled = True
        Me.cboRankA1.Location = New System.Drawing.Point(64, 64)
        Me.cboRankA1.Name = "cboRankA1"
        Me.cboRankA1.Size = New System.Drawing.Size(71, 21)
        Me.cboRankA1.TabIndex = 6
        '
        'cmNoImage
        '
        Me.cmNoImage.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmNoImage.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmNoImage.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmNoImage.ForeColor = System.Drawing.Color.Black
        Me.cmNoImage.Location = New System.Drawing.Point(6, 83)
        Me.cmNoImage.Name = "cmNoImage"
        Me.cmNoImage.Size = New System.Drawing.Size(118, 26)
        Me.cmNoImage.TabIndex = 13
        Me.cmNoImage.Text = "No Image"
        Me.cmNoImage.UseVisualStyleBackColor = False
        '
        'Timer1
        '
        Me.Timer1.Interval = 1000
        '
        'lbPath
        '
        Me.lbPath.BackColor = System.Drawing.Color.Silver
        Me.lbPath.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lbPath.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbPath.ForeColor = System.Drawing.Color.Black
        Me.lbPath.Location = New System.Drawing.Point(1131, 164)
        Me.lbPath.Name = "lbPath"
        Me.lbPath.Size = New System.Drawing.Size(630, 18)
        Me.lbPath.TabIndex = 56
        Me.lbPath.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.lbPath.Visible = False
        '
        'cmFindLog
        '
        Me.cmFindLog.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmFindLog.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmFindLog.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmFindLog.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmFindLog.ForeColor = System.Drawing.Color.Black
        Me.cmFindLog.Location = New System.Drawing.Point(10, 18)
        Me.cmFindLog.Name = "cmFindLog"
        Me.cmFindLog.Size = New System.Drawing.Size(111, 26)
        Me.cmFindLog.TabIndex = 0
        Me.cmFindLog.Text = "Find Log File"
        Me.cmFindLog.UseVisualStyleBackColor = False
        '
        'lbHelp01
        '
        Me.lbHelp01.BackColor = System.Drawing.Color.Transparent
        Me.lbHelp01.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbHelp01.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lbHelp01.Location = New System.Drawing.Point(1128, 146)
        Me.lbHelp01.Name = "lbHelp01"
        Me.lbHelp01.Size = New System.Drawing.Size(441, 18)
        Me.lbHelp01.TabIndex = 58
        Me.lbHelp01.Text = "This program parses the Warnings.Log file. It must be located before checking the" &
    " file."
        Me.lbHelp01.Visible = False
        '
        'cmScanLog
        '
        Me.cmScanLog.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmScanLog.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmScanLog.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmScanLog.ForeColor = System.Drawing.Color.Black
        Me.cmScanLog.Location = New System.Drawing.Point(10, 122)
        Me.cmScanLog.Name = "cmScanLog"
        Me.cmScanLog.Size = New System.Drawing.Size(111, 62)
        Me.cmScanLog.TabIndex = 2
        Me.cmScanLog.Text = "Scan log every 10s"
        Me.cmScanLog.UseVisualStyleBackColor = False
        '
        'cmCopy
        '
        Me.cmCopy.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmCopy.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmCopy.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmCopy.ForeColor = System.Drawing.Color.Black
        Me.cmCopy.Location = New System.Drawing.Point(6, 139)
        Me.cmCopy.Name = "cmCopy"
        Me.cmCopy.Size = New System.Drawing.Size(55, 26)
        Me.cmCopy.TabIndex = 20
        Me.cmCopy.Text = "Copy"
        Me.cmCopy.UseVisualStyleBackColor = False
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(921, 14)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(134, 13)
        Me.Label2.TabIndex = 61
        Me.Label2.Text = "Scan Status"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cmRankFont
        '
        Me.cmRankFont.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmRankFont.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmRankFont.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmRankFont.ForeColor = System.Drawing.Color.Black
        Me.cmRankFont.Location = New System.Drawing.Point(6, 139)
        Me.cmRankFont.Name = "cmRankFont"
        Me.cmRankFont.Size = New System.Drawing.Size(129, 26)
        Me.cmRankFont.TabIndex = 5
        Me.cmRankFont.Text = "Font"
        Me.cmRankFont.UseVisualStyleBackColor = False
        '
        'pbPanelDefault01
        '
        Me.pbPanelDefault01.InitialImage = Nothing
        Me.pbPanelDefault01.Location = New System.Drawing.Point(1131, 12)
        Me.pbPanelDefault01.Name = "pbPanelDefault01"
        Me.pbPanelDefault01.Size = New System.Drawing.Size(62, 45)
        Me.pbPanelDefault01.TabIndex = 63
        Me.pbPanelDefault01.TabStop = False
        Me.pbPanelDefault01.Visible = False
        '
        'cmAbout
        '
        Me.cmAbout.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmAbout.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmAbout.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmAbout.ForeColor = System.Drawing.Color.Black
        Me.cmAbout.Location = New System.Drawing.Point(936, 55)
        Me.cmAbout.Name = "cmAbout"
        Me.cmAbout.Size = New System.Drawing.Size(102, 26)
        Me.cmAbout.TabIndex = 19
        Me.cmAbout.Text = "About"
        Me.cmAbout.UseVisualStyleBackColor = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.Label3.Location = New System.Drawing.Point(6, 21)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(55, 13)
        Me.Label3.TabIndex = 66
        Me.Label3.Text = "Page Size"
        '
        'cboPageSize
        '
        Me.cboPageSize.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.cboPageSize.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboPageSize.ForeColor = System.Drawing.Color.White
        Me.cboPageSize.FormattingEnabled = True
        Me.cboPageSize.Location = New System.Drawing.Point(67, 19)
        Me.cboPageSize.Name = "cboPageSize"
        Me.cboPageSize.Size = New System.Drawing.Size(121, 21)
        Me.cboPageSize.TabIndex = 15
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.Label4.Location = New System.Drawing.Point(6, 53)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(49, 13)
        Me.Label4.TabIndex = 70
        Me.Label4.Text = "Y Layout"
        '
        'cboLayoutY
        '
        Me.cboLayoutY.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.cboLayoutY.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboLayoutY.ForeColor = System.Drawing.Color.White
        Me.cboLayoutY.FormattingEnabled = True
        Me.cboLayoutY.Location = New System.Drawing.Point(67, 51)
        Me.cboLayoutY.Name = "cboLayoutY"
        Me.cboLayoutY.Size = New System.Drawing.Size(121, 21)
        Me.cboLayoutY.TabIndex = 16
        '
        'gbRank
        '
        Me.gbRank.Controls.Add(Me.cmRank3DC)
        Me.gbRank.Controls.Add(Me.lbR5)
        Me.gbRank.Controls.Add(Me.cboRank3D)
        Me.gbRank.Controls.Add(Me.cboRankA2)
        Me.gbRank.Controls.Add(Me.lbR4)
        Me.gbRank.Controls.Add(Me.cmRankBR)
        Me.gbRank.Controls.Add(Me.cmRankBD)
        Me.gbRank.Controls.Add(Me.cmRankFR)
        Me.gbRank.Controls.Add(Me.cmRankFD)
        Me.gbRank.Controls.Add(Me.cmRankB2)
        Me.gbRank.Controls.Add(Me.cmRankB1)
        Me.gbRank.Controls.Add(Me.lbR2)
        Me.gbRank.Controls.Add(Me.cmRankF2)
        Me.gbRank.Controls.Add(Me.cmRankFont)
        Me.gbRank.Controls.Add(Me.cmRankF1)
        Me.gbRank.Controls.Add(Me.lbR1)
        Me.gbRank.Controls.Add(Me.lbR3)
        Me.gbRank.Controls.Add(Me.cboRankA1)
        Me.gbRank.ForeColor = System.Drawing.Color.Black
        Me.gbRank.Location = New System.Drawing.Point(130, 13)
        Me.gbRank.Name = "gbRank"
        Me.gbRank.Size = New System.Drawing.Size(143, 172)
        Me.gbRank.TabIndex = 73
        Me.gbRank.TabStop = False
        Me.gbRank.Text = "Rank"
        '
        'cmRank3DC
        '
        Me.cmRank3DC.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmRank3DC.Location = New System.Drawing.Point(64, 112)
        Me.cmRank3DC.Name = "cmRank3DC"
        Me.cmRank3DC.Size = New System.Drawing.Size(21, 21)
        Me.cmRank3DC.TabIndex = 68
        Me.cmRank3DC.Text = "1"
        Me.cmRank3DC.UseVisualStyleBackColor = True
        '
        'lbR5
        '
        Me.lbR5.AutoSize = True
        Me.lbR5.ForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.lbR5.Location = New System.Drawing.Point(6, 115)
        Me.lbR5.Name = "lbR5"
        Me.lbR5.Size = New System.Drawing.Size(46, 13)
        Me.lbR5.TabIndex = 67
        Me.lbR5.Text = "Shadow"
        '
        'cboRank3D
        '
        Me.cboRank3D.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.cboRank3D.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboRank3D.ForeColor = System.Drawing.Color.White
        Me.cboRank3D.FormattingEnabled = True
        Me.cboRank3D.Location = New System.Drawing.Point(89, 112)
        Me.cboRank3D.Name = "cboRank3D"
        Me.cboRank3D.Size = New System.Drawing.Size(46, 21)
        Me.cboRank3D.TabIndex = 66
        '
        'cboRankA2
        '
        Me.cboRankA2.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.cboRankA2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboRankA2.ForeColor = System.Drawing.Color.White
        Me.cboRankA2.FormattingEnabled = True
        Me.cboRankA2.Location = New System.Drawing.Point(64, 88)
        Me.cboRankA2.Name = "cboRankA2"
        Me.cboRankA2.Size = New System.Drawing.Size(71, 21)
        Me.cboRankA2.TabIndex = 65
        '
        'lbR4
        '
        Me.lbR4.AutoSize = True
        Me.lbR4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.lbR4.Location = New System.Drawing.Point(6, 92)
        Me.lbR4.Name = "lbR4"
        Me.lbR4.Size = New System.Drawing.Size(52, 13)
        Me.lbR4.TabIndex = 64
        Me.lbR4.Text = "Opacity 2"
        '
        'cmRankBR
        '
        Me.cmRankBR.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmRankBR.Location = New System.Drawing.Point(114, 39)
        Me.cmRankBR.Name = "cmRankBR"
        Me.cmRankBR.Size = New System.Drawing.Size(20, 21)
        Me.cmRankBR.TabIndex = 63
        Me.cmRankBR.Text = ">"
        Me.cmRankBR.UseVisualStyleBackColor = True
        '
        'cmRankBD
        '
        Me.cmRankBD.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmRankBD.Location = New System.Drawing.Point(89, 39)
        Me.cmRankBD.Name = "cmRankBD"
        Me.cmRankBD.Size = New System.Drawing.Size(20, 21)
        Me.cmRankBD.TabIndex = 62
        Me.cmRankBD.Text = "˅"
        Me.cmRankBD.UseVisualStyleBackColor = True
        '
        'cmRankFR
        '
        Me.cmRankFR.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmRankFR.Location = New System.Drawing.Point(114, 15)
        Me.cmRankFR.Name = "cmRankFR"
        Me.cmRankFR.Size = New System.Drawing.Size(20, 21)
        Me.cmRankFR.TabIndex = 61
        Me.cmRankFR.Text = ">"
        Me.cmRankFR.UseVisualStyleBackColor = True
        '
        'cmRankFD
        '
        Me.cmRankFD.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmRankFD.Location = New System.Drawing.Point(89, 15)
        Me.cmRankFD.Name = "cmRankFD"
        Me.cmRankFD.Size = New System.Drawing.Size(20, 21)
        Me.cmRankFD.TabIndex = 60
        Me.cmRankFD.Text = "˅"
        Me.cmRankFD.UseVisualStyleBackColor = True
        '
        'cmRankB2
        '
        Me.cmRankB2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmRankB2.Location = New System.Drawing.Point(64, 39)
        Me.cmRankB2.Name = "cmRankB2"
        Me.cmRankB2.Size = New System.Drawing.Size(20, 21)
        Me.cmRankB2.TabIndex = 59
        Me.cmRankB2.Text = "2"
        Me.cmRankB2.UseVisualStyleBackColor = True
        '
        'cmRankB1
        '
        Me.cmRankB1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmRankB1.Location = New System.Drawing.Point(39, 39)
        Me.cmRankB1.Name = "cmRankB1"
        Me.cmRankB1.Size = New System.Drawing.Size(20, 21)
        Me.cmRankB1.TabIndex = 58
        Me.cmRankB1.Text = "1"
        Me.cmRankB1.UseVisualStyleBackColor = True
        '
        'lbR2
        '
        Me.lbR2.AutoSize = True
        Me.lbR2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.lbR2.Location = New System.Drawing.Point(6, 42)
        Me.lbR2.Name = "lbR2"
        Me.lbR2.Size = New System.Drawing.Size(32, 13)
        Me.lbR2.TabIndex = 57
        Me.lbR2.Text = "Back"
        '
        'cmRankF2
        '
        Me.cmRankF2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmRankF2.Location = New System.Drawing.Point(64, 15)
        Me.cmRankF2.Name = "cmRankF2"
        Me.cmRankF2.Size = New System.Drawing.Size(20, 21)
        Me.cmRankF2.TabIndex = 56
        Me.cmRankF2.Text = "2"
        Me.cmRankF2.UseVisualStyleBackColor = True
        '
        'cmRankF1
        '
        Me.cmRankF1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmRankF1.Location = New System.Drawing.Point(39, 15)
        Me.cmRankF1.Name = "cmRankF1"
        Me.cmRankF1.Size = New System.Drawing.Size(20, 21)
        Me.cmRankF1.TabIndex = 55
        Me.cmRankF1.Text = "1"
        Me.cmRankF1.UseVisualStyleBackColor = True
        '
        'lbR1
        '
        Me.lbR1.AutoSize = True
        Me.lbR1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.lbR1.Location = New System.Drawing.Point(6, 18)
        Me.lbR1.Name = "lbR1"
        Me.lbR1.Size = New System.Drawing.Size(28, 13)
        Me.lbR1.TabIndex = 54
        Me.lbR1.Text = "Font"
        '
        'gbName
        '
        Me.gbName.Controls.Add(Me.cboNameA2)
        Me.gbName.Controls.Add(Me.cboNameA1)
        Me.gbName.Controls.Add(Me.cmName3DC)
        Me.gbName.Controls.Add(Me.lbF5)
        Me.gbName.Controls.Add(Me.cboName3D)
        Me.gbName.Controls.Add(Me.lbF4)
        Me.gbName.Controls.Add(Me.lbF3)
        Me.gbName.Controls.Add(Me.cmNameBR)
        Me.gbName.Controls.Add(Me.cmNameBD)
        Me.gbName.Controls.Add(Me.cmNameFR)
        Me.gbName.Controls.Add(Me.cmNameFD)
        Me.gbName.Controls.Add(Me.cmNameB2)
        Me.gbName.Controls.Add(Me.cmNameB1)
        Me.gbName.Controls.Add(Me.lbF2)
        Me.gbName.Controls.Add(Me.cmNameF2)
        Me.gbName.Controls.Add(Me.cmNameFont)
        Me.gbName.Controls.Add(Me.cmNameF1)
        Me.gbName.Controls.Add(Me.lbF1)
        Me.gbName.ForeColor = System.Drawing.Color.Black
        Me.gbName.Location = New System.Drawing.Point(279, 13)
        Me.gbName.Name = "gbName"
        Me.gbName.Size = New System.Drawing.Size(143, 172)
        Me.gbName.TabIndex = 74
        Me.gbName.TabStop = False
        Me.gbName.Text = "Name"
        '
        'cboNameA2
        '
        Me.cboNameA2.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.cboNameA2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboNameA2.ForeColor = System.Drawing.Color.White
        Me.cboNameA2.FormattingEnabled = True
        Me.cboNameA2.Location = New System.Drawing.Point(64, 88)
        Me.cboNameA2.Name = "cboNameA2"
        Me.cboNameA2.Size = New System.Drawing.Size(71, 21)
        Me.cboNameA2.TabIndex = 82
        '
        'cboNameA1
        '
        Me.cboNameA1.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.cboNameA1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboNameA1.ForeColor = System.Drawing.Color.White
        Me.cboNameA1.FormattingEnabled = True
        Me.cboNameA1.Location = New System.Drawing.Point(64, 64)
        Me.cboNameA1.Name = "cboNameA1"
        Me.cboNameA1.Size = New System.Drawing.Size(71, 21)
        Me.cboNameA1.TabIndex = 81
        '
        'cmName3DC
        '
        Me.cmName3DC.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmName3DC.Location = New System.Drawing.Point(64, 112)
        Me.cmName3DC.Name = "cmName3DC"
        Me.cmName3DC.Size = New System.Drawing.Size(21, 21)
        Me.cmName3DC.TabIndex = 80
        Me.cmName3DC.Text = "1"
        Me.cmName3DC.UseVisualStyleBackColor = True
        '
        'lbF5
        '
        Me.lbF5.AutoSize = True
        Me.lbF5.ForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.lbF5.Location = New System.Drawing.Point(6, 115)
        Me.lbF5.Name = "lbF5"
        Me.lbF5.Size = New System.Drawing.Size(46, 13)
        Me.lbF5.TabIndex = 79
        Me.lbF5.Text = "Shadow"
        '
        'cboName3D
        '
        Me.cboName3D.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.cboName3D.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboName3D.ForeColor = System.Drawing.Color.White
        Me.cboName3D.FormattingEnabled = True
        Me.cboName3D.Location = New System.Drawing.Point(89, 112)
        Me.cboName3D.Name = "cboName3D"
        Me.cboName3D.Size = New System.Drawing.Size(46, 21)
        Me.cboName3D.TabIndex = 78
        '
        'lbF4
        '
        Me.lbF4.AutoSize = True
        Me.lbF4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.lbF4.Location = New System.Drawing.Point(6, 92)
        Me.lbF4.Name = "lbF4"
        Me.lbF4.Size = New System.Drawing.Size(52, 13)
        Me.lbF4.TabIndex = 76
        Me.lbF4.Text = "Opacity 2"
        '
        'lbF3
        '
        Me.lbF3.AutoSize = True
        Me.lbF3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.lbF3.Location = New System.Drawing.Point(6, 68)
        Me.lbF3.Name = "lbF3"
        Me.lbF3.Size = New System.Drawing.Size(52, 13)
        Me.lbF3.TabIndex = 75
        Me.lbF3.Text = "Opacity 1"
        '
        'cmNameBR
        '
        Me.cmNameBR.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmNameBR.Location = New System.Drawing.Point(114, 39)
        Me.cmNameBR.Name = "cmNameBR"
        Me.cmNameBR.Size = New System.Drawing.Size(20, 21)
        Me.cmNameBR.TabIndex = 73
        Me.cmNameBR.Text = ">"
        Me.cmNameBR.UseVisualStyleBackColor = True
        '
        'cmNameBD
        '
        Me.cmNameBD.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmNameBD.Location = New System.Drawing.Point(89, 39)
        Me.cmNameBD.Name = "cmNameBD"
        Me.cmNameBD.Size = New System.Drawing.Size(20, 21)
        Me.cmNameBD.TabIndex = 72
        Me.cmNameBD.Text = "˅"
        Me.cmNameBD.UseVisualStyleBackColor = True
        '
        'cmNameFR
        '
        Me.cmNameFR.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmNameFR.Location = New System.Drawing.Point(114, 15)
        Me.cmNameFR.Name = "cmNameFR"
        Me.cmNameFR.Size = New System.Drawing.Size(20, 21)
        Me.cmNameFR.TabIndex = 71
        Me.cmNameFR.Text = ">"
        Me.cmNameFR.UseVisualStyleBackColor = True
        '
        'cmNameFD
        '
        Me.cmNameFD.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmNameFD.Location = New System.Drawing.Point(89, 15)
        Me.cmNameFD.Name = "cmNameFD"
        Me.cmNameFD.Size = New System.Drawing.Size(20, 21)
        Me.cmNameFD.TabIndex = 70
        Me.cmNameFD.Text = "˅"
        Me.cmNameFD.UseVisualStyleBackColor = True
        '
        'cmNameB2
        '
        Me.cmNameB2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmNameB2.Location = New System.Drawing.Point(64, 39)
        Me.cmNameB2.Name = "cmNameB2"
        Me.cmNameB2.Size = New System.Drawing.Size(20, 21)
        Me.cmNameB2.TabIndex = 69
        Me.cmNameB2.Text = "2"
        Me.cmNameB2.UseVisualStyleBackColor = True
        '
        'cmNameB1
        '
        Me.cmNameB1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmNameB1.Location = New System.Drawing.Point(39, 39)
        Me.cmNameB1.Name = "cmNameB1"
        Me.cmNameB1.Size = New System.Drawing.Size(20, 21)
        Me.cmNameB1.TabIndex = 68
        Me.cmNameB1.Text = "1"
        Me.cmNameB1.UseVisualStyleBackColor = True
        '
        'lbF2
        '
        Me.lbF2.AutoSize = True
        Me.lbF2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.lbF2.Location = New System.Drawing.Point(4, 41)
        Me.lbF2.Name = "lbF2"
        Me.lbF2.Size = New System.Drawing.Size(32, 13)
        Me.lbF2.TabIndex = 67
        Me.lbF2.Text = "Back"
        '
        'cmNameF2
        '
        Me.cmNameF2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmNameF2.Location = New System.Drawing.Point(64, 15)
        Me.cmNameF2.Name = "cmNameF2"
        Me.cmNameF2.Size = New System.Drawing.Size(20, 21)
        Me.cmNameF2.TabIndex = 66
        Me.cmNameF2.Text = "2"
        Me.cmNameF2.UseVisualStyleBackColor = True
        '
        'cmNameFont
        '
        Me.cmNameFont.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmNameFont.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmNameFont.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmNameFont.ForeColor = System.Drawing.Color.Black
        Me.cmNameFont.Location = New System.Drawing.Point(6, 139)
        Me.cmNameFont.Name = "cmNameFont"
        Me.cmNameFont.Size = New System.Drawing.Size(129, 26)
        Me.cmNameFont.TabIndex = 9
        Me.cmNameFont.Text = "Font"
        Me.cmNameFont.UseVisualStyleBackColor = False
        '
        'cmNameF1
        '
        Me.cmNameF1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmNameF1.Location = New System.Drawing.Point(39, 15)
        Me.cmNameF1.Name = "cmNameF1"
        Me.cmNameF1.Size = New System.Drawing.Size(20, 21)
        Me.cmNameF1.TabIndex = 65
        Me.cmNameF1.Text = "1"
        Me.cmNameF1.UseVisualStyleBackColor = True
        '
        'lbF1
        '
        Me.lbF1.AutoSize = True
        Me.lbF1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.lbF1.Location = New System.Drawing.Point(4, 17)
        Me.lbF1.Name = "lbF1"
        Me.lbF1.Size = New System.Drawing.Size(28, 13)
        Me.lbF1.TabIndex = 64
        Me.lbF1.Text = "Font"
        '
        'gbBack
        '
        Me.gbBack.Controls.Add(Me.cmSave)
        Me.gbBack.Controls.Add(Me.cboScaling)
        Me.gbBack.Controls.Add(Me.Label7)
        Me.gbBack.Controls.Add(Me.cmFormColor)
        Me.gbBack.Controls.Add(Me.cmFormImage)
        Me.gbBack.Controls.Add(Me.cmNoImage)
        Me.gbBack.Controls.Add(Me.cmCopy)
        Me.gbBack.Location = New System.Drawing.Point(428, 13)
        Me.gbBack.Name = "gbBack"
        Me.gbBack.Size = New System.Drawing.Size(130, 172)
        Me.gbBack.TabIndex = 75
        Me.gbBack.TabStop = False
        Me.gbBack.Text = "Background"
        '
        'cboScaling
        '
        Me.cboScaling.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.cboScaling.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboScaling.ForeColor = System.Drawing.Color.White
        Me.cboScaling.FormattingEnabled = True
        Me.cboScaling.Location = New System.Drawing.Point(51, 113)
        Me.cboScaling.Name = "cboScaling"
        Me.cboScaling.Size = New System.Drawing.Size(73, 21)
        Me.cboScaling.TabIndex = 14
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.ForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.Label7.Location = New System.Drawing.Point(6, 116)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(42, 13)
        Me.Label7.TabIndex = 64
        Me.Label7.Text = "Scaling"
        '
        'gbLayout
        '
        Me.gbLayout.Controls.Add(Me.cmSizeRefresh)
        Me.gbLayout.Controls.Add(Me.cboLayoutX)
        Me.gbLayout.Controls.Add(Me.Label6)
        Me.gbLayout.Controls.Add(Me.Label3)
        Me.gbLayout.Controls.Add(Me.cboPageSize)
        Me.gbLayout.Controls.Add(Me.Label4)
        Me.gbLayout.Controls.Add(Me.cboLayoutY)
        Me.gbLayout.Location = New System.Drawing.Point(564, 13)
        Me.gbLayout.Name = "gbLayout"
        Me.gbLayout.Size = New System.Drawing.Size(194, 172)
        Me.gbLayout.TabIndex = 76
        Me.gbLayout.TabStop = False
        Me.gbLayout.Text = "Layout"
        '
        'cmSizeRefresh
        '
        Me.cmSizeRefresh.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmSizeRefresh.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmSizeRefresh.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmSizeRefresh.ForeColor = System.Drawing.Color.Black
        Me.cmSizeRefresh.Location = New System.Drawing.Point(67, 139)
        Me.cmSizeRefresh.Name = "cmSizeRefresh"
        Me.cmSizeRefresh.Size = New System.Drawing.Size(121, 26)
        Me.cmSizeRefresh.TabIndex = 18
        Me.cmSizeRefresh.Text = "Refresh"
        Me.cmSizeRefresh.UseVisualStyleBackColor = False
        '
        'cboLayoutX
        '
        Me.cboLayoutX.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.cboLayoutX.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboLayoutX.ForeColor = System.Drawing.Color.White
        Me.cboLayoutX.FormattingEnabled = True
        Me.cboLayoutX.Location = New System.Drawing.Point(67, 83)
        Me.cboLayoutX.Name = "cboLayoutX"
        Me.cboLayoutX.Size = New System.Drawing.Size(121, 21)
        Me.cboLayoutX.TabIndex = 17
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.ForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.Label6.Location = New System.Drawing.Point(6, 85)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(49, 13)
        Me.Label6.TabIndex = 72
        Me.Label6.Text = "X Layout"
        '
        'cmGUILite
        '
        Me.cmGUILite.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmGUILite.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmGUILite.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmGUILite.ForeColor = System.Drawing.Color.Black
        Me.cmGUILite.Location = New System.Drawing.Point(936, 148)
        Me.cmGUILite.Name = "cmGUILite"
        Me.cmGUILite.Size = New System.Drawing.Size(51, 26)
        Me.cmGUILite.TabIndex = 21
        Me.cmGUILite.Text = "Light"
        Me.cmGUILite.UseVisualStyleBackColor = False
        '
        'cmGUIDark
        '
        Me.cmGUIDark.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmGUIDark.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmGUIDark.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmGUIDark.ForeColor = System.Drawing.Color.Black
        Me.cmGUIDark.Location = New System.Drawing.Point(986, 148)
        Me.cmGUIDark.Name = "cmGUIDark"
        Me.cmGUIDark.Size = New System.Drawing.Size(55, 26)
        Me.cmGUIDark.TabIndex = 22
        Me.cmGUIDark.Text = "Dark"
        Me.cmGUIDark.UseVisualStyleBackColor = False
        '
        'pbStats
        '
        Me.pbStats.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.pbStats.Cursor = System.Windows.Forms.Cursors.Default
        Me.pbStats.Location = New System.Drawing.Point(10, 191)
        Me.pbStats.Name = "pbStats"
        Me.pbStats.Size = New System.Drawing.Size(630, 150)
        Me.pbStats.TabIndex = 77
        Me.pbStats.TabStop = False
        '
        'cmTestData
        '
        Me.cmTestData.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmTestData.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmTestData.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmTestData.ForeColor = System.Drawing.Color.Black
        Me.cmTestData.Location = New System.Drawing.Point(936, 116)
        Me.cmTestData.Name = "cmTestData"
        Me.cmTestData.Size = New System.Drawing.Size(103, 26)
        Me.cmTestData.TabIndex = 78
        Me.cmTestData.Text = "Test Setup"
        Me.cmTestData.UseVisualStyleBackColor = False
        '
        'cmLastMatch
        '
        Me.cmLastMatch.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmLastMatch.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmLastMatch.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmLastMatch.ForeColor = System.Drawing.Color.Black
        Me.cmLastMatch.Location = New System.Drawing.Point(936, 86)
        Me.cmLastMatch.Name = "cmLastMatch"
        Me.cmLastMatch.Size = New System.Drawing.Size(103, 26)
        Me.cmLastMatch.TabIndex = 79
        Me.cmLastMatch.Text = "Last Match Stats"
        Me.cmLastMatch.UseVisualStyleBackColor = False
        '
        'gbFX
        '
        Me.gbFX.Controls.Add(Me.chkFX)
        Me.gbFX.Controls.Add(Me.Label1)
        Me.gbFX.Controls.Add(Me.cmFXModeHelp)
        Me.gbFX.Controls.Add(Me.cboFXVar1)
        Me.gbFX.Controls.Add(Me.lbFXVar1)
        Me.gbFX.Controls.Add(Me.cboFxVar3)
        Me.gbFX.Controls.Add(Me.lbFXVar3)
        Me.gbFX.Controls.Add(Me.cboFxVar4)
        Me.gbFX.Controls.Add(Me.cmFX3DC)
        Me.gbFX.Controls.Add(Me.cboFXVar2)
        Me.gbFX.Controls.Add(Me.lbFXVar2)
        Me.gbFX.Controls.Add(Me.lbFXVar4)
        Me.gbFX.Location = New System.Drawing.Point(764, 13)
        Me.gbFX.Name = "gbFX"
        Me.gbFX.Size = New System.Drawing.Size(145, 172)
        Me.gbFX.TabIndex = 80
        Me.gbFX.TabStop = False
        Me.gbFX.Text = "FX"
        '
        'chkFX
        '
        Me.chkFX.AutoSize = True
        Me.chkFX.Enabled = False
        Me.chkFX.Location = New System.Drawing.Point(66, 42)
        Me.chkFX.Name = "chkFX"
        Me.chkFX.Size = New System.Drawing.Size(56, 17)
        Me.chkFX.TabIndex = 90
        Me.chkFX.Text = "Active"
        Me.chkFX.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.Label1.Location = New System.Drawing.Point(6, 45)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(37, 13)
        Me.Label1.TabIndex = 89
        Me.Label1.Text = " Mode"
        '
        'cmFXModeHelp
        '
        Me.cmFXModeHelp.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmFXModeHelp.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmFXModeHelp.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmFXModeHelp.ForeColor = System.Drawing.Color.Black
        Me.cmFXModeHelp.Location = New System.Drawing.Point(65, 139)
        Me.cmFXModeHelp.Name = "cmFXModeHelp"
        Me.cmFXModeHelp.Size = New System.Drawing.Size(71, 26)
        Me.cmFXModeHelp.TabIndex = 88
        Me.cmFXModeHelp.Text = "Fx Hints"
        Me.cmFXModeHelp.UseVisualStyleBackColor = False
        '
        'cboFXVar1
        '
        Me.cboFXVar1.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.cboFXVar1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboFXVar1.ForeColor = System.Drawing.Color.White
        Me.cboFXVar1.FormattingEnabled = True
        Me.cboFXVar1.Location = New System.Drawing.Point(65, 15)
        Me.cboFXVar1.Name = "cboFXVar1"
        Me.cboFXVar1.Size = New System.Drawing.Size(71, 21)
        Me.cboFXVar1.TabIndex = 87
        '
        'lbFXVar1
        '
        Me.lbFXVar1.AutoSize = True
        Me.lbFXVar1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.lbFXVar1.Location = New System.Drawing.Point(6, 21)
        Me.lbFXVar1.Name = "lbFXVar1"
        Me.lbFXVar1.Size = New System.Drawing.Size(37, 13)
        Me.lbFXVar1.TabIndex = 86
        Me.lbFXVar1.Text = " Mode"
        '
        'cboFxVar3
        '
        Me.cboFxVar3.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.cboFxVar3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboFxVar3.Enabled = False
        Me.cboFxVar3.ForeColor = System.Drawing.Color.White
        Me.cboFxVar3.FormattingEnabled = True
        Me.cboFxVar3.Location = New System.Drawing.Point(65, 89)
        Me.cboFxVar3.Name = "cboFxVar3"
        Me.cboFxVar3.Size = New System.Drawing.Size(71, 21)
        Me.cboFxVar3.TabIndex = 85
        '
        'lbFXVar3
        '
        Me.lbFXVar3.AutoSize = True
        Me.lbFXVar3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.lbFXVar3.Location = New System.Drawing.Point(6, 91)
        Me.lbFXVar3.Name = "lbFXVar3"
        Me.lbFXVar3.Size = New System.Drawing.Size(13, 13)
        Me.lbFXVar3.TabIndex = 84
        Me.lbFXVar3.Text = "--"
        '
        'cboFxVar4
        '
        Me.cboFxVar4.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.cboFxVar4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboFxVar4.Enabled = False
        Me.cboFxVar4.ForeColor = System.Drawing.Color.White
        Me.cboFxVar4.FormattingEnabled = True
        Me.cboFxVar4.Location = New System.Drawing.Point(65, 113)
        Me.cboFxVar4.Name = "cboFxVar4"
        Me.cboFxVar4.Size = New System.Drawing.Size(71, 21)
        Me.cboFxVar4.TabIndex = 83
        '
        'cmFX3DC
        '
        Me.cmFX3DC.Enabled = False
        Me.cmFX3DC.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmFX3DC.Location = New System.Drawing.Point(65, 65)
        Me.cmFX3DC.Name = "cmFX3DC"
        Me.cmFX3DC.Size = New System.Drawing.Size(21, 21)
        Me.cmFX3DC.TabIndex = 82
        Me.cmFX3DC.Text = "1"
        Me.cmFX3DC.UseVisualStyleBackColor = True
        '
        'cboFXVar2
        '
        Me.cboFXVar2.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.cboFXVar2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboFXVar2.Enabled = False
        Me.cboFXVar2.ForeColor = System.Drawing.Color.White
        Me.cboFXVar2.FormattingEnabled = True
        Me.cboFXVar2.Location = New System.Drawing.Point(90, 65)
        Me.cboFXVar2.Name = "cboFXVar2"
        Me.cboFXVar2.Size = New System.Drawing.Size(46, 21)
        Me.cboFXVar2.TabIndex = 81
        '
        'lbFXVar2
        '
        Me.lbFXVar2.AutoSize = True
        Me.lbFXVar2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.lbFXVar2.Location = New System.Drawing.Point(6, 68)
        Me.lbFXVar2.Name = "lbFXVar2"
        Me.lbFXVar2.Size = New System.Drawing.Size(13, 13)
        Me.lbFXVar2.TabIndex = 66
        Me.lbFXVar2.Text = "--"
        '
        'lbFXVar4
        '
        Me.lbFXVar4.AutoSize = True
        Me.lbFXVar4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.lbFXVar4.Location = New System.Drawing.Point(6, 115)
        Me.lbFXVar4.Name = "lbFXVar4"
        Me.lbFXVar4.Size = New System.Drawing.Size(13, 13)
        Me.lbFXVar4.TabIndex = 70
        Me.lbFXVar4.Text = "--"
        '
        'lbError1
        '
        Me.lbError1.BackColor = System.Drawing.Color.Silver
        Me.lbError1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lbError1.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbError1.ForeColor = System.Drawing.Color.White
        Me.lbError1.Location = New System.Drawing.Point(10, 81)
        Me.lbError1.Name = "lbError1"
        Me.lbError1.Size = New System.Drawing.Size(111, 18)
        Me.lbError1.TabIndex = 81
        Me.lbError1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lbError2
        '
        Me.lbError2.BackColor = System.Drawing.Color.Silver
        Me.lbError2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lbError2.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbError2.ForeColor = System.Drawing.Color.White
        Me.lbError2.Location = New System.Drawing.Point(10, 100)
        Me.lbError2.Name = "lbError2"
        Me.lbError2.Size = New System.Drawing.Size(111, 18)
        Me.lbError2.TabIndex = 82
        Me.lbError2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cmSave
        '
        Me.cmSave.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmSave.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmSave.ForeColor = System.Drawing.Color.Black
        Me.cmSave.Location = New System.Drawing.Point(69, 139)
        Me.cmSave.Name = "cmSave"
        Me.cmSave.Size = New System.Drawing.Size(55, 26)
        Me.cmSave.TabIndex = 65
        Me.cmSave.Text = "Save"
        Me.cmSave.UseVisualStyleBackColor = False
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(242, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1084, 461)
        Me.Controls.Add(Me.lbError2)
        Me.Controls.Add(Me.lbError1)
        Me.Controls.Add(Me.gbFX)
        Me.Controls.Add(Me.cmLastMatch)
        Me.Controls.Add(Me.cmTestData)
        Me.Controls.Add(Me.pbStats)
        Me.Controls.Add(Me.cmGUIDark)
        Me.Controls.Add(Me.cmGUILite)
        Me.Controls.Add(Me.gbLayout)
        Me.Controls.Add(Me.gbBack)
        Me.Controls.Add(Me.gbName)
        Me.Controls.Add(Me.gbRank)
        Me.Controls.Add(Me.cmAbout)
        Me.Controls.Add(Me.pbPanelDefault01)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.cmScanLog)
        Me.Controls.Add(Me.lbHelp01)
        Me.Controls.Add(Me.cmFindLog)
        Me.Controls.Add(Me.lbPath)
        Me.Controls.Add(Me.lbSteam08)
        Me.Controls.Add(Me.lbSteam07)
        Me.Controls.Add(Me.lbSteam06)
        Me.Controls.Add(Me.lbSteam05)
        Me.Controls.Add(Me.lbSteam04)
        Me.Controls.Add(Me.lbSteam03)
        Me.Controls.Add(Me.lbSteam02)
        Me.Controls.Add(Me.lbSteam01)
        Me.Controls.Add(Me.pbFact05)
        Me.Controls.Add(Me.pbFact04)
        Me.Controls.Add(Me.pbFact03)
        Me.Controls.Add(Me.pbFact02)
        Me.Controls.Add(Me.pbFact01)
        Me.Controls.Add(Me.lbStatus)
        Me.Controls.Add(Me.lbFact08)
        Me.Controls.Add(Me.lbFact07)
        Me.Controls.Add(Me.lbFact06)
        Me.Controls.Add(Me.lbFact05)
        Me.Controls.Add(Me.lbFact04)
        Me.Controls.Add(Me.lbFact03)
        Me.Controls.Add(Me.lbFact02)
        Me.Controls.Add(Me.lbFact01)
        Me.Controls.Add(Me.cmCheckLog)
        Me.DoubleBuffered = True
        Me.ForeColor = System.Drawing.Color.Black
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmMain"
        Me.Text = "MakoCelo v3.30"
        CType(Me.pbFact01, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbFact02, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbFact03, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbFact04, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbFact05, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbPanelDefault01, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gbRank.ResumeLayout(False)
        Me.gbRank.PerformLayout()
        Me.gbName.ResumeLayout(False)
        Me.gbName.PerformLayout()
        Me.gbBack.ResumeLayout(False)
        Me.gbBack.PerformLayout()
        Me.gbLayout.ResumeLayout(False)
        Me.gbLayout.PerformLayout()
        CType(Me.pbStats, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gbFX.ResumeLayout(False)
        Me.gbFX.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents cmCheckLog As System.Windows.Forms.Button
    Friend WithEvents lbFact01 As System.Windows.Forms.Label
    Friend WithEvents lbFact02 As System.Windows.Forms.Label
    Friend WithEvents lbFact03 As System.Windows.Forms.Label
    Friend WithEvents lbFact04 As System.Windows.Forms.Label
    Friend WithEvents lbFact08 As System.Windows.Forms.Label
    Friend WithEvents lbFact07 As System.Windows.Forms.Label
    Friend WithEvents lbFact06 As System.Windows.Forms.Label
    Friend WithEvents lbFact05 As System.Windows.Forms.Label
    Friend WithEvents lbStatus As System.Windows.Forms.Label
    Friend WithEvents pbFact01 As System.Windows.Forms.PictureBox
    Friend WithEvents pbFact02 As System.Windows.Forms.PictureBox
    Friend WithEvents pbFact03 As System.Windows.Forms.PictureBox
    Friend WithEvents pbFact04 As System.Windows.Forms.PictureBox
    Friend WithEvents pbFact05 As System.Windows.Forms.PictureBox
    Friend WithEvents lbSteam01 As System.Windows.Forms.Label
    Friend WithEvents lbSteam02 As System.Windows.Forms.Label
    Friend WithEvents lbSteam03 As System.Windows.Forms.Label
    Friend WithEvents lbSteam04 As System.Windows.Forms.Label
    Friend WithEvents lbSteam05 As System.Windows.Forms.Label
    Friend WithEvents lbSteam06 As System.Windows.Forms.Label
    Friend WithEvents lbSteam07 As System.Windows.Forms.Label
    Friend WithEvents lbSteam08 As System.Windows.Forms.Label
    Friend WithEvents ColorDialog1 As System.Windows.Forms.ColorDialog
    Friend WithEvents cmFormColor As System.Windows.Forms.Button
    Friend WithEvents cmFormImage As System.Windows.Forms.Button
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents lbR3 As System.Windows.Forms.Label
    Friend WithEvents cboRankA1 As System.Windows.Forms.ComboBox
    Friend WithEvents cmNoImage As System.Windows.Forms.Button
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents lbPath As System.Windows.Forms.Label
    Friend WithEvents cmFindLog As System.Windows.Forms.Button
    Friend WithEvents lbHelp01 As System.Windows.Forms.Label
    Friend WithEvents cmScanLog As System.Windows.Forms.Button
    Friend WithEvents cmCopy As System.Windows.Forms.Button
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents cmRankFont As System.Windows.Forms.Button
    Friend WithEvents FontDialog1 As System.Windows.Forms.FontDialog
    Friend WithEvents pbPanelDefault01 As System.Windows.Forms.PictureBox
    Friend WithEvents cmAbout As System.Windows.Forms.Button
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents cboPageSize As System.Windows.Forms.ComboBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents cboLayoutY As System.Windows.Forms.ComboBox
    Friend WithEvents gbRank As System.Windows.Forms.GroupBox
    Friend WithEvents gbName As System.Windows.Forms.GroupBox
    Friend WithEvents cmNameFont As System.Windows.Forms.Button
    Friend WithEvents gbBack As System.Windows.Forms.GroupBox
    Friend WithEvents gbLayout As System.Windows.Forms.GroupBox
    Friend WithEvents cboLayoutX As System.Windows.Forms.ComboBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents cmSizeRefresh As System.Windows.Forms.Button
    Friend WithEvents cboScaling As System.Windows.Forms.ComboBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents cmGUILite As System.Windows.Forms.Button
    Friend WithEvents cmGUIDark As System.Windows.Forms.Button
    Friend WithEvents pbStats As System.Windows.Forms.PictureBox
    Friend WithEvents lbR1 As System.Windows.Forms.Label
    Friend WithEvents cmRankB2 As System.Windows.Forms.Button
    Friend WithEvents cmRankB1 As System.Windows.Forms.Button
    Friend WithEvents lbR2 As System.Windows.Forms.Label
    Friend WithEvents cmRankF2 As System.Windows.Forms.Button
    Friend WithEvents cmRankF1 As System.Windows.Forms.Button
    Friend WithEvents cmRankFD As System.Windows.Forms.Button
    Friend WithEvents cmRankBR As System.Windows.Forms.Button
    Friend WithEvents cmRankBD As System.Windows.Forms.Button
    Friend WithEvents cmRankFR As System.Windows.Forms.Button
    Friend WithEvents cmNameBR As System.Windows.Forms.Button
    Friend WithEvents cmNameBD As System.Windows.Forms.Button
    Friend WithEvents cmNameFR As System.Windows.Forms.Button
    Friend WithEvents cmNameFD As System.Windows.Forms.Button
    Friend WithEvents cmNameB2 As System.Windows.Forms.Button
    Friend WithEvents cmNameB1 As System.Windows.Forms.Button
    Friend WithEvents lbF2 As System.Windows.Forms.Label
    Friend WithEvents cmNameF2 As System.Windows.Forms.Button
    Friend WithEvents cmNameF1 As System.Windows.Forms.Button
    Friend WithEvents lbF1 As System.Windows.Forms.Label
    Friend WithEvents cboRankA2 As System.Windows.Forms.ComboBox
    Friend WithEvents lbR4 As System.Windows.Forms.Label
    Friend WithEvents lbF4 As System.Windows.Forms.Label
    Friend WithEvents lbF3 As System.Windows.Forms.Label
    Friend WithEvents cboRank3D As System.Windows.Forms.ComboBox
    Friend WithEvents cmRank3DC As System.Windows.Forms.Button
    Friend WithEvents lbR5 As System.Windows.Forms.Label
    Friend WithEvents cmName3DC As System.Windows.Forms.Button
    Friend WithEvents lbF5 As System.Windows.Forms.Label
    Friend WithEvents cboName3D As System.Windows.Forms.ComboBox
    Friend WithEvents cboNameA2 As System.Windows.Forms.ComboBox
    Friend WithEvents cboNameA1 As System.Windows.Forms.ComboBox
    Friend WithEvents cmTestData As System.Windows.Forms.Button
    Friend WithEvents cmLastMatch As System.Windows.Forms.Button
    Friend WithEvents gbFX As System.Windows.Forms.GroupBox
    Friend WithEvents lbFXVar2 As System.Windows.Forms.Label
    Friend WithEvents lbFXVar4 As System.Windows.Forms.Label
    Friend WithEvents cmFX3DC As System.Windows.Forms.Button
    Friend WithEvents cboFXVar2 As System.Windows.Forms.ComboBox
    Friend WithEvents cboFxVar4 As System.Windows.Forms.ComboBox
    Friend WithEvents cboFxVar3 As System.Windows.Forms.ComboBox
    Friend WithEvents lbFXVar3 As System.Windows.Forms.Label
    Friend WithEvents cboFXVar1 As System.Windows.Forms.ComboBox
    Friend WithEvents lbFXVar1 As System.Windows.Forms.Label
    Friend WithEvents cmFXModeHelp As Button
    Friend WithEvents lbError1 As Label
    Friend WithEvents lbError2 As Label
    Friend WithEvents chkFX As CheckBox
    Friend WithEvents Label1 As Label
    Friend WithEvents cmSave As Button
    Friend WithEvents SaveFileDialog1 As SaveFileDialog
End Class
