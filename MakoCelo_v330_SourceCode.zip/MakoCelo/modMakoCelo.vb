﻿
Structure  t_Box

  Dim X as single 
  Dim Y as Single 
  Dim Xcenter as single 
  Dim Ycenter as Single 
  Dim Width As Single 
  Dim Height As Single   

End Structure

Public Enum FXVarDefs
  None = 0
  Mode = 1
  ShadeAng = 2
  ShadeAmount = 3
  ShadeBias = 4


End Enum

Public Enum FXMode

  None = 0
  Shadow = 1
  Emboss = 2
  LabelBlur = 3


End Enum