﻿Public Class frmAbout
  Private Sub frmAbout_Load(sender As Object, e As EventArgs) Handles MyBase.Load

  End Sub

  Private Sub frmAbout_Shown(sender As Object, e As EventArgs) Handles Me.Shown
    'R4.00 Textbox defaults to all text selected.
    tbHelp.SelectionLength = 0
  End Sub

  Private Sub frmAbout_KeyDown(sender As Object, e As KeyEventArgs) Handles Me.KeyDown

    'R4.10 KEY PREVIEW is on, check for ESCAPE or RETURN to exit.
    If (e.KeyCode = 27) Or (e.KeyCode = 13) Then Me.Close()

  End Sub
End Class