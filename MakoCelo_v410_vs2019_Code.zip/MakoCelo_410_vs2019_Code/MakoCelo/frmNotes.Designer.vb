﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmNotes
  Inherits System.Windows.Forms.Form

  'Form overrides dispose to clean up the component list.
  <System.Diagnostics.DebuggerNonUserCode()> _
  Protected Overrides Sub Dispose(ByVal disposing As Boolean)
    Try
      If disposing AndAlso components IsNot Nothing Then
        components.Dispose()
      End If
    Finally
      MyBase.Dispose(disposing)
    End Try
  End Sub

  'Required by the Windows Form Designer
  Private components As System.ComponentModel.IContainer

  'NOTE: The following procedure is required by the Windows Form Designer
  'It can be modified using the Windows Form Designer.  
  'Do not modify it using the code editor.
  <System.Diagnostics.DebuggerStepThrough()> _
  Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmNotes))
        Me.tbN04 = New System.Windows.Forms.TextBox()
        Me.tbN03 = New System.Windows.Forms.TextBox()
        Me.tbN02 = New System.Windows.Forms.TextBox()
        Me.tbN01 = New System.Windows.Forms.TextBox()
        Me.tbN05 = New System.Windows.Forms.TextBox()
        Me.tbN10 = New System.Windows.Forms.TextBox()
        Me.tbN09 = New System.Windows.Forms.TextBox()
        Me.tbN08 = New System.Windows.Forms.TextBox()
        Me.tbN07 = New System.Windows.Forms.TextBox()
        Me.tbN06 = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.cmOK = New System.Windows.Forms.Button()
        Me.cmCancel = New System.Windows.Forms.Button()
        Me.cboMode = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.cboSpeed = New System.Windows.Forms.ComboBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.cboHoldTime = New System.Windows.Forms.ComboBox()
        Me.tbDelim = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.cboAlign = New System.Windows.Forms.ComboBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.lbXOff = New System.Windows.Forms.Label()
        Me.tbXoff = New System.Windows.Forms.TextBox()
        Me.lbYoff = New System.Windows.Forms.Label()
        Me.tbYoff = New System.Windows.Forms.TextBox()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.Button12 = New System.Windows.Forms.Button()
        Me.Button13 = New System.Windows.Forms.Button()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.SuspendLayout()
        '
        'tbN04
        '
        Me.tbN04.BackColor = System.Drawing.Color.White
        Me.tbN04.ForeColor = System.Drawing.Color.Black
        Me.tbN04.Location = New System.Drawing.Point(15, 105)
        Me.tbN04.Name = "tbN04"
        Me.tbN04.Size = New System.Drawing.Size(467, 20)
        Me.tbN04.TabIndex = 4
        '
        'tbN03
        '
        Me.tbN03.BackColor = System.Drawing.Color.White
        Me.tbN03.ForeColor = System.Drawing.Color.Black
        Me.tbN03.Location = New System.Drawing.Point(15, 80)
        Me.tbN03.Name = "tbN03"
        Me.tbN03.Size = New System.Drawing.Size(467, 20)
        Me.tbN03.TabIndex = 3
        '
        'tbN02
        '
        Me.tbN02.BackColor = System.Drawing.Color.White
        Me.tbN02.ForeColor = System.Drawing.Color.Black
        Me.tbN02.Location = New System.Drawing.Point(15, 55)
        Me.tbN02.Name = "tbN02"
        Me.tbN02.Size = New System.Drawing.Size(467, 20)
        Me.tbN02.TabIndex = 2
        '
        'tbN01
        '
        Me.tbN01.BackColor = System.Drawing.Color.White
        Me.tbN01.ForeColor = System.Drawing.Color.Black
        Me.tbN01.Location = New System.Drawing.Point(15, 30)
        Me.tbN01.Name = "tbN01"
        Me.tbN01.Size = New System.Drawing.Size(467, 20)
        Me.tbN01.TabIndex = 1
        '
        'tbN05
        '
        Me.tbN05.BackColor = System.Drawing.Color.White
        Me.tbN05.ForeColor = System.Drawing.Color.Black
        Me.tbN05.Location = New System.Drawing.Point(15, 130)
        Me.tbN05.Name = "tbN05"
        Me.tbN05.Size = New System.Drawing.Size(467, 20)
        Me.tbN05.TabIndex = 5
        '
        'tbN10
        '
        Me.tbN10.BackColor = System.Drawing.Color.White
        Me.tbN10.ForeColor = System.Drawing.Color.Black
        Me.tbN10.Location = New System.Drawing.Point(15, 255)
        Me.tbN10.Name = "tbN10"
        Me.tbN10.Size = New System.Drawing.Size(467, 20)
        Me.tbN10.TabIndex = 10
        '
        'tbN09
        '
        Me.tbN09.BackColor = System.Drawing.Color.White
        Me.tbN09.ForeColor = System.Drawing.Color.Black
        Me.tbN09.Location = New System.Drawing.Point(15, 230)
        Me.tbN09.Name = "tbN09"
        Me.tbN09.Size = New System.Drawing.Size(467, 20)
        Me.tbN09.TabIndex = 9
        '
        'tbN08
        '
        Me.tbN08.BackColor = System.Drawing.Color.White
        Me.tbN08.ForeColor = System.Drawing.Color.Black
        Me.tbN08.Location = New System.Drawing.Point(15, 205)
        Me.tbN08.Name = "tbN08"
        Me.tbN08.Size = New System.Drawing.Size(467, 20)
        Me.tbN08.TabIndex = 8
        '
        'tbN07
        '
        Me.tbN07.BackColor = System.Drawing.Color.White
        Me.tbN07.ForeColor = System.Drawing.Color.Black
        Me.tbN07.Location = New System.Drawing.Point(15, 180)
        Me.tbN07.Name = "tbN07"
        Me.tbN07.Size = New System.Drawing.Size(467, 20)
        Me.tbN07.TabIndex = 7
        '
        'tbN06
        '
        Me.tbN06.BackColor = System.Drawing.Color.White
        Me.tbN06.ForeColor = System.Drawing.Color.Black
        Me.tbN06.Location = New System.Drawing.Point(15, 155)
        Me.tbN06.Name = "tbN06"
        Me.tbN06.Size = New System.Drawing.Size(467, 20)
        Me.tbN06.TabIndex = 6
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(485, 30)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(32, 20)
        Me.Button1.TabIndex = 18
        Me.Button1.Text = "Clr"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(485, 55)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(32, 20)
        Me.Button2.TabIndex = 19
        Me.Button2.Text = "Clr"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(485, 80)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(32, 20)
        Me.Button3.TabIndex = 20
        Me.Button3.Text = "Clr"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(485, 105)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(32, 20)
        Me.Button4.TabIndex = 21
        Me.Button4.Text = "Clr"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(485, 130)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(32, 20)
        Me.Button5.TabIndex = 22
        Me.Button5.Text = "Clr"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.Location = New System.Drawing.Point(485, 155)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(32, 20)
        Me.Button6.TabIndex = 23
        Me.Button6.Text = "Clr"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Button7
        '
        Me.Button7.Location = New System.Drawing.Point(485, 180)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(32, 20)
        Me.Button7.TabIndex = 24
        Me.Button7.Text = "Clr"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Button8
        '
        Me.Button8.Location = New System.Drawing.Point(485, 205)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(32, 20)
        Me.Button8.TabIndex = 25
        Me.Button8.Text = "Clr"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'Button9
        '
        Me.Button9.Location = New System.Drawing.Point(485, 230)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(32, 20)
        Me.Button9.TabIndex = 26
        Me.Button9.Text = "Clr"
        Me.Button9.UseVisualStyleBackColor = True
        '
        'Button10
        '
        Me.Button10.Location = New System.Drawing.Point(485, 255)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(32, 20)
        Me.Button10.TabIndex = 27
        Me.Button10.Text = "Clr"
        Me.Button10.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(210, 13)
        Me.Label1.TabIndex = 130
        Me.Label1.Text = "Enter the text to display for this note object."
        '
        'cmOK
        '
        Me.cmOK.Location = New System.Drawing.Point(551, 32)
        Me.cmOK.Name = "cmOK"
        Me.cmOK.Size = New System.Drawing.Size(105, 37)
        Me.cmOK.TabIndex = 131
        Me.cmOK.Text = "OK"
        Me.cmOK.UseVisualStyleBackColor = True
        '
        'cmCancel
        '
        Me.cmCancel.Location = New System.Drawing.Point(551, 77)
        Me.cmCancel.Name = "cmCancel"
        Me.cmCancel.Size = New System.Drawing.Size(105, 37)
        Me.cmCancel.TabIndex = 132
        Me.cmCancel.Text = "Cancel"
        Me.cmCancel.UseVisualStyleBackColor = True
        '
        'cboMode
        '
        Me.cboMode.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.cboMode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboMode.ForeColor = System.Drawing.Color.White
        Me.cboMode.FormattingEnabled = True
        Me.cboMode.Location = New System.Drawing.Point(125, 295)
        Me.cboMode.Name = "cboMode"
        Me.cboMode.Size = New System.Drawing.Size(105, 21)
        Me.cboMode.TabIndex = 11
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(10, 300)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(107, 13)
        Me.Label2.TabIndex = 134
        Me.Label2.Text = "Text Animation Mode"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(10, 325)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(111, 13)
        Me.Label3.TabIndex = 135
        Me.Label3.Text = "Text Animation Speed"
        '
        'cboSpeed
        '
        Me.cboSpeed.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.cboSpeed.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboSpeed.ForeColor = System.Drawing.Color.White
        Me.cboSpeed.FormattingEnabled = True
        Me.cboSpeed.Location = New System.Drawing.Point(125, 320)
        Me.cboSpeed.Name = "cboSpeed"
        Me.cboSpeed.Size = New System.Drawing.Size(105, 21)
        Me.cboSpeed.TabIndex = 12
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(10, 350)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(104, 13)
        Me.Label4.TabIndex = 137
        Me.Label4.Text = "Animation Hold Time"
        '
        'cboHoldTime
        '
        Me.cboHoldTime.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.cboHoldTime.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboHoldTime.ForeColor = System.Drawing.Color.White
        Me.cboHoldTime.FormattingEnabled = True
        Me.cboHoldTime.Location = New System.Drawing.Point(125, 345)
        Me.cboHoldTime.Name = "cboHoldTime"
        Me.cboHoldTime.Size = New System.Drawing.Size(105, 21)
        Me.cboHoldTime.TabIndex = 13
        '
        'tbDelim
        '
        Me.tbDelim.BackColor = System.Drawing.Color.White
        Me.tbDelim.ForeColor = System.Drawing.Color.Black
        Me.tbDelim.Location = New System.Drawing.Point(355, 295)
        Me.tbDelim.Name = "tbDelim"
        Me.tbDelim.Size = New System.Drawing.Size(125, 20)
        Me.tbDelim.TabIndex = 15
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(255, 300)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(99, 13)
        Me.Label5.TabIndex = 140
        Me.Label5.Text = "Message Seperator"
        '
        'cboAlign
        '
        Me.cboAlign.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.cboAlign.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboAlign.ForeColor = System.Drawing.Color.White
        Me.cboAlign.FormattingEnabled = True
        Me.cboAlign.Location = New System.Drawing.Point(125, 370)
        Me.cboAlign.Name = "cboAlign"
        Me.cboAlign.Size = New System.Drawing.Size(105, 21)
        Me.cboAlign.TabIndex = 14
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(10, 375)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(77, 13)
        Me.Label6.TabIndex = 142
        Me.Label6.Text = "Text Alignment"
        '
        'lbXOff
        '
        Me.lbXOff.AutoSize = True
        Me.lbXOff.Location = New System.Drawing.Point(255, 325)
        Me.lbXOff.Name = "lbXOff"
        Me.lbXOff.Size = New System.Drawing.Size(69, 13)
        Me.lbXOff.TabIndex = 143
        Me.lbXOff.Text = "Text X Offset"
        '
        'tbXoff
        '
        Me.tbXoff.BackColor = System.Drawing.Color.White
        Me.tbXoff.ForeColor = System.Drawing.Color.Black
        Me.tbXoff.Location = New System.Drawing.Point(355, 320)
        Me.tbXoff.Name = "tbXoff"
        Me.tbXoff.Size = New System.Drawing.Size(125, 20)
        Me.tbXoff.TabIndex = 16
        '
        'lbYoff
        '
        Me.lbYoff.AutoSize = True
        Me.lbYoff.Location = New System.Drawing.Point(255, 350)
        Me.lbYoff.Name = "lbYoff"
        Me.lbYoff.Size = New System.Drawing.Size(69, 13)
        Me.lbYoff.TabIndex = 145
        Me.lbYoff.Text = "Text Y Offset"
        '
        'tbYoff
        '
        Me.tbYoff.BackColor = System.Drawing.Color.White
        Me.tbYoff.ForeColor = System.Drawing.Color.Black
        Me.tbYoff.Location = New System.Drawing.Point(355, 345)
        Me.tbYoff.Name = "tbYoff"
        Me.tbYoff.Size = New System.Drawing.Size(125, 20)
        Me.tbYoff.TabIndex = 17
        '
        'Button11
        '
        Me.Button11.Location = New System.Drawing.Point(485, 295)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(32, 20)
        Me.Button11.TabIndex = 28
        Me.Button11.Text = "Clr"
        Me.Button11.UseVisualStyleBackColor = True
        '
        'Button12
        '
        Me.Button12.Location = New System.Drawing.Point(485, 320)
        Me.Button12.Name = "Button12"
        Me.Button12.Size = New System.Drawing.Size(32, 20)
        Me.Button12.TabIndex = 29
        Me.Button12.Text = "Clr"
        Me.Button12.UseVisualStyleBackColor = True
        '
        'Button13
        '
        Me.Button13.Location = New System.Drawing.Point(485, 345)
        Me.Button13.Name = "Button13"
        Me.Button13.Size = New System.Drawing.Size(32, 20)
        Me.Button13.TabIndex = 30
        Me.Button13.Text = "Clr"
        Me.Button13.UseVisualStyleBackColor = True
        '
        'frmNotes
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(682, 417)
        Me.Controls.Add(Me.Button13)
        Me.Controls.Add(Me.Button12)
        Me.Controls.Add(Me.Button11)
        Me.Controls.Add(Me.tbYoff)
        Me.Controls.Add(Me.lbYoff)
        Me.Controls.Add(Me.tbXoff)
        Me.Controls.Add(Me.lbXOff)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.cboAlign)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.tbDelim)
        Me.Controls.Add(Me.cboHoldTime)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.cboSpeed)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.cboMode)
        Me.Controls.Add(Me.cmCancel)
        Me.Controls.Add(Me.cmOK)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Button10)
        Me.Controls.Add(Me.Button9)
        Me.Controls.Add(Me.Button8)
        Me.Controls.Add(Me.Button7)
        Me.Controls.Add(Me.Button6)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.tbN10)
        Me.Controls.Add(Me.tbN09)
        Me.Controls.Add(Me.tbN08)
        Me.Controls.Add(Me.tbN07)
        Me.Controls.Add(Me.tbN06)
        Me.Controls.Add(Me.tbN05)
        Me.Controls.Add(Me.tbN04)
        Me.Controls.Add(Me.tbN03)
        Me.Controls.Add(Me.tbN02)
        Me.Controls.Add(Me.tbN01)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmNotes"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "frmNotes"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents tbN04 As TextBox
    Friend WithEvents tbN03 As TextBox
    Friend WithEvents tbN02 As TextBox
    Friend WithEvents tbN01 As TextBox
    Friend WithEvents tbN05 As TextBox
    Friend WithEvents tbN10 As TextBox
    Friend WithEvents tbN09 As TextBox
    Friend WithEvents tbN08 As TextBox
    Friend WithEvents tbN07 As TextBox
    Friend WithEvents tbN06 As TextBox
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents Button7 As Button
    Friend WithEvents Button8 As Button
    Friend WithEvents Button9 As Button
    Friend WithEvents Button10 As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents cmOK As Button
    Friend WithEvents cmCancel As Button
    Friend WithEvents cboMode As ComboBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents cboSpeed As ComboBox
    Friend WithEvents Label4 As Label
    Friend WithEvents cboHoldTime As ComboBox
    Friend WithEvents tbDelim As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents cboAlign As ComboBox
    Friend WithEvents Label6 As Label
    Friend WithEvents lbXOff As Label
    Friend WithEvents tbXoff As TextBox
    Friend WithEvents lbYoff As Label
    Friend WithEvents tbYoff As TextBox
    Friend WithEvents Button11 As Button
    Friend WithEvents Button12 As Button
    Friend WithEvents Button13 As Button
    Friend WithEvents ToolTip1 As ToolTip
End Class
