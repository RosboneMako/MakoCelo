﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmLabelSetup
  Inherits System.Windows.Forms.Form

  'Form overrides dispose to clean up the component list.
  <System.Diagnostics.DebuggerNonUserCode()> _
  Protected Overrides Sub Dispose(ByVal disposing As Boolean)
    Try
      If disposing AndAlso components IsNot Nothing Then
        components.Dispose()
      End If
    Finally
      MyBase.Dispose(disposing)
    End Try
  End Sub

  'Required by the Windows Form Designer
  Private components As System.ComponentModel.IContainer

  'NOTE: The following procedure is required by the Windows Form Designer
  'It can be modified using the Windows Form Designer.  
  'Do not modify it using the code editor.
  <System.Diagnostics.DebuggerStepThrough()> _
  Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmLabelSetup))
        Me.gbLabel = New System.Windows.Forms.GroupBox()
        Me.cboDepth = New System.Windows.Forms.ComboBox()
        Me.lbDepth = New System.Windows.Forms.Label()
        Me.tbHeight = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.tbWidth = New System.Windows.Forms.TextBox()
        Me.lbSize = New System.Windows.Forms.Label()
        Me.cmShadowColor = New System.Windows.Forms.Button()
        Me.lbR5 = New System.Windows.Forms.Label()
        Me.cbo3D = New System.Windows.Forms.ComboBox()
        Me.cboA2 = New System.Windows.Forms.ComboBox()
        Me.lbR4 = New System.Windows.Forms.Label()
        Me.cmBR = New System.Windows.Forms.Button()
        Me.cmBD = New System.Windows.Forms.Button()
        Me.cmFR = New System.Windows.Forms.Button()
        Me.cmFD = New System.Windows.Forms.Button()
        Me.cmB2 = New System.Windows.Forms.Button()
        Me.cmB1 = New System.Windows.Forms.Button()
        Me.lbR2 = New System.Windows.Forms.Label()
        Me.cmF2 = New System.Windows.Forms.Button()
        Me.cmRankFont = New System.Windows.Forms.Button()
        Me.cmF1 = New System.Windows.Forms.Button()
        Me.lbR1 = New System.Windows.Forms.Label()
        Me.lbR3 = New System.Windows.Forms.Label()
        Me.cboA1 = New System.Windows.Forms.ComboBox()
        Me.pbNote = New System.Windows.Forms.PictureBox()
        Me.cmCancel = New System.Windows.Forms.Button()
        Me.cmOK = New System.Windows.Forms.Button()
        Me.ColorDialog1 = New System.Windows.Forms.ColorDialog()
        Me.gbBack = New System.Windows.Forms.GroupBox()
        Me.cboScaling = New System.Windows.Forms.ComboBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.cmFormColor = New System.Windows.Forms.Button()
        Me.cmFormImage = New System.Windows.Forms.Button()
        Me.cmNoImage = New System.Windows.Forms.Button()
        Me.cboOVLScaling = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.cmOverlay = New System.Windows.Forms.Button()
        Me.cmCopy01 = New System.Windows.Forms.Button()
        Me.cmCopy02 = New System.Windows.Forms.Button()
        Me.cmCopy03 = New System.Windows.Forms.Button()
        Me.cmCopy04 = New System.Windows.Forms.Button()
        Me.cmCopyAll = New System.Windows.Forms.Button()
        Me.cmCopySize = New System.Windows.Forms.Button()
        Me.cmOVLNoImage = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.gbLabel.SuspendLayout()
        CType(Me.pbNote, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gbBack.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'gbLabel
        '
        Me.gbLabel.Controls.Add(Me.cboDepth)
        Me.gbLabel.Controls.Add(Me.lbDepth)
        Me.gbLabel.Controls.Add(Me.tbHeight)
        Me.gbLabel.Controls.Add(Me.Label1)
        Me.gbLabel.Controls.Add(Me.tbWidth)
        Me.gbLabel.Controls.Add(Me.lbSize)
        Me.gbLabel.Controls.Add(Me.cmShadowColor)
        Me.gbLabel.Controls.Add(Me.lbR5)
        Me.gbLabel.Controls.Add(Me.cbo3D)
        Me.gbLabel.Controls.Add(Me.cboA2)
        Me.gbLabel.Controls.Add(Me.lbR4)
        Me.gbLabel.Controls.Add(Me.cmBR)
        Me.gbLabel.Controls.Add(Me.cmBD)
        Me.gbLabel.Controls.Add(Me.cmFR)
        Me.gbLabel.Controls.Add(Me.cmFD)
        Me.gbLabel.Controls.Add(Me.cmB2)
        Me.gbLabel.Controls.Add(Me.cmB1)
        Me.gbLabel.Controls.Add(Me.lbR2)
        Me.gbLabel.Controls.Add(Me.cmF2)
        Me.gbLabel.Controls.Add(Me.cmRankFont)
        Me.gbLabel.Controls.Add(Me.cmF1)
        Me.gbLabel.Controls.Add(Me.lbR1)
        Me.gbLabel.Controls.Add(Me.lbR3)
        Me.gbLabel.Controls.Add(Me.cboA1)
        Me.gbLabel.ForeColor = System.Drawing.Color.Black
        Me.gbLabel.Location = New System.Drawing.Point(10, 10)
        Me.gbLabel.Name = "gbLabel"
        Me.gbLabel.Size = New System.Drawing.Size(256, 247)
        Me.gbLabel.TabIndex = 74
        Me.gbLabel.TabStop = False
        Me.gbLabel.Text = "Text Setup"
        '
        'cboDepth
        '
        Me.cboDepth.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.cboDepth.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboDepth.ForeColor = System.Drawing.Color.White
        Me.cboDepth.FormattingEnabled = True
        Me.cboDepth.Location = New System.Drawing.Point(200, 135)
        Me.cboDepth.Name = "cboDepth"
        Me.cboDepth.Size = New System.Drawing.Size(46, 21)
        Me.cboDepth.TabIndex = 13
        '
        'lbDepth
        '
        Me.lbDepth.AutoSize = True
        Me.lbDepth.Location = New System.Drawing.Point(5, 135)
        Me.lbDepth.Name = "lbDepth"
        Me.lbDepth.Size = New System.Drawing.Size(78, 13)
        Me.lbDepth.TabIndex = 143
        Me.lbDepth.Text = "Shadow Depth"
        '
        'tbHeight
        '
        Me.tbHeight.BackColor = System.Drawing.Color.White
        Me.tbHeight.ForeColor = System.Drawing.Color.Black
        Me.tbHeight.Location = New System.Drawing.Point(130, 220)
        Me.tbHeight.Name = "tbHeight"
        Me.tbHeight.Size = New System.Drawing.Size(118, 20)
        Me.tbHeight.TabIndex = 16
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(10, 225)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(107, 13)
        Me.Label1.TabIndex = 141
        Me.Label1.Text = "Note Height (60 max)"
        '
        'tbWidth
        '
        Me.tbWidth.BackColor = System.Drawing.Color.White
        Me.tbWidth.ForeColor = System.Drawing.Color.Black
        Me.tbWidth.Location = New System.Drawing.Point(130, 195)
        Me.tbWidth.Name = "tbWidth"
        Me.tbWidth.Size = New System.Drawing.Size(118, 20)
        Me.tbWidth.TabIndex = 15
        '
        'lbSize
        '
        Me.lbSize.AutoSize = True
        Me.lbSize.Location = New System.Drawing.Point(10, 200)
        Me.lbSize.Name = "lbSize"
        Me.lbSize.Size = New System.Drawing.Size(61, 13)
        Me.lbSize.TabIndex = 137
        Me.lbSize.Text = "Note Width"
        '
        'cmShadowColor
        '
        Me.cmShadowColor.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmShadowColor.Location = New System.Drawing.Point(174, 111)
        Me.cmShadowColor.Name = "cmShadowColor"
        Me.cmShadowColor.Size = New System.Drawing.Size(21, 21)
        Me.cmShadowColor.TabIndex = 11
        Me.cmShadowColor.Text = "1"
        Me.cmShadowColor.UseVisualStyleBackColor = True
        '
        'lbR5
        '
        Me.lbR5.AutoSize = True
        Me.lbR5.ForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.lbR5.Location = New System.Drawing.Point(5, 110)
        Me.lbR5.Name = "lbR5"
        Me.lbR5.Size = New System.Drawing.Size(119, 13)
        Me.lbR5.TabIndex = 67
        Me.lbR5.Text = "Simple Shadow Options"
        '
        'cbo3D
        '
        Me.cbo3D.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.cbo3D.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbo3D.ForeColor = System.Drawing.Color.White
        Me.cbo3D.FormattingEnabled = True
        Me.cbo3D.Location = New System.Drawing.Point(200, 110)
        Me.cbo3D.Name = "cbo3D"
        Me.cbo3D.Size = New System.Drawing.Size(46, 21)
        Me.cbo3D.TabIndex = 12
        '
        'cboA2
        '
        Me.cboA2.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.cboA2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboA2.ForeColor = System.Drawing.Color.White
        Me.cboA2.FormattingEnabled = True
        Me.cboA2.Location = New System.Drawing.Point(175, 85)
        Me.cboA2.Name = "cboA2"
        Me.cboA2.Size = New System.Drawing.Size(71, 21)
        Me.cboA2.TabIndex = 10
        '
        'lbR4
        '
        Me.lbR4.AutoSize = True
        Me.lbR4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.lbR4.Location = New System.Drawing.Point(5, 85)
        Me.lbR4.Name = "lbR4"
        Me.lbR4.Size = New System.Drawing.Size(156, 13)
        Me.lbR4.TabIndex = 64
        Me.lbR4.Text = "Background Gradient Opacity 2"
        '
        'cmBR
        '
        Me.cmBR.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmBR.Location = New System.Drawing.Point(225, 34)
        Me.cmBR.Name = "cmBR"
        Me.cmBR.Size = New System.Drawing.Size(20, 21)
        Me.cmBR.TabIndex = 8
        Me.cmBR.Text = ">"
        Me.cmBR.UseVisualStyleBackColor = True
        '
        'cmBD
        '
        Me.cmBD.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmBD.Location = New System.Drawing.Point(200, 34)
        Me.cmBD.Name = "cmBD"
        Me.cmBD.Size = New System.Drawing.Size(20, 21)
        Me.cmBD.TabIndex = 7
        Me.cmBD.Text = "˅"
        Me.cmBD.UseVisualStyleBackColor = True
        '
        'cmFR
        '
        Me.cmFR.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmFR.Location = New System.Drawing.Point(225, 10)
        Me.cmFR.Name = "cmFR"
        Me.cmFR.Size = New System.Drawing.Size(20, 21)
        Me.cmFR.TabIndex = 4
        Me.cmFR.Text = ">"
        Me.cmFR.UseVisualStyleBackColor = True
        '
        'cmFD
        '
        Me.cmFD.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmFD.Location = New System.Drawing.Point(200, 10)
        Me.cmFD.Name = "cmFD"
        Me.cmFD.Size = New System.Drawing.Size(20, 21)
        Me.cmFD.TabIndex = 3
        Me.cmFD.Text = "˅"
        Me.cmFD.UseVisualStyleBackColor = True
        '
        'cmB2
        '
        Me.cmB2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmB2.Location = New System.Drawing.Point(175, 34)
        Me.cmB2.Name = "cmB2"
        Me.cmB2.Size = New System.Drawing.Size(20, 21)
        Me.cmB2.TabIndex = 6
        Me.cmB2.Text = "2"
        Me.cmB2.UseVisualStyleBackColor = True
        '
        'cmB1
        '
        Me.cmB1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmB1.Location = New System.Drawing.Point(150, 34)
        Me.cmB1.Name = "cmB1"
        Me.cmB1.Size = New System.Drawing.Size(20, 21)
        Me.cmB1.TabIndex = 5
        Me.cmB1.Text = "1"
        Me.cmB1.UseVisualStyleBackColor = True
        '
        'lbR2
        '
        Me.lbR2.AutoSize = True
        Me.lbR2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.lbR2.Location = New System.Drawing.Point(5, 35)
        Me.lbR2.Name = "lbR2"
        Me.lbR2.Size = New System.Drawing.Size(135, 13)
        Me.lbR2.TabIndex = 57
        Me.lbR2.Text = "Background Gradient Color"
        '
        'cmF2
        '
        Me.cmF2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmF2.Location = New System.Drawing.Point(175, 10)
        Me.cmF2.Name = "cmF2"
        Me.cmF2.Size = New System.Drawing.Size(20, 21)
        Me.cmF2.TabIndex = 2
        Me.cmF2.Text = "2"
        Me.cmF2.UseVisualStyleBackColor = True
        '
        'cmRankFont
        '
        Me.cmRankFont.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmRankFont.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmRankFont.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmRankFont.ForeColor = System.Drawing.Color.Black
        Me.cmRankFont.Location = New System.Drawing.Point(175, 160)
        Me.cmRankFont.Name = "cmRankFont"
        Me.cmRankFont.Size = New System.Drawing.Size(70, 26)
        Me.cmRankFont.TabIndex = 14
        Me.cmRankFont.Text = "Font"
        Me.cmRankFont.UseVisualStyleBackColor = False
        '
        'cmF1
        '
        Me.cmF1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmF1.Location = New System.Drawing.Point(150, 10)
        Me.cmF1.Name = "cmF1"
        Me.cmF1.Size = New System.Drawing.Size(20, 21)
        Me.cmF1.TabIndex = 1
        Me.cmF1.Text = "1"
        Me.cmF1.UseVisualStyleBackColor = True
        '
        'lbR1
        '
        Me.lbR1.AutoSize = True
        Me.lbR1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.lbR1.Location = New System.Drawing.Point(5, 15)
        Me.lbR1.Name = "lbR1"
        Me.lbR1.Size = New System.Drawing.Size(98, 13)
        Me.lbR1.TabIndex = 54
        Me.lbR1.Text = "Font Gradient Color"
        '
        'lbR3
        '
        Me.lbR3.AutoSize = True
        Me.lbR3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.lbR3.Location = New System.Drawing.Point(5, 60)
        Me.lbR3.Name = "lbR3"
        Me.lbR3.Size = New System.Drawing.Size(156, 13)
        Me.lbR3.TabIndex = 53
        Me.lbR3.Text = "Background Gradient Opacity 1"
        '
        'cboA1
        '
        Me.cboA1.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.cboA1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboA1.ForeColor = System.Drawing.Color.White
        Me.cboA1.FormattingEnabled = True
        Me.cboA1.Location = New System.Drawing.Point(175, 60)
        Me.cboA1.Name = "cboA1"
        Me.cboA1.Size = New System.Drawing.Size(71, 21)
        Me.cboA1.TabIndex = 9
        '
        'pbNote
        '
        Me.pbNote.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.pbNote.Cursor = System.Windows.Forms.Cursors.Default
        Me.pbNote.Location = New System.Drawing.Point(12, 275)
        Me.pbNote.Name = "pbNote"
        Me.pbNote.Size = New System.Drawing.Size(256, 40)
        Me.pbNote.TabIndex = 92
        Me.pbNote.TabStop = False
        '
        'cmCancel
        '
        Me.cmCancel.Location = New System.Drawing.Point(445, 60)
        Me.cmCancel.Name = "cmCancel"
        Me.cmCancel.Size = New System.Drawing.Size(120, 37)
        Me.cmCancel.TabIndex = 25
        Me.cmCancel.Text = "Cancel"
        Me.cmCancel.UseVisualStyleBackColor = True
        '
        'cmOK
        '
        Me.cmOK.Location = New System.Drawing.Point(445, 15)
        Me.cmOK.Name = "cmOK"
        Me.cmOK.Size = New System.Drawing.Size(120, 37)
        Me.cmOK.TabIndex = 24
        Me.cmOK.Text = "OK"
        Me.cmOK.UseVisualStyleBackColor = True
        '
        'gbBack
        '
        Me.gbBack.Controls.Add(Me.cboScaling)
        Me.gbBack.Controls.Add(Me.Label7)
        Me.gbBack.Controls.Add(Me.cmFormColor)
        Me.gbBack.Controls.Add(Me.cmFormImage)
        Me.gbBack.Controls.Add(Me.cmNoImage)
        Me.gbBack.Location = New System.Drawing.Point(275, 10)
        Me.gbBack.Name = "gbBack"
        Me.gbBack.Size = New System.Drawing.Size(130, 135)
        Me.gbBack.TabIndex = 135
        Me.gbBack.TabStop = False
        Me.gbBack.Text = "Background"
        '
        'cboScaling
        '
        Me.cboScaling.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.cboScaling.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboScaling.ForeColor = System.Drawing.Color.White
        Me.cboScaling.FormattingEnabled = True
        Me.cboScaling.Location = New System.Drawing.Point(50, 105)
        Me.cboScaling.Name = "cboScaling"
        Me.cboScaling.Size = New System.Drawing.Size(70, 21)
        Me.cboScaling.TabIndex = 20
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.ForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.Label7.Location = New System.Drawing.Point(5, 110)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(42, 13)
        Me.Label7.TabIndex = 64
        Me.Label7.Text = "Scaling"
        '
        'cmFormColor
        '
        Me.cmFormColor.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmFormColor.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmFormColor.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmFormColor.ForeColor = System.Drawing.Color.Black
        Me.cmFormColor.Location = New System.Drawing.Point(5, 15)
        Me.cmFormColor.Name = "cmFormColor"
        Me.cmFormColor.Size = New System.Drawing.Size(115, 26)
        Me.cmFormColor.TabIndex = 17
        Me.cmFormColor.Text = "Panel Color"
        Me.cmFormColor.UseVisualStyleBackColor = False
        '
        'cmFormImage
        '
        Me.cmFormImage.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmFormImage.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmFormImage.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmFormImage.ForeColor = System.Drawing.Color.Black
        Me.cmFormImage.Location = New System.Drawing.Point(5, 75)
        Me.cmFormImage.Name = "cmFormImage"
        Me.cmFormImage.Size = New System.Drawing.Size(115, 26)
        Me.cmFormImage.TabIndex = 19
        Me.cmFormImage.Text = "Panel Image"
        Me.cmFormImage.UseVisualStyleBackColor = False
        '
        'cmNoImage
        '
        Me.cmNoImage.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmNoImage.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmNoImage.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmNoImage.ForeColor = System.Drawing.Color.Black
        Me.cmNoImage.Location = New System.Drawing.Point(5, 45)
        Me.cmNoImage.Name = "cmNoImage"
        Me.cmNoImage.Size = New System.Drawing.Size(115, 26)
        Me.cmNoImage.TabIndex = 18
        Me.cmNoImage.Text = "No Image"
        Me.cmNoImage.UseVisualStyleBackColor = False
        '
        'cboOVLScaling
        '
        Me.cboOVLScaling.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.cboOVLScaling.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboOVLScaling.ForeColor = System.Drawing.Color.White
        Me.cboOVLScaling.FormattingEnabled = True
        Me.cboOVLScaling.Location = New System.Drawing.Point(50, 75)
        Me.cboOVLScaling.Name = "cboOVLScaling"
        Me.cboOVLScaling.Size = New System.Drawing.Size(73, 21)
        Me.cboOVLScaling.TabIndex = 23
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.Label2.Location = New System.Drawing.Point(5, 80)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(42, 13)
        Me.Label2.TabIndex = 66
        Me.Label2.Text = "Scaling"
        '
        'cmOverlay
        '
        Me.cmOverlay.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmOverlay.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmOverlay.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmOverlay.ForeColor = System.Drawing.Color.Black
        Me.cmOverlay.Location = New System.Drawing.Point(5, 45)
        Me.cmOverlay.Name = "cmOverlay"
        Me.cmOverlay.Size = New System.Drawing.Size(118, 26)
        Me.cmOverlay.TabIndex = 22
        Me.cmOverlay.Text = "Overlay Image"
        Me.cmOverlay.UseVisualStyleBackColor = False
        '
        'cmCopy01
        '
        Me.cmCopy01.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmCopy01.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmCopy01.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmCopy01.ForeColor = System.Drawing.Color.Black
        Me.cmCopy01.Location = New System.Drawing.Point(430, 120)
        Me.cmCopy01.Name = "cmCopy01"
        Me.cmCopy01.Size = New System.Drawing.Size(145, 26)
        Me.cmCopy01.TabIndex = 26
        Me.cmCopy01.Text = "Copy Note 1 settings"
        Me.cmCopy01.UseVisualStyleBackColor = False
        '
        'cmCopy02
        '
        Me.cmCopy02.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmCopy02.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmCopy02.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmCopy02.ForeColor = System.Drawing.Color.Black
        Me.cmCopy02.Location = New System.Drawing.Point(430, 150)
        Me.cmCopy02.Name = "cmCopy02"
        Me.cmCopy02.Size = New System.Drawing.Size(145, 26)
        Me.cmCopy02.TabIndex = 27
        Me.cmCopy02.Text = "Copy Note 2 settings"
        Me.cmCopy02.UseVisualStyleBackColor = False
        '
        'cmCopy03
        '
        Me.cmCopy03.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmCopy03.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmCopy03.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmCopy03.ForeColor = System.Drawing.Color.Black
        Me.cmCopy03.Location = New System.Drawing.Point(430, 180)
        Me.cmCopy03.Name = "cmCopy03"
        Me.cmCopy03.Size = New System.Drawing.Size(145, 26)
        Me.cmCopy03.TabIndex = 28
        Me.cmCopy03.Text = "Copy Note 3 settings"
        Me.cmCopy03.UseVisualStyleBackColor = False
        '
        'cmCopy04
        '
        Me.cmCopy04.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmCopy04.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmCopy04.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmCopy04.ForeColor = System.Drawing.Color.Black
        Me.cmCopy04.Location = New System.Drawing.Point(430, 210)
        Me.cmCopy04.Name = "cmCopy04"
        Me.cmCopy04.Size = New System.Drawing.Size(145, 26)
        Me.cmCopy04.TabIndex = 29
        Me.cmCopy04.Text = "Copy Note 4 settings"
        Me.cmCopy04.UseVisualStyleBackColor = False
        '
        'cmCopyAll
        '
        Me.cmCopyAll.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmCopyAll.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmCopyAll.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmCopyAll.ForeColor = System.Drawing.Color.Black
        Me.cmCopyAll.Location = New System.Drawing.Point(430, 255)
        Me.cmCopyAll.Name = "cmCopyAll"
        Me.cmCopyAll.Size = New System.Drawing.Size(145, 26)
        Me.cmCopyAll.TabIndex = 30
        Me.cmCopyAll.Text = "Set ALL notes to this Style"
        Me.cmCopyAll.UseVisualStyleBackColor = False
        '
        'cmCopySize
        '
        Me.cmCopySize.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmCopySize.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmCopySize.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmCopySize.ForeColor = System.Drawing.Color.Black
        Me.cmCopySize.Location = New System.Drawing.Point(430, 285)
        Me.cmCopySize.Name = "cmCopySize"
        Me.cmCopySize.Size = New System.Drawing.Size(145, 26)
        Me.cmCopySize.TabIndex = 31
        Me.cmCopySize.Text = "Set ALL notes to this Size"
        Me.cmCopySize.UseVisualStyleBackColor = False
        '
        'cmOVLNoImage
        '
        Me.cmOVLNoImage.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmOVLNoImage.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmOVLNoImage.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmOVLNoImage.ForeColor = System.Drawing.Color.Black
        Me.cmOVLNoImage.Location = New System.Drawing.Point(5, 15)
        Me.cmOVLNoImage.Name = "cmOVLNoImage"
        Me.cmOVLNoImage.Size = New System.Drawing.Size(118, 26)
        Me.cmOVLNoImage.TabIndex = 21
        Me.cmOVLNoImage.Text = "No Image"
        Me.cmOVLNoImage.UseVisualStyleBackColor = False
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.cmOVLNoImage)
        Me.GroupBox1.Controls.Add(Me.cmOverlay)
        Me.GroupBox1.Controls.Add(Me.cboOVLScaling)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Location = New System.Drawing.Point(275, 145)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(130, 110)
        Me.GroupBox1.TabIndex = 143
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Overlay"
        '
        'frmLabelSetup
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(599, 344)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.cmCopySize)
        Me.Controls.Add(Me.cmCopyAll)
        Me.Controls.Add(Me.cmCopy04)
        Me.Controls.Add(Me.cmCopy03)
        Me.Controls.Add(Me.cmCopy02)
        Me.Controls.Add(Me.cmCopy01)
        Me.Controls.Add(Me.gbBack)
        Me.Controls.Add(Me.cmCancel)
        Me.Controls.Add(Me.cmOK)
        Me.Controls.Add(Me.pbNote)
        Me.Controls.Add(Me.gbLabel)
        Me.DoubleBuffered = True
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmLabelSetup"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Text Object Setup"
        Me.gbLabel.ResumeLayout(False)
        Me.gbLabel.PerformLayout()
        CType(Me.pbNote, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gbBack.ResumeLayout(False)
        Me.gbBack.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents gbLabel As GroupBox
    Friend WithEvents cmShadowColor As Button
    Friend WithEvents lbR5 As Label
    Friend WithEvents cbo3D As ComboBox
    Friend WithEvents cboA2 As ComboBox
    Friend WithEvents lbR4 As Label
    Friend WithEvents cmBR As Button
    Friend WithEvents cmBD As Button
    Friend WithEvents cmFR As Button
    Friend WithEvents cmFD As Button
    Friend WithEvents cmB2 As Button
    Friend WithEvents cmB1 As Button
    Friend WithEvents lbR2 As Label
    Friend WithEvents cmF2 As Button
    Friend WithEvents cmRankFont As Button
    Friend WithEvents cmF1 As Button
    Friend WithEvents lbR1 As Label
    Friend WithEvents lbR3 As Label
    Friend WithEvents cboA1 As ComboBox
    Friend WithEvents pbNote As PictureBox
    Friend WithEvents cmCancel As Button
    Friend WithEvents cmOK As Button
    Friend WithEvents ColorDialog1 As ColorDialog
    Friend WithEvents lbSize As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents tbWidth As TextBox
    Friend WithEvents tbHeight As TextBox
    Friend WithEvents gbBack As GroupBox
    Friend WithEvents cboScaling As ComboBox
    Friend WithEvents Label7 As Label
    Friend WithEvents cmFormColor As Button
    Friend WithEvents cmFormImage As Button
    Friend WithEvents cmNoImage As Button
    Friend WithEvents cmCopy01 As Button
    Friend WithEvents cmCopy02 As Button
    Friend WithEvents cmCopy03 As Button
    Friend WithEvents cmCopy04 As Button
    Friend WithEvents cmCopyAll As Button
    Friend WithEvents cmCopySize As Button
    Friend WithEvents cboDepth As ComboBox
    Friend WithEvents lbDepth As Label
    Friend WithEvents cboOVLScaling As ComboBox
    Friend WithEvents Label2 As Label
    Friend WithEvents cmOverlay As Button
    Friend WithEvents cmOVLNoImage As Button
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents ToolTip1 As ToolTip
End Class
