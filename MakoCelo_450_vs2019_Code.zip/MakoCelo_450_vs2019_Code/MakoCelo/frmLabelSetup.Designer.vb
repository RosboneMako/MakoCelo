﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmLabelSetup
  Inherits System.Windows.Forms.Form

  'Form overrides dispose to clean up the component list.
  <System.Diagnostics.DebuggerNonUserCode()> _
  Protected Overrides Sub Dispose(ByVal disposing As Boolean)
    Try
      If disposing AndAlso components IsNot Nothing Then
        components.Dispose()
      End If
    Finally
      MyBase.Dispose(disposing)
    End Try
  End Sub

  'Required by the Windows Form Designer
  Private components As System.ComponentModel.IContainer

  'NOTE: The following procedure is required by the Windows Form Designer
  'It can be modified using the Windows Form Designer.  
  'Do not modify it using the code editor.
  <System.Diagnostics.DebuggerStepThrough()> _
  Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmLabelSetup))
        Me.gbLabel = New System.Windows.Forms.GroupBox()
        Me.lbShadowColor = New System.Windows.Forms.Label()
        Me.lbBordColor = New System.Windows.Forms.Label()
        Me.lbB2 = New System.Windows.Forms.Label()
        Me.lbF2 = New System.Windows.Forms.Label()
        Me.lbB1 = New System.Windows.Forms.Label()
        Me.lbF1 = New System.Windows.Forms.Label()
        Me.cmBordColor = New System.Windows.Forms.Button()
        Me.cboBord = New System.Windows.Forms.ComboBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.cboDepth = New System.Windows.Forms.ComboBox()
        Me.lbDepth = New System.Windows.Forms.Label()
        Me.tbHeight = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.tbWidth = New System.Windows.Forms.TextBox()
        Me.lbSize = New System.Windows.Forms.Label()
        Me.cmShadowColor = New System.Windows.Forms.Button()
        Me.lbR5 = New System.Windows.Forms.Label()
        Me.cbo3D = New System.Windows.Forms.ComboBox()
        Me.cmRankFont = New System.Windows.Forms.Button()
        Me.cboA2 = New System.Windows.Forms.ComboBox()
        Me.lbR4 = New System.Windows.Forms.Label()
        Me.cmBR = New System.Windows.Forms.Button()
        Me.cmBD = New System.Windows.Forms.Button()
        Me.cmFR = New System.Windows.Forms.Button()
        Me.cmFD = New System.Windows.Forms.Button()
        Me.cmB2 = New System.Windows.Forms.Button()
        Me.cmB1 = New System.Windows.Forms.Button()
        Me.lbR2 = New System.Windows.Forms.Label()
        Me.cmF2 = New System.Windows.Forms.Button()
        Me.cmF1 = New System.Windows.Forms.Button()
        Me.lbR1 = New System.Windows.Forms.Label()
        Me.lbR3 = New System.Windows.Forms.Label()
        Me.cboA1 = New System.Windows.Forms.ComboBox()
        Me.pbNote = New System.Windows.Forms.PictureBox()
        Me.cmCancel = New System.Windows.Forms.Button()
        Me.cmOK = New System.Windows.Forms.Button()
        Me.ColorDialog1 = New System.Windows.Forms.ColorDialog()
        Me.gbBack = New System.Windows.Forms.GroupBox()
        Me.lbBordPanColor = New System.Windows.Forms.Label()
        Me.chkCardBack = New System.Windows.Forms.CheckBox()
        Me.cmBordPanColor = New System.Windows.Forms.Button()
        Me.cboBordPan = New System.Windows.Forms.ComboBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.cboScaling = New System.Windows.Forms.ComboBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.cmFormColor = New System.Windows.Forms.Button()
        Me.cmFormImage = New System.Windows.Forms.Button()
        Me.cmNoImage = New System.Windows.Forms.Button()
        Me.cboOVLScaling = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.cmOverlay = New System.Windows.Forms.Button()
        Me.cmCopy01 = New System.Windows.Forms.Button()
        Me.cmCopy02 = New System.Windows.Forms.Button()
        Me.cmCopy03 = New System.Windows.Forms.Button()
        Me.cmCopy04 = New System.Windows.Forms.Button()
        Me.cmCopyAll = New System.Windows.Forms.Button()
        Me.cmCopySize = New System.Windows.Forms.Button()
        Me.cmOVLNoImage = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.cboBordWidth = New System.Windows.Forms.ComboBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.cboBordPanWidth = New System.Windows.Forms.ComboBox()
        Me.gbLabel.SuspendLayout()
        CType(Me.pbNote, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gbBack.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'gbLabel
        '
        Me.gbLabel.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.gbLabel.Controls.Add(Me.Label4)
        Me.gbLabel.Controls.Add(Me.cboBordWidth)
        Me.gbLabel.Controls.Add(Me.lbShadowColor)
        Me.gbLabel.Controls.Add(Me.lbBordColor)
        Me.gbLabel.Controls.Add(Me.lbB2)
        Me.gbLabel.Controls.Add(Me.lbF2)
        Me.gbLabel.Controls.Add(Me.lbB1)
        Me.gbLabel.Controls.Add(Me.lbF1)
        Me.gbLabel.Controls.Add(Me.cmBordColor)
        Me.gbLabel.Controls.Add(Me.cboBord)
        Me.gbLabel.Controls.Add(Me.Label6)
        Me.gbLabel.Controls.Add(Me.cboDepth)
        Me.gbLabel.Controls.Add(Me.lbDepth)
        Me.gbLabel.Controls.Add(Me.tbHeight)
        Me.gbLabel.Controls.Add(Me.Label1)
        Me.gbLabel.Controls.Add(Me.tbWidth)
        Me.gbLabel.Controls.Add(Me.lbSize)
        Me.gbLabel.Controls.Add(Me.cmShadowColor)
        Me.gbLabel.Controls.Add(Me.lbR5)
        Me.gbLabel.Controls.Add(Me.cbo3D)
        Me.gbLabel.Controls.Add(Me.cmRankFont)
        Me.gbLabel.Controls.Add(Me.cboA2)
        Me.gbLabel.Controls.Add(Me.lbR4)
        Me.gbLabel.Controls.Add(Me.cmBR)
        Me.gbLabel.Controls.Add(Me.cmBD)
        Me.gbLabel.Controls.Add(Me.cmFR)
        Me.gbLabel.Controls.Add(Me.cmFD)
        Me.gbLabel.Controls.Add(Me.cmB2)
        Me.gbLabel.Controls.Add(Me.cmB1)
        Me.gbLabel.Controls.Add(Me.lbR2)
        Me.gbLabel.Controls.Add(Me.cmF2)
        Me.gbLabel.Controls.Add(Me.cmF1)
        Me.gbLabel.Controls.Add(Me.lbR1)
        Me.gbLabel.Controls.Add(Me.lbR3)
        Me.gbLabel.Controls.Add(Me.cboA1)
        Me.gbLabel.ForeColor = System.Drawing.Color.Black
        Me.gbLabel.Location = New System.Drawing.Point(10, 10)
        Me.gbLabel.Name = "gbLabel"
        Me.gbLabel.Size = New System.Drawing.Size(304, 352)
        Me.gbLabel.TabIndex = 74
        Me.gbLabel.TabStop = False
        Me.gbLabel.Text = "Text Setup"
        '
        'lbShadowColor
        '
        Me.lbShadowColor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lbShadowColor.Location = New System.Drawing.Point(179, 221)
        Me.lbShadowColor.Name = "lbShadowColor"
        Me.lbShadowColor.Size = New System.Drawing.Size(10, 21)
        Me.lbShadowColor.TabIndex = 151
        '
        'lbBordColor
        '
        Me.lbBordColor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lbBordColor.Location = New System.Drawing.Point(178, 157)
        Me.lbBordColor.Name = "lbBordColor"
        Me.lbBordColor.Size = New System.Drawing.Size(10, 21)
        Me.lbBordColor.TabIndex = 150
        '
        'lbB2
        '
        Me.lbB2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lbB2.Location = New System.Drawing.Point(229, 71)
        Me.lbB2.Name = "lbB2"
        Me.lbB2.Size = New System.Drawing.Size(10, 21)
        Me.lbB2.TabIndex = 149
        '
        'lbF2
        '
        Me.lbF2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lbF2.Location = New System.Drawing.Point(229, 47)
        Me.lbF2.Name = "lbF2"
        Me.lbF2.Size = New System.Drawing.Size(10, 21)
        Me.lbF2.TabIndex = 148
        '
        'lbB1
        '
        Me.lbB1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lbB1.Location = New System.Drawing.Point(193, 71)
        Me.lbB1.Name = "lbB1"
        Me.lbB1.Size = New System.Drawing.Size(10, 21)
        Me.lbB1.TabIndex = 147
        '
        'lbF1
        '
        Me.lbF1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lbF1.Location = New System.Drawing.Point(193, 47)
        Me.lbF1.Name = "lbF1"
        Me.lbF1.Size = New System.Drawing.Size(10, 21)
        Me.lbF1.TabIndex = 144
        '
        'cmBordColor
        '
        Me.cmBordColor.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmBordColor.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmBordColor.Location = New System.Drawing.Point(157, 157)
        Me.cmBordColor.Name = "cmBordColor"
        Me.cmBordColor.Size = New System.Drawing.Size(20, 21)
        Me.cmBordColor.TabIndex = 146
        Me.cmBordColor.Text = "1"
        Me.cmBordColor.UseVisualStyleBackColor = False
        '
        'cboBord
        '
        Me.cboBord.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.cboBord.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboBord.ForeColor = System.Drawing.Color.White
        Me.cboBord.FormattingEnabled = True
        Me.cboBord.Location = New System.Drawing.Point(193, 157)
        Me.cboBord.Name = "cboBord"
        Me.cboBord.Size = New System.Drawing.Size(96, 21)
        Me.cboBord.TabIndex = 145
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.ForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.Label6.Location = New System.Drawing.Point(4, 157)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(38, 13)
        Me.Label6.TabIndex = 144
        Me.Label6.Text = "Border"
        '
        'cboDepth
        '
        Me.cboDepth.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.cboDepth.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboDepth.ForeColor = System.Drawing.Color.White
        Me.cboDepth.FormattingEnabled = True
        Me.cboDepth.Location = New System.Drawing.Point(194, 246)
        Me.cboDepth.Name = "cboDepth"
        Me.cboDepth.Size = New System.Drawing.Size(97, 21)
        Me.cboDepth.TabIndex = 13
        '
        'lbDepth
        '
        Me.lbDepth.AutoSize = True
        Me.lbDepth.Location = New System.Drawing.Point(2, 245)
        Me.lbDepth.Name = "lbDepth"
        Me.lbDepth.Size = New System.Drawing.Size(78, 13)
        Me.lbDepth.TabIndex = 143
        Me.lbDepth.Text = "Shadow Depth"
        '
        'tbHeight
        '
        Me.tbHeight.BackColor = System.Drawing.Color.White
        Me.tbHeight.ForeColor = System.Drawing.Color.Black
        Me.tbHeight.Location = New System.Drawing.Point(173, 315)
        Me.tbHeight.Name = "tbHeight"
        Me.tbHeight.Size = New System.Drawing.Size(118, 20)
        Me.tbHeight.TabIndex = 16
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(7, 317)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(107, 13)
        Me.Label1.TabIndex = 141
        Me.Label1.Text = "Note Height (60 max)"
        '
        'tbWidth
        '
        Me.tbWidth.BackColor = System.Drawing.Color.White
        Me.tbWidth.ForeColor = System.Drawing.Color.Black
        Me.tbWidth.Location = New System.Drawing.Point(173, 290)
        Me.tbWidth.Name = "tbWidth"
        Me.tbWidth.Size = New System.Drawing.Size(118, 20)
        Me.tbWidth.TabIndex = 15
        '
        'lbSize
        '
        Me.lbSize.AutoSize = True
        Me.lbSize.Location = New System.Drawing.Point(7, 275)
        Me.lbSize.Name = "lbSize"
        Me.lbSize.Size = New System.Drawing.Size(61, 13)
        Me.lbSize.TabIndex = 137
        Me.lbSize.Text = "Note Width"
        '
        'cmShadowColor
        '
        Me.cmShadowColor.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmShadowColor.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmShadowColor.Location = New System.Drawing.Point(158, 221)
        Me.cmShadowColor.Name = "cmShadowColor"
        Me.cmShadowColor.Size = New System.Drawing.Size(20, 21)
        Me.cmShadowColor.TabIndex = 11
        Me.cmShadowColor.Text = "1"
        Me.cmShadowColor.UseVisualStyleBackColor = False
        '
        'lbR5
        '
        Me.lbR5.AutoSize = True
        Me.lbR5.ForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.lbR5.Location = New System.Drawing.Point(2, 221)
        Me.lbR5.Name = "lbR5"
        Me.lbR5.Size = New System.Drawing.Size(119, 13)
        Me.lbR5.TabIndex = 67
        Me.lbR5.Text = "Simple Shadow Options"
        '
        'cbo3D
        '
        Me.cbo3D.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.cbo3D.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbo3D.ForeColor = System.Drawing.Color.White
        Me.cbo3D.FormattingEnabled = True
        Me.cbo3D.Location = New System.Drawing.Point(194, 221)
        Me.cbo3D.Name = "cbo3D"
        Me.cbo3D.Size = New System.Drawing.Size(96, 21)
        Me.cbo3D.TabIndex = 12
        '
        'cmRankFont
        '
        Me.cmRankFont.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmRankFont.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmRankFont.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmRankFont.ForeColor = System.Drawing.Color.Black
        Me.cmRankFont.Location = New System.Drawing.Point(219, 15)
        Me.cmRankFont.Name = "cmRankFont"
        Me.cmRankFont.Size = New System.Drawing.Size(70, 26)
        Me.cmRankFont.TabIndex = 14
        Me.cmRankFont.Text = "Font"
        Me.cmRankFont.UseVisualStyleBackColor = False
        '
        'cboA2
        '
        Me.cboA2.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.cboA2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboA2.ForeColor = System.Drawing.Color.White
        Me.cboA2.FormattingEnabled = True
        Me.cboA2.Location = New System.Drawing.Point(193, 122)
        Me.cboA2.Name = "cboA2"
        Me.cboA2.Size = New System.Drawing.Size(97, 21)
        Me.cboA2.TabIndex = 10
        '
        'lbR4
        '
        Me.lbR4.AutoSize = True
        Me.lbR4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.lbR4.Location = New System.Drawing.Point(3, 122)
        Me.lbR4.Name = "lbR4"
        Me.lbR4.Size = New System.Drawing.Size(156, 13)
        Me.lbR4.TabIndex = 64
        Me.lbR4.Text = "Background Gradient Opacity 2"
        '
        'cmBR
        '
        Me.cmBR.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmBR.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmBR.Location = New System.Drawing.Point(269, 71)
        Me.cmBR.Name = "cmBR"
        Me.cmBR.Size = New System.Drawing.Size(20, 21)
        Me.cmBR.TabIndex = 8
        Me.cmBR.Text = ">"
        Me.cmBR.UseVisualStyleBackColor = False
        '
        'cmBD
        '
        Me.cmBD.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmBD.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmBD.Location = New System.Drawing.Point(244, 71)
        Me.cmBD.Name = "cmBD"
        Me.cmBD.Size = New System.Drawing.Size(20, 21)
        Me.cmBD.TabIndex = 7
        Me.cmBD.Text = "˅"
        Me.cmBD.UseVisualStyleBackColor = False
        '
        'cmFR
        '
        Me.cmFR.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmFR.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmFR.Location = New System.Drawing.Point(269, 47)
        Me.cmFR.Name = "cmFR"
        Me.cmFR.Size = New System.Drawing.Size(20, 21)
        Me.cmFR.TabIndex = 4
        Me.cmFR.Text = ">"
        Me.cmFR.UseVisualStyleBackColor = False
        '
        'cmFD
        '
        Me.cmFD.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmFD.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmFD.Location = New System.Drawing.Point(244, 47)
        Me.cmFD.Name = "cmFD"
        Me.cmFD.Size = New System.Drawing.Size(20, 21)
        Me.cmFD.TabIndex = 3
        Me.cmFD.Text = "˅"
        Me.cmFD.UseVisualStyleBackColor = False
        '
        'cmB2
        '
        Me.cmB2.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmB2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmB2.Location = New System.Drawing.Point(208, 71)
        Me.cmB2.Name = "cmB2"
        Me.cmB2.Size = New System.Drawing.Size(20, 21)
        Me.cmB2.TabIndex = 6
        Me.cmB2.Text = "2"
        Me.cmB2.UseVisualStyleBackColor = False
        '
        'cmB1
        '
        Me.cmB1.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmB1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmB1.Location = New System.Drawing.Point(172, 71)
        Me.cmB1.Name = "cmB1"
        Me.cmB1.Size = New System.Drawing.Size(20, 21)
        Me.cmB1.TabIndex = 5
        Me.cmB1.Text = "1"
        Me.cmB1.UseVisualStyleBackColor = False
        '
        'lbR2
        '
        Me.lbR2.AutoSize = True
        Me.lbR2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.lbR2.Location = New System.Drawing.Point(4, 72)
        Me.lbR2.Name = "lbR2"
        Me.lbR2.Size = New System.Drawing.Size(135, 13)
        Me.lbR2.TabIndex = 57
        Me.lbR2.Text = "Background Gradient Color"
        '
        'cmF2
        '
        Me.cmF2.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmF2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmF2.Location = New System.Drawing.Point(208, 47)
        Me.cmF2.Name = "cmF2"
        Me.cmF2.Size = New System.Drawing.Size(20, 21)
        Me.cmF2.TabIndex = 2
        Me.cmF2.Text = "2"
        Me.cmF2.UseVisualStyleBackColor = False
        '
        'cmF1
        '
        Me.cmF1.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmF1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmF1.Location = New System.Drawing.Point(172, 47)
        Me.cmF1.Name = "cmF1"
        Me.cmF1.Size = New System.Drawing.Size(20, 21)
        Me.cmF1.TabIndex = 1
        Me.cmF1.Text = "1"
        Me.cmF1.UseVisualStyleBackColor = False
        '
        'lbR1
        '
        Me.lbR1.AutoSize = True
        Me.lbR1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.lbR1.Location = New System.Drawing.Point(3, 49)
        Me.lbR1.Name = "lbR1"
        Me.lbR1.Size = New System.Drawing.Size(98, 13)
        Me.lbR1.TabIndex = 54
        Me.lbR1.Text = "Font Gradient Color"
        '
        'lbR3
        '
        Me.lbR3.AutoSize = True
        Me.lbR3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.lbR3.Location = New System.Drawing.Point(4, 97)
        Me.lbR3.Name = "lbR3"
        Me.lbR3.Size = New System.Drawing.Size(156, 13)
        Me.lbR3.TabIndex = 53
        Me.lbR3.Text = "Background Gradient Opacity 1"
        '
        'cboA1
        '
        Me.cboA1.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.cboA1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboA1.ForeColor = System.Drawing.Color.White
        Me.cboA1.FormattingEnabled = True
        Me.cboA1.Location = New System.Drawing.Point(193, 97)
        Me.cboA1.Name = "cboA1"
        Me.cboA1.Size = New System.Drawing.Size(97, 21)
        Me.cboA1.TabIndex = 9
        '
        'pbNote
        '
        Me.pbNote.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.pbNote.Cursor = System.Windows.Forms.Cursors.Default
        Me.pbNote.Location = New System.Drawing.Point(10, 378)
        Me.pbNote.Name = "pbNote"
        Me.pbNote.Size = New System.Drawing.Size(256, 40)
        Me.pbNote.TabIndex = 92
        Me.pbNote.TabStop = False
        '
        'cmCancel
        '
        Me.cmCancel.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmCancel.Location = New System.Drawing.Point(551, 80)
        Me.cmCancel.Name = "cmCancel"
        Me.cmCancel.Size = New System.Drawing.Size(120, 37)
        Me.cmCancel.TabIndex = 25
        Me.cmCancel.Text = "Cancel"
        Me.cmCancel.UseVisualStyleBackColor = False
        '
        'cmOK
        '
        Me.cmOK.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmOK.Location = New System.Drawing.Point(551, 35)
        Me.cmOK.Name = "cmOK"
        Me.cmOK.Size = New System.Drawing.Size(120, 37)
        Me.cmOK.TabIndex = 24
        Me.cmOK.Text = "OK"
        Me.cmOK.UseVisualStyleBackColor = False
        '
        'gbBack
        '
        Me.gbBack.Controls.Add(Me.Label5)
        Me.gbBack.Controls.Add(Me.lbBordPanColor)
        Me.gbBack.Controls.Add(Me.cboBordPanWidth)
        Me.gbBack.Controls.Add(Me.chkCardBack)
        Me.gbBack.Controls.Add(Me.cmBordPanColor)
        Me.gbBack.Controls.Add(Me.cboBordPan)
        Me.gbBack.Controls.Add(Me.Label3)
        Me.gbBack.Controls.Add(Me.cboScaling)
        Me.gbBack.Controls.Add(Me.Label7)
        Me.gbBack.Controls.Add(Me.cmFormColor)
        Me.gbBack.Controls.Add(Me.cmFormImage)
        Me.gbBack.Controls.Add(Me.cmNoImage)
        Me.gbBack.Location = New System.Drawing.Point(320, 10)
        Me.gbBack.Name = "gbBack"
        Me.gbBack.Size = New System.Drawing.Size(202, 216)
        Me.gbBack.TabIndex = 135
        Me.gbBack.TabStop = False
        Me.gbBack.Text = "Background"
        '
        'lbBordPanColor
        '
        Me.lbBordPanColor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lbBordPanColor.Location = New System.Drawing.Point(79, 160)
        Me.lbBordPanColor.Name = "lbBordPanColor"
        Me.lbBordPanColor.Size = New System.Drawing.Size(10, 21)
        Me.lbBordPanColor.TabIndex = 151
        '
        'chkCardBack
        '
        Me.chkCardBack.AutoSize = True
        Me.chkCardBack.Location = New System.Drawing.Point(9, 134)
        Me.chkCardBack.Name = "chkCardBack"
        Me.chkCardBack.Size = New System.Drawing.Size(143, 17)
        Me.chkCardBack.TabIndex = 68
        Me.chkCardBack.Text = "Use image on playercard"
        Me.chkCardBack.UseVisualStyleBackColor = True
        '
        'cmBordPanColor
        '
        Me.cmBordPanColor.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmBordPanColor.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmBordPanColor.Location = New System.Drawing.Point(58, 160)
        Me.cmBordPanColor.Name = "cmBordPanColor"
        Me.cmBordPanColor.Size = New System.Drawing.Size(20, 21)
        Me.cmBordPanColor.TabIndex = 67
        Me.cmBordPanColor.Text = "1"
        Me.cmBordPanColor.UseVisualStyleBackColor = False
        '
        'cboBordPan
        '
        Me.cboBordPan.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.cboBordPan.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboBordPan.ForeColor = System.Drawing.Color.White
        Me.cboBordPan.FormattingEnabled = True
        Me.cboBordPan.Location = New System.Drawing.Point(107, 160)
        Me.cboBordPan.Name = "cboBordPan"
        Me.cboBordPan.Size = New System.Drawing.Size(89, 21)
        Me.cboBordPan.TabIndex = 66
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.Label3.Location = New System.Drawing.Point(5, 162)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(38, 13)
        Me.Label3.TabIndex = 65
        Me.Label3.Text = "Border"
        '
        'cboScaling
        '
        Me.cboScaling.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.cboScaling.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboScaling.ForeColor = System.Drawing.Color.White
        Me.cboScaling.FormattingEnabled = True
        Me.cboScaling.Location = New System.Drawing.Point(107, 107)
        Me.cboScaling.Name = "cboScaling"
        Me.cboScaling.Size = New System.Drawing.Size(89, 21)
        Me.cboScaling.TabIndex = 20
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.ForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.Label7.Location = New System.Drawing.Point(5, 110)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(42, 13)
        Me.Label7.TabIndex = 64
        Me.Label7.Text = "Scaling"
        '
        'cmFormColor
        '
        Me.cmFormColor.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmFormColor.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmFormColor.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmFormColor.ForeColor = System.Drawing.Color.Black
        Me.cmFormColor.Location = New System.Drawing.Point(5, 15)
        Me.cmFormColor.Name = "cmFormColor"
        Me.cmFormColor.Size = New System.Drawing.Size(191, 26)
        Me.cmFormColor.TabIndex = 17
        Me.cmFormColor.Text = "Panel Color"
        Me.cmFormColor.UseVisualStyleBackColor = False
        '
        'cmFormImage
        '
        Me.cmFormImage.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmFormImage.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmFormImage.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmFormImage.ForeColor = System.Drawing.Color.Black
        Me.cmFormImage.Location = New System.Drawing.Point(5, 75)
        Me.cmFormImage.Name = "cmFormImage"
        Me.cmFormImage.Size = New System.Drawing.Size(191, 26)
        Me.cmFormImage.TabIndex = 19
        Me.cmFormImage.Text = "Panel Image"
        Me.cmFormImage.UseVisualStyleBackColor = False
        '
        'cmNoImage
        '
        Me.cmNoImage.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmNoImage.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmNoImage.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmNoImage.ForeColor = System.Drawing.Color.Black
        Me.cmNoImage.Location = New System.Drawing.Point(5, 45)
        Me.cmNoImage.Name = "cmNoImage"
        Me.cmNoImage.Size = New System.Drawing.Size(191, 26)
        Me.cmNoImage.TabIndex = 18
        Me.cmNoImage.Text = "No Image"
        Me.cmNoImage.UseVisualStyleBackColor = False
        '
        'cboOVLScaling
        '
        Me.cboOVLScaling.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.cboOVLScaling.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboOVLScaling.ForeColor = System.Drawing.Color.White
        Me.cboOVLScaling.FormattingEnabled = True
        Me.cboOVLScaling.Location = New System.Drawing.Point(94, 80)
        Me.cboOVLScaling.Name = "cboOVLScaling"
        Me.cboOVLScaling.Size = New System.Drawing.Size(102, 21)
        Me.cboOVLScaling.TabIndex = 23
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.Label2.Location = New System.Drawing.Point(5, 84)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(42, 13)
        Me.Label2.TabIndex = 66
        Me.Label2.Text = "Scaling"
        '
        'cmOverlay
        '
        Me.cmOverlay.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmOverlay.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmOverlay.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmOverlay.ForeColor = System.Drawing.Color.Black
        Me.cmOverlay.Location = New System.Drawing.Point(5, 49)
        Me.cmOverlay.Name = "cmOverlay"
        Me.cmOverlay.Size = New System.Drawing.Size(191, 26)
        Me.cmOverlay.TabIndex = 22
        Me.cmOverlay.Text = "Overlay Image"
        Me.cmOverlay.UseVisualStyleBackColor = False
        '
        'cmCopy01
        '
        Me.cmCopy01.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmCopy01.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmCopy01.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmCopy01.ForeColor = System.Drawing.Color.Black
        Me.cmCopy01.Location = New System.Drawing.Point(536, 140)
        Me.cmCopy01.Name = "cmCopy01"
        Me.cmCopy01.Size = New System.Drawing.Size(145, 26)
        Me.cmCopy01.TabIndex = 26
        Me.cmCopy01.Text = "Copy Note 1 settings"
        Me.cmCopy01.UseVisualStyleBackColor = False
        '
        'cmCopy02
        '
        Me.cmCopy02.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmCopy02.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmCopy02.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmCopy02.ForeColor = System.Drawing.Color.Black
        Me.cmCopy02.Location = New System.Drawing.Point(536, 170)
        Me.cmCopy02.Name = "cmCopy02"
        Me.cmCopy02.Size = New System.Drawing.Size(145, 26)
        Me.cmCopy02.TabIndex = 27
        Me.cmCopy02.Text = "Copy Note 2 settings"
        Me.cmCopy02.UseVisualStyleBackColor = False
        '
        'cmCopy03
        '
        Me.cmCopy03.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmCopy03.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmCopy03.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmCopy03.ForeColor = System.Drawing.Color.Black
        Me.cmCopy03.Location = New System.Drawing.Point(536, 200)
        Me.cmCopy03.Name = "cmCopy03"
        Me.cmCopy03.Size = New System.Drawing.Size(145, 26)
        Me.cmCopy03.TabIndex = 28
        Me.cmCopy03.Text = "Copy Note 3 settings"
        Me.cmCopy03.UseVisualStyleBackColor = False
        '
        'cmCopy04
        '
        Me.cmCopy04.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmCopy04.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmCopy04.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmCopy04.ForeColor = System.Drawing.Color.Black
        Me.cmCopy04.Location = New System.Drawing.Point(536, 230)
        Me.cmCopy04.Name = "cmCopy04"
        Me.cmCopy04.Size = New System.Drawing.Size(145, 26)
        Me.cmCopy04.TabIndex = 29
        Me.cmCopy04.Text = "Copy Note 4 settings"
        Me.cmCopy04.UseVisualStyleBackColor = False
        '
        'cmCopyAll
        '
        Me.cmCopyAll.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmCopyAll.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmCopyAll.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmCopyAll.ForeColor = System.Drawing.Color.Black
        Me.cmCopyAll.Location = New System.Drawing.Point(536, 275)
        Me.cmCopyAll.Name = "cmCopyAll"
        Me.cmCopyAll.Size = New System.Drawing.Size(145, 26)
        Me.cmCopyAll.TabIndex = 30
        Me.cmCopyAll.Text = "Set ALL notes to this Style"
        Me.cmCopyAll.UseVisualStyleBackColor = False
        '
        'cmCopySize
        '
        Me.cmCopySize.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmCopySize.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmCopySize.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmCopySize.ForeColor = System.Drawing.Color.Black
        Me.cmCopySize.Location = New System.Drawing.Point(536, 305)
        Me.cmCopySize.Name = "cmCopySize"
        Me.cmCopySize.Size = New System.Drawing.Size(145, 26)
        Me.cmCopySize.TabIndex = 31
        Me.cmCopySize.Text = "Set ALL notes to this Size"
        Me.cmCopySize.UseVisualStyleBackColor = False
        '
        'cmOVLNoImage
        '
        Me.cmOVLNoImage.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmOVLNoImage.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmOVLNoImage.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmOVLNoImage.ForeColor = System.Drawing.Color.Black
        Me.cmOVLNoImage.Location = New System.Drawing.Point(5, 19)
        Me.cmOVLNoImage.Name = "cmOVLNoImage"
        Me.cmOVLNoImage.Size = New System.Drawing.Size(191, 26)
        Me.cmOVLNoImage.TabIndex = 21
        Me.cmOVLNoImage.Text = "No Image"
        Me.cmOVLNoImage.UseVisualStyleBackColor = False
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.cmOVLNoImage)
        Me.GroupBox1.Controls.Add(Me.cmOverlay)
        Me.GroupBox1.Controls.Add(Me.cboOVLScaling)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Location = New System.Drawing.Point(320, 243)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(202, 119)
        Me.GroupBox1.TabIndex = 143
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Overlay"
        '
        'cboBordWidth
        '
        Me.cboBordWidth.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.cboBordWidth.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboBordWidth.ForeColor = System.Drawing.Color.White
        Me.cboBordWidth.FormattingEnabled = True
        Me.cboBordWidth.Location = New System.Drawing.Point(193, 182)
        Me.cboBordWidth.Name = "cboBordWidth"
        Me.cboBordWidth.Size = New System.Drawing.Size(96, 21)
        Me.cboBordWidth.TabIndex = 152
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.Label4.Location = New System.Drawing.Point(4, 185)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(90, 13)
        Me.Label4.TabIndex = 153
        Me.Label4.Text = "Border Thickness"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.ForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.Label5.Location = New System.Drawing.Point(6, 190)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(90, 13)
        Me.Label5.TabIndex = 155
        Me.Label5.Text = "Border Thickness"
        '
        'cboBordPanWidth
        '
        Me.cboBordPanWidth.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.cboBordPanWidth.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboBordPanWidth.ForeColor = System.Drawing.Color.White
        Me.cboBordPanWidth.FormattingEnabled = True
        Me.cboBordPanWidth.Location = New System.Drawing.Point(107, 185)
        Me.cboBordPanWidth.Name = "cboBordPanWidth"
        Me.cboBordPanWidth.Size = New System.Drawing.Size(89, 21)
        Me.cboBordPanWidth.TabIndex = 154
        '
        'frmLabelSetup
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(694, 434)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.cmCopySize)
        Me.Controls.Add(Me.cmCopyAll)
        Me.Controls.Add(Me.cmCopy04)
        Me.Controls.Add(Me.cmCopy03)
        Me.Controls.Add(Me.cmCopy02)
        Me.Controls.Add(Me.cmCopy01)
        Me.Controls.Add(Me.gbBack)
        Me.Controls.Add(Me.cmCancel)
        Me.Controls.Add(Me.cmOK)
        Me.Controls.Add(Me.pbNote)
        Me.Controls.Add(Me.gbLabel)
        Me.DoubleBuffered = True
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmLabelSetup"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "MakoCELO - Presentation Setup"
        Me.gbLabel.ResumeLayout(False)
        Me.gbLabel.PerformLayout()
        CType(Me.pbNote, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gbBack.ResumeLayout(False)
        Me.gbBack.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents gbLabel As GroupBox
    Friend WithEvents cmShadowColor As Button
    Friend WithEvents lbR5 As Label
    Friend WithEvents cbo3D As ComboBox
    Friend WithEvents cboA2 As ComboBox
    Friend WithEvents lbR4 As Label
    Friend WithEvents cmBR As Button
    Friend WithEvents cmBD As Button
    Friend WithEvents cmFR As Button
    Friend WithEvents cmFD As Button
    Friend WithEvents cmB2 As Button
    Friend WithEvents cmB1 As Button
    Friend WithEvents lbR2 As Label
    Friend WithEvents cmF2 As Button
    Friend WithEvents cmRankFont As Button
    Friend WithEvents cmF1 As Button
    Friend WithEvents lbR1 As Label
    Friend WithEvents lbR3 As Label
    Friend WithEvents cboA1 As ComboBox
    Friend WithEvents pbNote As PictureBox
    Friend WithEvents cmCancel As Button
    Friend WithEvents cmOK As Button
    Friend WithEvents ColorDialog1 As ColorDialog
    Friend WithEvents lbSize As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents tbWidth As TextBox
    Friend WithEvents tbHeight As TextBox
    Friend WithEvents gbBack As GroupBox
    Friend WithEvents cboScaling As ComboBox
    Friend WithEvents Label7 As Label
    Friend WithEvents cmFormColor As Button
    Friend WithEvents cmFormImage As Button
    Friend WithEvents cmNoImage As Button
    Friend WithEvents cmCopy01 As Button
    Friend WithEvents cmCopy02 As Button
    Friend WithEvents cmCopy03 As Button
    Friend WithEvents cmCopy04 As Button
    Friend WithEvents cmCopyAll As Button
    Friend WithEvents cmCopySize As Button
    Friend WithEvents cboDepth As ComboBox
    Friend WithEvents lbDepth As Label
    Friend WithEvents cboOVLScaling As ComboBox
    Friend WithEvents Label2 As Label
    Friend WithEvents cmOverlay As Button
    Friend WithEvents cmOVLNoImage As Button
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents ToolTip1 As ToolTip
    Friend WithEvents cboBordPan As ComboBox
    Friend WithEvents Label3 As Label
    Friend WithEvents cmBordPanColor As Button
    Friend WithEvents cmBordColor As Button
    Friend WithEvents cboBord As ComboBox
    Friend WithEvents Label6 As Label
    Friend WithEvents chkCardBack As CheckBox
    Friend WithEvents lbB2 As Label
    Friend WithEvents lbF2 As Label
    Friend WithEvents lbB1 As Label
    Friend WithEvents lbF1 As Label
    Friend WithEvents lbShadowColor As Label
    Friend WithEvents lbBordColor As Label
    Friend WithEvents lbBordPanColor As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents cboBordWidth As ComboBox
    Friend WithEvents Label5 As Label
    Friend WithEvents cboBordPanWidth As ComboBox
End Class
