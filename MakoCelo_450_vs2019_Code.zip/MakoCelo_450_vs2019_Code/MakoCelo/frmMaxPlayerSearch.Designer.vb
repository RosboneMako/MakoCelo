﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmMaxPlayerSearch
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMaxPlayerSearch))
        Me.Web1 = New System.Windows.Forms.WebBrowser()
        Me.cm1v1Sov = New System.Windows.Forms.Button()
        Me.tb1v1Sov = New System.Windows.Forms.TextBox()
        Me.cm1v1Usf = New System.Windows.Forms.Button()
        Me.tb1v1Usf = New System.Windows.Forms.TextBox()
        Me.cm1v1Brit = New System.Windows.Forms.Button()
        Me.cm1v1Ost = New System.Windows.Forms.Button()
        Me.cm1v1Okw = New System.Windows.Forms.Button()
        Me.tb1v1Brit = New System.Windows.Forms.TextBox()
        Me.tb1v1Ost = New System.Windows.Forms.TextBox()
        Me.tb1v1Okw = New System.Windows.Forms.TextBox()
        Me.tb2v2Okw = New System.Windows.Forms.TextBox()
        Me.tb2v2Ost = New System.Windows.Forms.TextBox()
        Me.tb2v2Brit = New System.Windows.Forms.TextBox()
        Me.tb2v2Usf = New System.Windows.Forms.TextBox()
        Me.tb2v2Sov = New System.Windows.Forms.TextBox()
        Me.tb3v3Okw = New System.Windows.Forms.TextBox()
        Me.tb3v3Ost = New System.Windows.Forms.TextBox()
        Me.tb3v3Brit = New System.Windows.Forms.TextBox()
        Me.tb3v3Usf = New System.Windows.Forms.TextBox()
        Me.tb3v3Sov = New System.Windows.Forms.TextBox()
        Me.tb4v4Okw = New System.Windows.Forms.TextBox()
        Me.tb4v4Ost = New System.Windows.Forms.TextBox()
        Me.tb4v4Brit = New System.Windows.Forms.TextBox()
        Me.tb4v4Usf = New System.Windows.Forms.TextBox()
        Me.tb4v4Sov = New System.Windows.Forms.TextBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.rb4v4 = New System.Windows.Forms.RadioButton()
        Me.rb3v3 = New System.Windows.Forms.RadioButton()
        Me.rb2v2 = New System.Windows.Forms.RadioButton()
        Me.rb1v1 = New System.Windows.Forms.RadioButton()
        Me.cmATallies = New System.Windows.Forms.Button()
        Me.tb2ATAllies = New System.Windows.Forms.TextBox()
        Me.tb3ATAllies = New System.Windows.Forms.TextBox()
        Me.tb4ATAllies = New System.Windows.Forms.TextBox()
        Me.cmATAxis = New System.Windows.Forms.Button()
        Me.tb4ATAxis = New System.Windows.Forms.TextBox()
        Me.tb3ATAxis = New System.Windows.Forms.TextBox()
        Me.tb2ATAxis = New System.Windows.Forms.TextBox()
        Me.cmOK = New System.Windows.Forms.Button()
        Me.cmGetAll = New System.Windows.Forms.Button()
        Me.cmCancel = New System.Windows.Forms.Button()
        Me.cmStopAll = New System.Windows.Forms.Button()
        Me.lbStatus = New System.Windows.Forms.Label()
        Me.cmGetAllActual = New System.Windows.Forms.Button()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.tbHelp = New System.Windows.Forms.TextBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Web1
        '
        Me.Web1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Web1.Location = New System.Drawing.Point(12, 154)
        Me.Web1.MinimumSize = New System.Drawing.Size(20, 20)
        Me.Web1.Name = "Web1"
        Me.Web1.Size = New System.Drawing.Size(1316, 482)
        Me.Web1.TabIndex = 42
        '
        'cm1v1Sov
        '
        Me.cm1v1Sov.Location = New System.Drawing.Point(119, 8)
        Me.cm1v1Sov.Name = "cm1v1Sov"
        Me.cm1v1Sov.Size = New System.Drawing.Size(50, 27)
        Me.cm1v1Sov.TabIndex = 1
        Me.cm1v1Sov.Text = "Sov"
        Me.ToolTip1.SetToolTip(Me.cm1v1Sov, "Open the relic website to get the max number of players.")
        Me.cm1v1Sov.UseVisualStyleBackColor = True
        '
        'tb1v1Sov
        '
        Me.tb1v1Sov.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.tb1v1Sov.ForeColor = System.Drawing.Color.Black
        Me.tb1v1Sov.Location = New System.Drawing.Point(119, 41)
        Me.tb1v1Sov.Name = "tb1v1Sov"
        Me.tb1v1Sov.Size = New System.Drawing.Size(50, 20)
        Me.tb1v1Sov.TabIndex = 17
        '
        'cm1v1Usf
        '
        Me.cm1v1Usf.Location = New System.Drawing.Point(231, 8)
        Me.cm1v1Usf.Name = "cm1v1Usf"
        Me.cm1v1Usf.Size = New System.Drawing.Size(50, 27)
        Me.cm1v1Usf.TabIndex = 3
        Me.cm1v1Usf.Text = "Usf"
        Me.ToolTip1.SetToolTip(Me.cm1v1Usf, "Open the relic website to get the max number of players.")
        Me.cm1v1Usf.UseVisualStyleBackColor = True
        '
        'tb1v1Usf
        '
        Me.tb1v1Usf.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.tb1v1Usf.ForeColor = System.Drawing.Color.Black
        Me.tb1v1Usf.Location = New System.Drawing.Point(231, 41)
        Me.tb1v1Usf.Name = "tb1v1Usf"
        Me.tb1v1Usf.Size = New System.Drawing.Size(50, 20)
        Me.tb1v1Usf.TabIndex = 19
        '
        'cm1v1Brit
        '
        Me.cm1v1Brit.Location = New System.Drawing.Point(287, 8)
        Me.cm1v1Brit.Name = "cm1v1Brit"
        Me.cm1v1Brit.Size = New System.Drawing.Size(50, 27)
        Me.cm1v1Brit.TabIndex = 4
        Me.cm1v1Brit.Text = "Brit"
        Me.ToolTip1.SetToolTip(Me.cm1v1Brit, "Open the relic website to get the max number of players.")
        Me.cm1v1Brit.UseVisualStyleBackColor = True
        '
        'cm1v1Ost
        '
        Me.cm1v1Ost.Location = New System.Drawing.Point(63, 8)
        Me.cm1v1Ost.Name = "cm1v1Ost"
        Me.cm1v1Ost.Size = New System.Drawing.Size(50, 27)
        Me.cm1v1Ost.TabIndex = 0
        Me.cm1v1Ost.Text = "Ost"
        Me.ToolTip1.SetToolTip(Me.cm1v1Ost, "Open the relic website to get the max number of players.")
        Me.cm1v1Ost.UseVisualStyleBackColor = True
        '
        'cm1v1Okw
        '
        Me.cm1v1Okw.Location = New System.Drawing.Point(175, 8)
        Me.cm1v1Okw.Name = "cm1v1Okw"
        Me.cm1v1Okw.Size = New System.Drawing.Size(50, 27)
        Me.cm1v1Okw.TabIndex = 2
        Me.cm1v1Okw.Text = "Okw"
        Me.ToolTip1.SetToolTip(Me.cm1v1Okw, "Open the relic website to get the max number of players.")
        Me.cm1v1Okw.UseVisualStyleBackColor = True
        '
        'tb1v1Brit
        '
        Me.tb1v1Brit.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.tb1v1Brit.ForeColor = System.Drawing.Color.Black
        Me.tb1v1Brit.Location = New System.Drawing.Point(287, 41)
        Me.tb1v1Brit.Name = "tb1v1Brit"
        Me.tb1v1Brit.Size = New System.Drawing.Size(50, 20)
        Me.tb1v1Brit.TabIndex = 20
        '
        'tb1v1Ost
        '
        Me.tb1v1Ost.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.tb1v1Ost.ForeColor = System.Drawing.Color.Black
        Me.tb1v1Ost.Location = New System.Drawing.Point(63, 41)
        Me.tb1v1Ost.Name = "tb1v1Ost"
        Me.tb1v1Ost.Size = New System.Drawing.Size(50, 20)
        Me.tb1v1Ost.TabIndex = 16
        '
        'tb1v1Okw
        '
        Me.tb1v1Okw.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.tb1v1Okw.ForeColor = System.Drawing.Color.Black
        Me.tb1v1Okw.Location = New System.Drawing.Point(175, 41)
        Me.tb1v1Okw.Name = "tb1v1Okw"
        Me.tb1v1Okw.Size = New System.Drawing.Size(50, 20)
        Me.tb1v1Okw.TabIndex = 18
        '
        'tb2v2Okw
        '
        Me.tb2v2Okw.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.tb2v2Okw.ForeColor = System.Drawing.Color.Black
        Me.tb2v2Okw.Location = New System.Drawing.Point(175, 67)
        Me.tb2v2Okw.Name = "tb2v2Okw"
        Me.tb2v2Okw.Size = New System.Drawing.Size(50, 20)
        Me.tb2v2Okw.TabIndex = 23
        '
        'tb2v2Ost
        '
        Me.tb2v2Ost.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.tb2v2Ost.ForeColor = System.Drawing.Color.Black
        Me.tb2v2Ost.Location = New System.Drawing.Point(63, 67)
        Me.tb2v2Ost.Name = "tb2v2Ost"
        Me.tb2v2Ost.Size = New System.Drawing.Size(50, 20)
        Me.tb2v2Ost.TabIndex = 21
        '
        'tb2v2Brit
        '
        Me.tb2v2Brit.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.tb2v2Brit.ForeColor = System.Drawing.Color.Black
        Me.tb2v2Brit.Location = New System.Drawing.Point(287, 67)
        Me.tb2v2Brit.Name = "tb2v2Brit"
        Me.tb2v2Brit.Size = New System.Drawing.Size(50, 20)
        Me.tb2v2Brit.TabIndex = 25
        '
        'tb2v2Usf
        '
        Me.tb2v2Usf.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.tb2v2Usf.ForeColor = System.Drawing.Color.Black
        Me.tb2v2Usf.Location = New System.Drawing.Point(231, 67)
        Me.tb2v2Usf.Name = "tb2v2Usf"
        Me.tb2v2Usf.Size = New System.Drawing.Size(50, 20)
        Me.tb2v2Usf.TabIndex = 24
        '
        'tb2v2Sov
        '
        Me.tb2v2Sov.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.tb2v2Sov.ForeColor = System.Drawing.Color.Black
        Me.tb2v2Sov.Location = New System.Drawing.Point(119, 67)
        Me.tb2v2Sov.Name = "tb2v2Sov"
        Me.tb2v2Sov.Size = New System.Drawing.Size(50, 20)
        Me.tb2v2Sov.TabIndex = 22
        '
        'tb3v3Okw
        '
        Me.tb3v3Okw.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.tb3v3Okw.ForeColor = System.Drawing.Color.Black
        Me.tb3v3Okw.Location = New System.Drawing.Point(175, 93)
        Me.tb3v3Okw.Name = "tb3v3Okw"
        Me.tb3v3Okw.Size = New System.Drawing.Size(50, 20)
        Me.tb3v3Okw.TabIndex = 30
        '
        'tb3v3Ost
        '
        Me.tb3v3Ost.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.tb3v3Ost.ForeColor = System.Drawing.Color.Black
        Me.tb3v3Ost.Location = New System.Drawing.Point(63, 93)
        Me.tb3v3Ost.Name = "tb3v3Ost"
        Me.tb3v3Ost.Size = New System.Drawing.Size(50, 20)
        Me.tb3v3Ost.TabIndex = 28
        '
        'tb3v3Brit
        '
        Me.tb3v3Brit.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.tb3v3Brit.ForeColor = System.Drawing.Color.Black
        Me.tb3v3Brit.Location = New System.Drawing.Point(287, 93)
        Me.tb3v3Brit.Name = "tb3v3Brit"
        Me.tb3v3Brit.Size = New System.Drawing.Size(50, 20)
        Me.tb3v3Brit.TabIndex = 32
        '
        'tb3v3Usf
        '
        Me.tb3v3Usf.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.tb3v3Usf.ForeColor = System.Drawing.Color.Black
        Me.tb3v3Usf.Location = New System.Drawing.Point(231, 93)
        Me.tb3v3Usf.Name = "tb3v3Usf"
        Me.tb3v3Usf.Size = New System.Drawing.Size(50, 20)
        Me.tb3v3Usf.TabIndex = 31
        '
        'tb3v3Sov
        '
        Me.tb3v3Sov.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.tb3v3Sov.ForeColor = System.Drawing.Color.Black
        Me.tb3v3Sov.Location = New System.Drawing.Point(119, 93)
        Me.tb3v3Sov.Name = "tb3v3Sov"
        Me.tb3v3Sov.Size = New System.Drawing.Size(50, 20)
        Me.tb3v3Sov.TabIndex = 29
        '
        'tb4v4Okw
        '
        Me.tb4v4Okw.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.tb4v4Okw.ForeColor = System.Drawing.Color.Black
        Me.tb4v4Okw.Location = New System.Drawing.Point(175, 119)
        Me.tb4v4Okw.Name = "tb4v4Okw"
        Me.tb4v4Okw.Size = New System.Drawing.Size(50, 20)
        Me.tb4v4Okw.TabIndex = 36
        '
        'tb4v4Ost
        '
        Me.tb4v4Ost.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.tb4v4Ost.ForeColor = System.Drawing.Color.Black
        Me.tb4v4Ost.Location = New System.Drawing.Point(63, 119)
        Me.tb4v4Ost.Name = "tb4v4Ost"
        Me.tb4v4Ost.Size = New System.Drawing.Size(50, 20)
        Me.tb4v4Ost.TabIndex = 35
        '
        'tb4v4Brit
        '
        Me.tb4v4Brit.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.tb4v4Brit.ForeColor = System.Drawing.Color.Black
        Me.tb4v4Brit.Location = New System.Drawing.Point(287, 119)
        Me.tb4v4Brit.Name = "tb4v4Brit"
        Me.tb4v4Brit.Size = New System.Drawing.Size(50, 20)
        Me.tb4v4Brit.TabIndex = 38
        '
        'tb4v4Usf
        '
        Me.tb4v4Usf.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.tb4v4Usf.ForeColor = System.Drawing.Color.Black
        Me.tb4v4Usf.Location = New System.Drawing.Point(231, 119)
        Me.tb4v4Usf.Name = "tb4v4Usf"
        Me.tb4v4Usf.Size = New System.Drawing.Size(50, 20)
        Me.tb4v4Usf.TabIndex = 37
        '
        'tb4v4Sov
        '
        Me.tb4v4Sov.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.tb4v4Sov.ForeColor = System.Drawing.Color.Black
        Me.tb4v4Sov.Location = New System.Drawing.Point(119, 119)
        Me.tb4v4Sov.Name = "tb4v4Sov"
        Me.tb4v4Sov.Size = New System.Drawing.Size(50, 20)
        Me.tb4v4Sov.TabIndex = 35
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.rb4v4)
        Me.Panel1.Controls.Add(Me.rb3v3)
        Me.Panel1.Controls.Add(Me.rb2v2)
        Me.Panel1.Controls.Add(Me.rb1v1)
        Me.Panel1.Location = New System.Drawing.Point(12, 41)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(48, 98)
        Me.Panel1.TabIndex = 43
        Me.Panel1.TabStop = True
        '
        'rb4v4
        '
        Me.rb4v4.AutoSize = True
        Me.rb4v4.ForeColor = System.Drawing.Color.Black
        Me.rb4v4.Location = New System.Drawing.Point(3, 72)
        Me.rb4v4.Name = "rb4v4"
        Me.rb4v4.Size = New System.Drawing.Size(43, 17)
        Me.rb4v4.TabIndex = 15
        Me.rb4v4.TabStop = True
        Me.rb4v4.Text = "&4v4"
        Me.rb4v4.UseVisualStyleBackColor = True
        '
        'rb3v3
        '
        Me.rb3v3.AutoSize = True
        Me.rb3v3.ForeColor = System.Drawing.Color.Black
        Me.rb3v3.Location = New System.Drawing.Point(3, 49)
        Me.rb3v3.Name = "rb3v3"
        Me.rb3v3.Size = New System.Drawing.Size(43, 17)
        Me.rb3v3.TabIndex = 14
        Me.rb3v3.TabStop = True
        Me.rb3v3.Text = "&3v3"
        Me.rb3v3.UseVisualStyleBackColor = True
        '
        'rb2v2
        '
        Me.rb2v2.AutoSize = True
        Me.rb2v2.ForeColor = System.Drawing.Color.Black
        Me.rb2v2.Location = New System.Drawing.Point(3, 26)
        Me.rb2v2.Name = "rb2v2"
        Me.rb2v2.Size = New System.Drawing.Size(43, 17)
        Me.rb2v2.TabIndex = 13
        Me.rb2v2.TabStop = True
        Me.rb2v2.Text = "&2v2"
        Me.rb2v2.UseVisualStyleBackColor = True
        '
        'rb1v1
        '
        Me.rb1v1.AutoSize = True
        Me.rb1v1.Checked = True
        Me.rb1v1.ForeColor = System.Drawing.Color.Black
        Me.rb1v1.Location = New System.Drawing.Point(3, 3)
        Me.rb1v1.Name = "rb1v1"
        Me.rb1v1.Size = New System.Drawing.Size(43, 17)
        Me.rb1v1.TabIndex = 12
        Me.rb1v1.TabStop = True
        Me.rb1v1.Text = "&1v1"
        Me.rb1v1.UseVisualStyleBackColor = True
        '
        'cmATallies
        '
        Me.cmATallies.Location = New System.Drawing.Point(343, 8)
        Me.cmATallies.Name = "cmATallies"
        Me.cmATallies.Size = New System.Drawing.Size(66, 27)
        Me.cmATallies.TabIndex = 5
        Me.cmATallies.Text = "AT Allies"
        Me.ToolTip1.SetToolTip(Me.cmATallies, "Open the relic website to get the max number of players.")
        Me.cmATallies.UseVisualStyleBackColor = True
        '
        'tb2ATAllies
        '
        Me.tb2ATAllies.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.tb2ATAllies.ForeColor = System.Drawing.Color.Black
        Me.tb2ATAllies.Location = New System.Drawing.Point(343, 67)
        Me.tb2ATAllies.Name = "tb2ATAllies"
        Me.tb2ATAllies.Size = New System.Drawing.Size(66, 20)
        Me.tb2ATAllies.TabIndex = 26
        '
        'tb3ATAllies
        '
        Me.tb3ATAllies.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.tb3ATAllies.ForeColor = System.Drawing.Color.Black
        Me.tb3ATAllies.Location = New System.Drawing.Point(343, 93)
        Me.tb3ATAllies.Name = "tb3ATAllies"
        Me.tb3ATAllies.Size = New System.Drawing.Size(66, 20)
        Me.tb3ATAllies.TabIndex = 33
        '
        'tb4ATAllies
        '
        Me.tb4ATAllies.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.tb4ATAllies.ForeColor = System.Drawing.Color.Black
        Me.tb4ATAllies.Location = New System.Drawing.Point(343, 119)
        Me.tb4ATAllies.Name = "tb4ATAllies"
        Me.tb4ATAllies.Size = New System.Drawing.Size(66, 20)
        Me.tb4ATAllies.TabIndex = 39
        '
        'cmATAxis
        '
        Me.cmATAxis.Location = New System.Drawing.Point(415, 8)
        Me.cmATAxis.Name = "cmATAxis"
        Me.cmATAxis.Size = New System.Drawing.Size(66, 27)
        Me.cmATAxis.TabIndex = 6
        Me.cmATAxis.Text = "AT Axis"
        Me.ToolTip1.SetToolTip(Me.cmATAxis, "Open the relic website to get the max number of players.")
        Me.cmATAxis.UseVisualStyleBackColor = True
        '
        'tb4ATAxis
        '
        Me.tb4ATAxis.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.tb4ATAxis.ForeColor = System.Drawing.Color.Black
        Me.tb4ATAxis.Location = New System.Drawing.Point(415, 119)
        Me.tb4ATAxis.Name = "tb4ATAxis"
        Me.tb4ATAxis.Size = New System.Drawing.Size(66, 20)
        Me.tb4ATAxis.TabIndex = 40
        '
        'tb3ATAxis
        '
        Me.tb3ATAxis.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.tb3ATAxis.ForeColor = System.Drawing.Color.Black
        Me.tb3ATAxis.Location = New System.Drawing.Point(415, 93)
        Me.tb3ATAxis.Name = "tb3ATAxis"
        Me.tb3ATAxis.Size = New System.Drawing.Size(66, 20)
        Me.tb3ATAxis.TabIndex = 34
        '
        'tb2ATAxis
        '
        Me.tb2ATAxis.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.tb2ATAxis.ForeColor = System.Drawing.Color.Black
        Me.tb2ATAxis.Location = New System.Drawing.Point(415, 67)
        Me.tb2ATAxis.Name = "tb2ATAxis"
        Me.tb2ATAxis.Size = New System.Drawing.Size(66, 20)
        Me.tb2ATAxis.TabIndex = 27
        '
        'cmOK
        '
        Me.cmOK.Location = New System.Drawing.Point(675, 8)
        Me.cmOK.Name = "cmOK"
        Me.cmOK.Size = New System.Drawing.Size(132, 36)
        Me.cmOK.TabIndex = 10
        Me.cmOK.Text = "Save and Exit"
        Me.cmOK.UseVisualStyleBackColor = True
        '
        'cmGetAll
        '
        Me.cmGetAll.Location = New System.Drawing.Point(487, 37)
        Me.cmGetAll.Name = "cmGetAll"
        Me.cmGetAll.Size = New System.Drawing.Size(167, 27)
        Me.cmGetAll.TabIndex = 8
        Me.cmGetAll.Text = "Get &ALL Approximates"
        Me.ToolTip1.SetToolTip(Me.cmGetAll, "Automatically get player counts by navigation page count (40 per page).")
        Me.cmGetAll.UseVisualStyleBackColor = True
        '
        'cmCancel
        '
        Me.cmCancel.Location = New System.Drawing.Point(675, 49)
        Me.cmCancel.Name = "cmCancel"
        Me.cmCancel.Size = New System.Drawing.Size(132, 38)
        Me.cmCancel.TabIndex = 11
        Me.cmCancel.Text = "&Cancel"
        Me.cmCancel.UseVisualStyleBackColor = True
        '
        'cmStopAll
        '
        Me.cmStopAll.Location = New System.Drawing.Point(487, 98)
        Me.cmStopAll.Name = "cmStopAll"
        Me.cmStopAll.Size = New System.Drawing.Size(167, 42)
        Me.cmStopAll.TabIndex = 9
        Me.cmStopAll.Text = "&Stop Searching"
        Me.cmStopAll.UseVisualStyleBackColor = True
        '
        'lbStatus
        '
        Me.lbStatus.BackColor = System.Drawing.Color.Silver
        Me.lbStatus.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbStatus.Location = New System.Drawing.Point(487, 67)
        Me.lbStatus.Name = "lbStatus"
        Me.lbStatus.Size = New System.Drawing.Size(167, 25)
        Me.lbStatus.TabIndex = 45
        Me.lbStatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cmGetAllActual
        '
        Me.cmGetAllActual.Location = New System.Drawing.Point(487, 8)
        Me.cmGetAllActual.Name = "cmGetAllActual"
        Me.cmGetAllActual.Size = New System.Drawing.Size(167, 27)
        Me.cmGetAllActual.TabIndex = 7
        Me.cmGetAllActual.Text = "Get &ALL Actual"
        Me.ToolTip1.SetToolTip(Me.cmGetAllActual, "Automatically get actual player counts from each web page.")
        Me.cmGetAllActual.UseVisualStyleBackColor = True
        '
        'tbHelp
        '
        Me.tbHelp.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.tbHelp.ForeColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.tbHelp.Location = New System.Drawing.Point(813, 8)
        Me.tbHelp.Multiline = True
        Me.tbHelp.Name = "tbHelp"
        Me.tbHelp.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.tbHelp.Size = New System.Drawing.Size(515, 131)
        Me.tbHelp.TabIndex = 41
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(343, 41)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(62, 25)
        Me.Button2.TabIndex = 47
        Me.Button2.Text = "Button2"
        Me.Button2.UseVisualStyleBackColor = True
        Me.Button2.Visible = False
        '
        'frmMaxPlayerSearch
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1340, 648)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.tbHelp)
        Me.Controls.Add(Me.cmGetAllActual)
        Me.Controls.Add(Me.lbStatus)
        Me.Controls.Add(Me.cmStopAll)
        Me.Controls.Add(Me.cmCancel)
        Me.Controls.Add(Me.cmGetAll)
        Me.Controls.Add(Me.cmOK)
        Me.Controls.Add(Me.tb4ATAxis)
        Me.Controls.Add(Me.tb3ATAxis)
        Me.Controls.Add(Me.tb2ATAxis)
        Me.Controls.Add(Me.cmATAxis)
        Me.Controls.Add(Me.tb4ATAllies)
        Me.Controls.Add(Me.tb3ATAllies)
        Me.Controls.Add(Me.tb2ATAllies)
        Me.Controls.Add(Me.cmATallies)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.tb4v4Okw)
        Me.Controls.Add(Me.tb4v4Ost)
        Me.Controls.Add(Me.tb4v4Brit)
        Me.Controls.Add(Me.tb4v4Usf)
        Me.Controls.Add(Me.tb4v4Sov)
        Me.Controls.Add(Me.tb3v3Okw)
        Me.Controls.Add(Me.tb3v3Ost)
        Me.Controls.Add(Me.tb3v3Brit)
        Me.Controls.Add(Me.tb3v3Usf)
        Me.Controls.Add(Me.tb3v3Sov)
        Me.Controls.Add(Me.tb2v2Okw)
        Me.Controls.Add(Me.tb2v2Ost)
        Me.Controls.Add(Me.tb2v2Brit)
        Me.Controls.Add(Me.tb2v2Usf)
        Me.Controls.Add(Me.tb2v2Sov)
        Me.Controls.Add(Me.tb1v1Okw)
        Me.Controls.Add(Me.tb1v1Ost)
        Me.Controls.Add(Me.tb1v1Brit)
        Me.Controls.Add(Me.cm1v1Okw)
        Me.Controls.Add(Me.cm1v1Ost)
        Me.Controls.Add(Me.cm1v1Brit)
        Me.Controls.Add(Me.tb1v1Usf)
        Me.Controls.Add(Me.cm1v1Usf)
        Me.Controls.Add(Me.tb1v1Sov)
        Me.Controls.Add(Me.cm1v1Sov)
        Me.Controls.Add(Me.Web1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmMaxPlayerSearch"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "MakoCELO - ELO Setup Dialog"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Web1 As WebBrowser
    Friend WithEvents cm1v1Sov As Button
    Friend WithEvents tb1v1Sov As TextBox
    Friend WithEvents cm1v1Usf As Button
    Friend WithEvents tb1v1Usf As TextBox
    Friend WithEvents cm1v1Brit As Button
    Friend WithEvents cm1v1Ost As Button
    Friend WithEvents cm1v1Okw As Button
    Friend WithEvents tb1v1Brit As TextBox
    Friend WithEvents tb1v1Ost As TextBox
    Friend WithEvents tb1v1Okw As TextBox
    Friend WithEvents tb2v2Okw As TextBox
    Friend WithEvents tb2v2Ost As TextBox
    Friend WithEvents tb2v2Brit As TextBox
    Friend WithEvents tb2v2Usf As TextBox
    Friend WithEvents tb2v2Sov As TextBox
    Friend WithEvents tb3v3Okw As TextBox
    Friend WithEvents tb3v3Ost As TextBox
    Friend WithEvents tb3v3Brit As TextBox
    Friend WithEvents tb3v3Usf As TextBox
    Friend WithEvents tb3v3Sov As TextBox
    Friend WithEvents tb4v4Okw As TextBox
    Friend WithEvents tb4v4Ost As TextBox
    Friend WithEvents tb4v4Brit As TextBox
    Friend WithEvents tb4v4Usf As TextBox
    Friend WithEvents tb4v4Sov As TextBox
    Friend WithEvents Panel1 As Panel
    Friend WithEvents rb4v4 As RadioButton
    Friend WithEvents rb3v3 As RadioButton
    Friend WithEvents rb2v2 As RadioButton
    Friend WithEvents rb1v1 As RadioButton
    Friend WithEvents cmATallies As Button
    Friend WithEvents tb2ATAllies As TextBox
    Friend WithEvents tb3ATAllies As TextBox
    Friend WithEvents tb4ATAllies As TextBox
    Friend WithEvents cmATAxis As Button
    Friend WithEvents tb4ATAxis As TextBox
    Friend WithEvents tb3ATAxis As TextBox
    Friend WithEvents tb2ATAxis As TextBox
    Friend WithEvents cmOK As Button
    Friend WithEvents cmGetAll As Button
    Friend WithEvents cmCancel As Button
    Friend WithEvents cmStopAll As Button
    Friend WithEvents lbStatus As Label
    Friend WithEvents cmGetAllActual As Button
    Friend WithEvents ToolTip1 As ToolTip
    Friend WithEvents tbHelp As TextBox
    Friend WithEvents Button2 As Button
End Class
