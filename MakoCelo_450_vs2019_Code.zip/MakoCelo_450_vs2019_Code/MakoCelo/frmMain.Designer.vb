﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMain))
        Me.cmCheckLog = New System.Windows.Forms.Button()
        Me.lbStatus = New System.Windows.Forms.Label()
        Me.pbFact01 = New System.Windows.Forms.PictureBox()
        Me.pbFact02 = New System.Windows.Forms.PictureBox()
        Me.pbFact03 = New System.Windows.Forms.PictureBox()
        Me.pbFact04 = New System.Windows.Forms.PictureBox()
        Me.pbFact05 = New System.Windows.Forms.PictureBox()
        Me.lbSteam01 = New System.Windows.Forms.Label()
        Me.lbSteam02 = New System.Windows.Forms.Label()
        Me.lbSteam03 = New System.Windows.Forms.Label()
        Me.lbSteam04 = New System.Windows.Forms.Label()
        Me.lbSteam05 = New System.Windows.Forms.Label()
        Me.lbSteam06 = New System.Windows.Forms.Label()
        Me.lbSteam07 = New System.Windows.Forms.Label()
        Me.lbSteam08 = New System.Windows.Forms.Label()
        Me.ColorDialog1 = New System.Windows.Forms.ColorDialog()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.cmFindLog = New System.Windows.Forms.Button()
        Me.cmScanLog = New System.Windows.Forms.Button()
        Me.cmCopy = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.FontDialog1 = New System.Windows.Forms.FontDialog()
        Me.cmAbout = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.cboLayoutY = New System.Windows.Forms.ComboBox()
        Me.gbRank = New System.Windows.Forms.GroupBox()
        Me.cmELO = New System.Windows.Forms.Button()
        Me.cmSetupSave = New System.Windows.Forms.Button()
        Me.cmSetupLoad = New System.Windows.Forms.Button()
        Me.cmNote_PlayAll = New System.Windows.Forms.Button()
        Me.cmNote04_Play = New System.Windows.Forms.Button()
        Me.cmNote03_Play = New System.Windows.Forms.Button()
        Me.cmNote02_Play = New System.Windows.Forms.Button()
        Me.cmNote01_Play = New System.Windows.Forms.Button()
        Me.cmNote4 = New System.Windows.Forms.Button()
        Me.cmNote04Setup = New System.Windows.Forms.Button()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.cmNote3 = New System.Windows.Forms.Button()
        Me.cmNote2 = New System.Windows.Forms.Button()
        Me.cmNote1 = New System.Windows.Forms.Button()
        Me.cmNote03Setup = New System.Windows.Forms.Button()
        Me.cmNote02Setup = New System.Windows.Forms.Button()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.cmNote01Setup = New System.Windows.Forms.Button()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.cmNameSetup = New System.Windows.Forms.Button()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.cmRankSetup = New System.Windows.Forms.Button()
        Me.cmSave = New System.Windows.Forms.Button()
        Me.gbLayout = New System.Windows.Forms.GroupBox()
        Me.cmStatsModeHelp = New System.Windows.Forms.Button()
        Me.cmDefaults = New System.Windows.Forms.Button()
        Me.tbYSize = New System.Windows.Forms.TextBox()
        Me.tbXsize = New System.Windows.Forms.TextBox()
        Me.tbYoff = New System.Windows.Forms.TextBox()
        Me.tbXoff = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.cboNoteSpace = New System.Windows.Forms.ComboBox()
        Me.chkGUIMode = New System.Windows.Forms.CheckBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.cmSizeRefresh = New System.Windows.Forms.Button()
        Me.cboLayoutX = New System.Windows.Forms.ComboBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.pbStats = New System.Windows.Forms.PictureBox()
        Me.cmTestData = New System.Windows.Forms.Button()
        Me.cmLastMatch = New System.Windows.Forms.Button()
        Me.gbFX = New System.Windows.Forms.GroupBox()
        Me.cmRID = New System.Windows.Forms.Button()
        Me.chkFX = New System.Windows.Forms.CheckBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.cmFXModeHelp = New System.Windows.Forms.Button()
        Me.cboFXVar1 = New System.Windows.Forms.ComboBox()
        Me.lbFXVar1 = New System.Windows.Forms.Label()
        Me.cboFxVar3 = New System.Windows.Forms.ComboBox()
        Me.lbFXVar3 = New System.Windows.Forms.Label()
        Me.cboFxVar4 = New System.Windows.Forms.ComboBox()
        Me.cmFX3DC = New System.Windows.Forms.Button()
        Me.cboFXVar2 = New System.Windows.Forms.ComboBox()
        Me.lbFXVar2 = New System.Windows.Forms.Label()
        Me.lbFXVar4 = New System.Windows.Forms.Label()
        Me.chkMismatch = New System.Windows.Forms.CheckBox()
        Me.lbError1 = New System.Windows.Forms.Label()
        Me.lbError2 = New System.Windows.Forms.Label()
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.chkTips = New System.Windows.Forms.CheckBox()
        Me.pbNote1 = New System.Windows.Forms.PictureBox()
        Me.timNote1 = New System.Windows.Forms.Timer(Me.components)
        Me.gbSound = New System.Windows.Forms.GroupBox()
        Me.cmAudioStop = New System.Windows.Forms.Button()
        Me.lbVolume = New System.Windows.Forms.Label()
        Me.scrVolume = New System.Windows.Forms.HScrollBar()
        Me.cmSound15 = New System.Windows.Forms.Button()
        Me.cmSound14 = New System.Windows.Forms.Button()
        Me.cmSound13 = New System.Windows.Forms.Button()
        Me.cmSound12 = New System.Windows.Forms.Button()
        Me.cmSound11 = New System.Windows.Forms.Button()
        Me.lbSoundCurrent = New System.Windows.Forms.Label()
        Me.cmSound10 = New System.Windows.Forms.Button()
        Me.cmSound09 = New System.Windows.Forms.Button()
        Me.cmSound08 = New System.Windows.Forms.Button()
        Me.cmSound07 = New System.Windows.Forms.Button()
        Me.cmSound06 = New System.Windows.Forms.Button()
        Me.cmSound05 = New System.Windows.Forms.Button()
        Me.cmSound04 = New System.Windows.Forms.Button()
        Me.cmSound03 = New System.Windows.Forms.Button()
        Me.cmSound02 = New System.Windows.Forms.Button()
        Me.cmSound01 = New System.Windows.Forms.Button()
        Me.pbNote3 = New System.Windows.Forms.PictureBox()
        Me.pbNote4 = New System.Windows.Forms.PictureBox()
        Me.pbNote2 = New System.Windows.Forms.PictureBox()
        Me.chkPosition = New System.Windows.Forms.CheckBox()
        Me.tsmPlayer = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.tsmPlayer_Relic = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmPlayer_OrgAT = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmPlayer_OrgFaction = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmPlayer_OrgPlayercard = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmPlayer_Google = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmPlayer_Steam = New System.Windows.Forms.ToolStripMenuItem()
        Me.chkPopUp = New System.Windows.Forms.CheckBox()
        Me.tsmAudio = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.tsmSetVolTo100 = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmSetVolTo90 = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmSetVolTo80 = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmSetVolTo70 = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmSetVolTo60 = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmSetVolTo50 = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmSetVolTo40 = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmSetVolTo30 = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmSetVolTo20 = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmSetVolTo10 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripSeparator()
        Me.tsmSelectFile = New System.Windows.Forms.ToolStripMenuItem()
        Me.chkSmoothAni = New System.Windows.Forms.CheckBox()
        Me.chkFoundSound = New System.Windows.Forms.CheckBox()
        Me.lbTime = New System.Windows.Forms.Label()
        Me.cboDelay = New System.Windows.Forms.ComboBox()
        Me.chkHideMissing = New System.Windows.Forms.CheckBox()
        Me.chkShowELO = New System.Windows.Forms.CheckBox()
        Me.timELOCycle = New System.Windows.Forms.Timer(Me.components)
        Me.scrStats = New System.Windows.Forms.VScrollBar()
        Me.chkSpeech = New System.Windows.Forms.CheckBox()
        Me.chkGetTeams = New System.Windows.Forms.CheckBox()
        Me.lstLog = New System.Windows.Forms.ListBox()
        Me.cmErrLog = New System.Windows.Forms.Button()
        Me.chkCountry = New System.Windows.Forms.CheckBox()
        Me.SS1 = New System.Windows.Forms.StatusStrip()
        Me.SS1_Version = New System.Windows.Forms.ToolStripStatusLabel()
        Me.SS1_Sep1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.SS1_Filename = New System.Windows.Forms.ToolStripStatusLabel()
        Me.SS1_Sep2 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.SS1_Time = New System.Windows.Forms.ToolStripStatusLabel()
        Me.SS1_Sep3 = New System.Windows.Forms.ToolStripStatusLabel()
        CType(Me.pbFact01, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbFact02, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbFact03, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbFact04, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbFact05, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gbRank.SuspendLayout()
        Me.gbLayout.SuspendLayout()
        CType(Me.pbStats, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gbFX.SuspendLayout()
        CType(Me.pbNote1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gbSound.SuspendLayout()
        CType(Me.pbNote3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbNote4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbNote2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tsmPlayer.SuspendLayout()
        Me.tsmAudio.SuspendLayout()
        Me.SS1.SuspendLayout()
        Me.SuspendLayout()
        '
        'cmCheckLog
        '
        Me.cmCheckLog.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmCheckLog.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmCheckLog.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmCheckLog.ForeColor = System.Drawing.Color.Black
        Me.cmCheckLog.Location = New System.Drawing.Point(10, 35)
        Me.cmCheckLog.Name = "cmCheckLog"
        Me.cmCheckLog.Size = New System.Drawing.Size(111, 30)
        Me.cmCheckLog.TabIndex = 1
        Me.cmCheckLog.Text = "Check Log File"
        Me.cmCheckLog.UseVisualStyleBackColor = False
        '
        'lbStatus
        '
        Me.lbStatus.BackColor = System.Drawing.Color.Silver
        Me.lbStatus.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lbStatus.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbStatus.ForeColor = System.Drawing.Color.Black
        Me.lbStatus.Location = New System.Drawing.Point(880, 15)
        Me.lbStatus.Name = "lbStatus"
        Me.lbStatus.Size = New System.Drawing.Size(235, 25)
        Me.lbStatus.TabIndex = 25
        Me.lbStatus.Text = "Ready."
        Me.lbStatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'pbFact01
        '
        Me.pbFact01.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.pbFact01.Image = CType(resources.GetObject("pbFact01.Image"), System.Drawing.Image)
        Me.pbFact01.Location = New System.Drawing.Point(1378, 192)
        Me.pbFact01.Name = "pbFact01"
        Me.pbFact01.Size = New System.Drawing.Size(95, 95)
        Me.pbFact01.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.pbFact01.TabIndex = 26
        Me.pbFact01.TabStop = False
        Me.pbFact01.Visible = False
        '
        'pbFact02
        '
        Me.pbFact02.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.pbFact02.Image = CType(resources.GetObject("pbFact02.Image"), System.Drawing.Image)
        Me.pbFact02.Location = New System.Drawing.Point(1296, 192)
        Me.pbFact02.Name = "pbFact02"
        Me.pbFact02.Size = New System.Drawing.Size(95, 95)
        Me.pbFact02.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.pbFact02.TabIndex = 27
        Me.pbFact02.TabStop = False
        Me.pbFact02.Visible = False
        '
        'pbFact03
        '
        Me.pbFact03.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.pbFact03.Image = CType(resources.GetObject("pbFact03.Image"), System.Drawing.Image)
        Me.pbFact03.Location = New System.Drawing.Point(1378, 279)
        Me.pbFact03.Name = "pbFact03"
        Me.pbFact03.Size = New System.Drawing.Size(95, 95)
        Me.pbFact03.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.pbFact03.TabIndex = 28
        Me.pbFact03.TabStop = False
        Me.pbFact03.Visible = False
        '
        'pbFact04
        '
        Me.pbFact04.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.pbFact04.Image = CType(resources.GetObject("pbFact04.Image"), System.Drawing.Image)
        Me.pbFact04.Location = New System.Drawing.Point(1460, 279)
        Me.pbFact04.Name = "pbFact04"
        Me.pbFact04.Size = New System.Drawing.Size(95, 95)
        Me.pbFact04.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.pbFact04.TabIndex = 29
        Me.pbFact04.TabStop = False
        Me.pbFact04.Visible = False
        '
        'pbFact05
        '
        Me.pbFact05.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.pbFact05.Image = CType(resources.GetObject("pbFact05.Image"), System.Drawing.Image)
        Me.pbFact05.Location = New System.Drawing.Point(1296, 279)
        Me.pbFact05.Name = "pbFact05"
        Me.pbFact05.Size = New System.Drawing.Size(95, 95)
        Me.pbFact05.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.pbFact05.TabIndex = 30
        Me.pbFact05.TabStop = False
        Me.pbFact05.Visible = False
        '
        'lbSteam01
        '
        Me.lbSteam01.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lbSteam01.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbSteam01.Location = New System.Drawing.Point(1465, 200)
        Me.lbSteam01.Name = "lbSteam01"
        Me.lbSteam01.Size = New System.Drawing.Size(50, 23)
        Me.lbSteam01.TabIndex = 39
        Me.lbSteam01.Visible = False
        '
        'lbSteam02
        '
        Me.lbSteam02.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lbSteam02.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbSteam02.Location = New System.Drawing.Point(1465, 223)
        Me.lbSteam02.Name = "lbSteam02"
        Me.lbSteam02.Size = New System.Drawing.Size(50, 23)
        Me.lbSteam02.TabIndex = 40
        Me.lbSteam02.Visible = False
        '
        'lbSteam03
        '
        Me.lbSteam03.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lbSteam03.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbSteam03.Location = New System.Drawing.Point(1465, 246)
        Me.lbSteam03.Name = "lbSteam03"
        Me.lbSteam03.Size = New System.Drawing.Size(50, 23)
        Me.lbSteam03.TabIndex = 41
        Me.lbSteam03.Visible = False
        '
        'lbSteam04
        '
        Me.lbSteam04.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lbSteam04.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbSteam04.Location = New System.Drawing.Point(1465, 269)
        Me.lbSteam04.Name = "lbSteam04"
        Me.lbSteam04.Size = New System.Drawing.Size(50, 23)
        Me.lbSteam04.TabIndex = 42
        Me.lbSteam04.Visible = False
        '
        'lbSteam05
        '
        Me.lbSteam05.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lbSteam05.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbSteam05.Location = New System.Drawing.Point(1519, 200)
        Me.lbSteam05.Name = "lbSteam05"
        Me.lbSteam05.Size = New System.Drawing.Size(50, 23)
        Me.lbSteam05.TabIndex = 43
        Me.lbSteam05.Visible = False
        '
        'lbSteam06
        '
        Me.lbSteam06.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lbSteam06.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbSteam06.Location = New System.Drawing.Point(1519, 223)
        Me.lbSteam06.Name = "lbSteam06"
        Me.lbSteam06.Size = New System.Drawing.Size(50, 23)
        Me.lbSteam06.TabIndex = 44
        Me.lbSteam06.Visible = False
        '
        'lbSteam07
        '
        Me.lbSteam07.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lbSteam07.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbSteam07.Location = New System.Drawing.Point(1519, 246)
        Me.lbSteam07.Name = "lbSteam07"
        Me.lbSteam07.Size = New System.Drawing.Size(50, 23)
        Me.lbSteam07.TabIndex = 45
        Me.lbSteam07.Visible = False
        '
        'lbSteam08
        '
        Me.lbSteam08.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lbSteam08.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbSteam08.Location = New System.Drawing.Point(1519, 269)
        Me.lbSteam08.Name = "lbSteam08"
        Me.lbSteam08.Size = New System.Drawing.Size(50, 23)
        Me.lbSteam08.TabIndex = 46
        Me.lbSteam08.Visible = False
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'Timer1
        '
        Me.Timer1.Interval = 1000
        '
        'cmFindLog
        '
        Me.cmFindLog.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmFindLog.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmFindLog.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmFindLog.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmFindLog.ForeColor = System.Drawing.Color.Black
        Me.cmFindLog.Location = New System.Drawing.Point(10, 6)
        Me.cmFindLog.Name = "cmFindLog"
        Me.cmFindLog.Size = New System.Drawing.Size(111, 26)
        Me.cmFindLog.TabIndex = 0
        Me.cmFindLog.Text = "Find Log File"
        Me.cmFindLog.UseVisualStyleBackColor = False
        '
        'cmScanLog
        '
        Me.cmScanLog.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmScanLog.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmScanLog.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmScanLog.ForeColor = System.Drawing.Color.Black
        Me.cmScanLog.Location = New System.Drawing.Point(10, 115)
        Me.cmScanLog.Name = "cmScanLog"
        Me.cmScanLog.Size = New System.Drawing.Size(111, 46)
        Me.cmScanLog.TabIndex = 2
        Me.cmScanLog.Text = "Auto Scan Log"
        Me.cmScanLog.UseVisualStyleBackColor = False
        '
        'cmCopy
        '
        Me.cmCopy.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmCopy.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmCopy.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmCopy.ForeColor = System.Drawing.Color.Black
        Me.cmCopy.Location = New System.Drawing.Point(880, 120)
        Me.cmCopy.Name = "cmCopy"
        Me.cmCopy.Size = New System.Drawing.Size(105, 23)
        Me.cmCopy.TabIndex = 6
        Me.cmCopy.Text = "Copy Stats Image"
        Me.cmCopy.UseVisualStyleBackColor = False
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(880, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(235, 13)
        Me.Label2.TabIndex = 61
        Me.Label2.Text = "Scan Status"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cmAbout
        '
        Me.cmAbout.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmAbout.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmAbout.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmAbout.ForeColor = System.Drawing.Color.Black
        Me.cmAbout.Location = New System.Drawing.Point(880, 45)
        Me.cmAbout.Name = "cmAbout"
        Me.cmAbout.Size = New System.Drawing.Size(105, 23)
        Me.cmAbout.TabIndex = 3
        Me.cmAbout.Text = "About"
        Me.cmAbout.UseVisualStyleBackColor = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.Label3.Location = New System.Drawing.Point(5, 20)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(44, 13)
        Me.Label3.TabIndex = 66
        Me.Label3.Text = "XY Size"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.Label4.Location = New System.Drawing.Point(5, 95)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(49, 13)
        Me.Label4.TabIndex = 70
        Me.Label4.Text = "Y Layout"
        '
        'cboLayoutY
        '
        Me.cboLayoutY.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.cboLayoutY.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboLayoutY.ForeColor = System.Drawing.Color.White
        Me.cboLayoutY.FormattingEnabled = True
        Me.cboLayoutY.Location = New System.Drawing.Point(60, 90)
        Me.cboLayoutY.Name = "cboLayoutY"
        Me.cboLayoutY.Size = New System.Drawing.Size(126, 21)
        Me.cboLayoutY.TabIndex = 23
        '
        'gbRank
        '
        Me.gbRank.Controls.Add(Me.cmELO)
        Me.gbRank.Controls.Add(Me.cmSetupSave)
        Me.gbRank.Controls.Add(Me.cmSetupLoad)
        Me.gbRank.Controls.Add(Me.cmNote_PlayAll)
        Me.gbRank.Controls.Add(Me.cmNote04_Play)
        Me.gbRank.Controls.Add(Me.cmNote03_Play)
        Me.gbRank.Controls.Add(Me.cmNote02_Play)
        Me.gbRank.Controls.Add(Me.cmNote01_Play)
        Me.gbRank.Controls.Add(Me.cmNote4)
        Me.gbRank.Controls.Add(Me.cmNote04Setup)
        Me.gbRank.Controls.Add(Me.Label14)
        Me.gbRank.Controls.Add(Me.cmNote3)
        Me.gbRank.Controls.Add(Me.cmNote2)
        Me.gbRank.Controls.Add(Me.cmNote1)
        Me.gbRank.Controls.Add(Me.cmNote03Setup)
        Me.gbRank.Controls.Add(Me.cmNote02Setup)
        Me.gbRank.Controls.Add(Me.Label13)
        Me.gbRank.Controls.Add(Me.Label12)
        Me.gbRank.Controls.Add(Me.cmNote01Setup)
        Me.gbRank.Controls.Add(Me.Label11)
        Me.gbRank.Controls.Add(Me.cmNameSetup)
        Me.gbRank.Controls.Add(Me.Label10)
        Me.gbRank.Controls.Add(Me.Label9)
        Me.gbRank.Controls.Add(Me.cmRankSetup)
        Me.gbRank.ForeColor = System.Drawing.Color.Black
        Me.gbRank.Location = New System.Drawing.Point(130, 0)
        Me.gbRank.Name = "gbRank"
        Me.gbRank.Size = New System.Drawing.Size(198, 195)
        Me.gbRank.TabIndex = 73
        Me.gbRank.TabStop = False
        Me.gbRank.Text = "Stats and Note Setups"
        '
        'cmELO
        '
        Me.cmELO.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmELO.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmELO.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmELO.ForeColor = System.Drawing.Color.Black
        Me.cmELO.Location = New System.Drawing.Point(100, 15)
        Me.cmELO.Name = "cmELO"
        Me.cmELO.Size = New System.Drawing.Size(50, 23)
        Me.cmELO.TabIndex = 94
        Me.cmELO.Text = "ELO"
        Me.cmELO.UseVisualStyleBackColor = False
        '
        'cmSetupSave
        '
        Me.cmSetupSave.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmSetupSave.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmSetupSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmSetupSave.ForeColor = System.Drawing.Color.Black
        Me.cmSetupSave.Location = New System.Drawing.Point(100, 165)
        Me.cmSetupSave.Name = "cmSetupSave"
        Me.cmSetupSave.Size = New System.Drawing.Size(85, 23)
        Me.cmSetupSave.TabIndex = 125
        Me.cmSetupSave.Text = "Save Setup"
        Me.cmSetupSave.UseVisualStyleBackColor = False
        '
        'cmSetupLoad
        '
        Me.cmSetupLoad.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmSetupLoad.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmSetupLoad.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmSetupLoad.ForeColor = System.Drawing.Color.Black
        Me.cmSetupLoad.Location = New System.Drawing.Point(5, 165)
        Me.cmSetupLoad.Name = "cmSetupLoad"
        Me.cmSetupLoad.Size = New System.Drawing.Size(90, 23)
        Me.cmSetupLoad.TabIndex = 124
        Me.cmSetupLoad.Text = "Load Setup"
        Me.cmSetupLoad.UseVisualStyleBackColor = False
        '
        'cmNote_PlayAll
        '
        Me.cmNote_PlayAll.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmNote_PlayAll.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmNote_PlayAll.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmNote_PlayAll.ForeColor = System.Drawing.Color.Black
        Me.cmNote_PlayAll.Location = New System.Drawing.Point(155, 40)
        Me.cmNote_PlayAll.Name = "cmNote_PlayAll"
        Me.cmNote_PlayAll.Size = New System.Drawing.Size(30, 23)
        Me.cmNote_PlayAll.TabIndex = 10
        Me.cmNote_PlayAll.Text = ">"
        Me.cmNote_PlayAll.UseVisualStyleBackColor = False
        '
        'cmNote04_Play
        '
        Me.cmNote04_Play.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmNote04_Play.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmNote04_Play.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmNote04_Play.ForeColor = System.Drawing.Color.Black
        Me.cmNote04_Play.Location = New System.Drawing.Point(155, 140)
        Me.cmNote04_Play.Name = "cmNote04_Play"
        Me.cmNote04_Play.Size = New System.Drawing.Size(30, 23)
        Me.cmNote04_Play.TabIndex = 14
        Me.cmNote04_Play.Text = ">"
        Me.cmNote04_Play.UseVisualStyleBackColor = False
        '
        'cmNote03_Play
        '
        Me.cmNote03_Play.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmNote03_Play.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmNote03_Play.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmNote03_Play.ForeColor = System.Drawing.Color.Black
        Me.cmNote03_Play.Location = New System.Drawing.Point(155, 115)
        Me.cmNote03_Play.Name = "cmNote03_Play"
        Me.cmNote03_Play.Size = New System.Drawing.Size(30, 23)
        Me.cmNote03_Play.TabIndex = 13
        Me.cmNote03_Play.Text = ">"
        Me.cmNote03_Play.UseVisualStyleBackColor = False
        '
        'cmNote02_Play
        '
        Me.cmNote02_Play.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmNote02_Play.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmNote02_Play.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmNote02_Play.ForeColor = System.Drawing.Color.Black
        Me.cmNote02_Play.Location = New System.Drawing.Point(155, 90)
        Me.cmNote02_Play.Name = "cmNote02_Play"
        Me.cmNote02_Play.Size = New System.Drawing.Size(30, 23)
        Me.cmNote02_Play.TabIndex = 12
        Me.cmNote02_Play.Text = ">"
        Me.cmNote02_Play.UseVisualStyleBackColor = False
        '
        'cmNote01_Play
        '
        Me.cmNote01_Play.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmNote01_Play.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmNote01_Play.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmNote01_Play.ForeColor = System.Drawing.Color.Black
        Me.cmNote01_Play.Location = New System.Drawing.Point(155, 65)
        Me.cmNote01_Play.Name = "cmNote01_Play"
        Me.cmNote01_Play.Size = New System.Drawing.Size(30, 23)
        Me.cmNote01_Play.TabIndex = 11
        Me.cmNote01_Play.Text = ">"
        Me.cmNote01_Play.UseVisualStyleBackColor = False
        '
        'cmNote4
        '
        Me.cmNote4.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmNote4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmNote4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmNote4.ForeColor = System.Drawing.Color.Black
        Me.cmNote4.Location = New System.Drawing.Point(100, 140)
        Me.cmNote4.Name = "cmNote4"
        Me.cmNote4.Size = New System.Drawing.Size(50, 23)
        Me.cmNote4.TabIndex = 9
        Me.cmNote4.Text = "Notes"
        Me.cmNote4.UseVisualStyleBackColor = False
        '
        'cmNote04Setup
        '
        Me.cmNote04Setup.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmNote04Setup.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmNote04Setup.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmNote04Setup.ForeColor = System.Drawing.Color.Black
        Me.cmNote04Setup.Location = New System.Drawing.Point(45, 140)
        Me.cmNote04Setup.Name = "cmNote04Setup"
        Me.cmNote04Setup.Size = New System.Drawing.Size(50, 23)
        Me.cmNote04Setup.TabIndex = 8
        Me.cmNote04Setup.Text = "Setup"
        Me.cmNote04Setup.UseVisualStyleBackColor = False
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.ForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.Label14.Location = New System.Drawing.Point(5, 145)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(39, 13)
        Me.Label14.TabIndex = 123
        Me.Label14.Text = "Note 4"
        '
        'cmNote3
        '
        Me.cmNote3.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmNote3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmNote3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmNote3.ForeColor = System.Drawing.Color.Black
        Me.cmNote3.Location = New System.Drawing.Point(100, 115)
        Me.cmNote3.Name = "cmNote3"
        Me.cmNote3.Size = New System.Drawing.Size(50, 23)
        Me.cmNote3.TabIndex = 7
        Me.cmNote3.Text = "Notes"
        Me.cmNote3.UseVisualStyleBackColor = False
        '
        'cmNote2
        '
        Me.cmNote2.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmNote2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmNote2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmNote2.ForeColor = System.Drawing.Color.Black
        Me.cmNote2.Location = New System.Drawing.Point(100, 90)
        Me.cmNote2.Name = "cmNote2"
        Me.cmNote2.Size = New System.Drawing.Size(50, 23)
        Me.cmNote2.TabIndex = 5
        Me.cmNote2.Text = "Notes"
        Me.cmNote2.UseVisualStyleBackColor = False
        '
        'cmNote1
        '
        Me.cmNote1.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmNote1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmNote1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmNote1.ForeColor = System.Drawing.Color.Black
        Me.cmNote1.Location = New System.Drawing.Point(100, 65)
        Me.cmNote1.Name = "cmNote1"
        Me.cmNote1.Size = New System.Drawing.Size(50, 23)
        Me.cmNote1.TabIndex = 3
        Me.cmNote1.Text = "Notes"
        Me.cmNote1.UseVisualStyleBackColor = False
        '
        'cmNote03Setup
        '
        Me.cmNote03Setup.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmNote03Setup.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmNote03Setup.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmNote03Setup.ForeColor = System.Drawing.Color.Black
        Me.cmNote03Setup.Location = New System.Drawing.Point(45, 115)
        Me.cmNote03Setup.Name = "cmNote03Setup"
        Me.cmNote03Setup.Size = New System.Drawing.Size(50, 23)
        Me.cmNote03Setup.TabIndex = 6
        Me.cmNote03Setup.Text = "Setup"
        Me.cmNote03Setup.UseVisualStyleBackColor = False
        '
        'cmNote02Setup
        '
        Me.cmNote02Setup.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmNote02Setup.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmNote02Setup.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmNote02Setup.ForeColor = System.Drawing.Color.Black
        Me.cmNote02Setup.Location = New System.Drawing.Point(45, 90)
        Me.cmNote02Setup.Name = "cmNote02Setup"
        Me.cmNote02Setup.Size = New System.Drawing.Size(50, 23)
        Me.cmNote02Setup.TabIndex = 4
        Me.cmNote02Setup.Text = "Setup"
        Me.cmNote02Setup.UseVisualStyleBackColor = False
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.ForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.Label13.Location = New System.Drawing.Point(5, 120)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(39, 13)
        Me.Label13.TabIndex = 117
        Me.Label13.Text = "Note 3"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.ForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.Label12.Location = New System.Drawing.Point(5, 95)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(39, 13)
        Me.Label12.TabIndex = 116
        Me.Label12.Text = "Note 2"
        '
        'cmNote01Setup
        '
        Me.cmNote01Setup.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmNote01Setup.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmNote01Setup.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmNote01Setup.ForeColor = System.Drawing.Color.Black
        Me.cmNote01Setup.Location = New System.Drawing.Point(45, 65)
        Me.cmNote01Setup.Name = "cmNote01Setup"
        Me.cmNote01Setup.Size = New System.Drawing.Size(50, 23)
        Me.cmNote01Setup.TabIndex = 2
        Me.cmNote01Setup.Text = "Setup"
        Me.cmNote01Setup.UseVisualStyleBackColor = False
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.ForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.Label11.Location = New System.Drawing.Point(5, 70)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(39, 13)
        Me.Label11.TabIndex = 114
        Me.Label11.Text = "Note 1"
        '
        'cmNameSetup
        '
        Me.cmNameSetup.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmNameSetup.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmNameSetup.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmNameSetup.ForeColor = System.Drawing.Color.Black
        Me.cmNameSetup.Location = New System.Drawing.Point(45, 40)
        Me.cmNameSetup.Name = "cmNameSetup"
        Me.cmNameSetup.Size = New System.Drawing.Size(50, 23)
        Me.cmNameSetup.TabIndex = 1
        Me.cmNameSetup.Text = "Setup"
        Me.cmNameSetup.UseVisualStyleBackColor = False
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.ForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.Label10.Location = New System.Drawing.Point(5, 45)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(35, 13)
        Me.Label10.TabIndex = 111
        Me.Label10.Text = "Name"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.ForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.Label9.Location = New System.Drawing.Point(5, 20)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(33, 13)
        Me.Label9.TabIndex = 110
        Me.Label9.Text = "Rank"
        '
        'cmRankSetup
        '
        Me.cmRankSetup.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmRankSetup.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmRankSetup.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmRankSetup.ForeColor = System.Drawing.Color.Black
        Me.cmRankSetup.Location = New System.Drawing.Point(45, 15)
        Me.cmRankSetup.Name = "cmRankSetup"
        Me.cmRankSetup.Size = New System.Drawing.Size(50, 23)
        Me.cmRankSetup.TabIndex = 0
        Me.cmRankSetup.Text = "Setup"
        Me.cmRankSetup.UseVisualStyleBackColor = False
        '
        'cmSave
        '
        Me.cmSave.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmSave.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmSave.ForeColor = System.Drawing.Color.Black
        Me.cmSave.Location = New System.Drawing.Point(880, 145)
        Me.cmSave.Name = "cmSave"
        Me.cmSave.Size = New System.Drawing.Size(105, 23)
        Me.cmSave.TabIndex = 7
        Me.cmSave.Text = "Save Stats Image"
        Me.cmSave.UseVisualStyleBackColor = False
        '
        'gbLayout
        '
        Me.gbLayout.Controls.Add(Me.cmStatsModeHelp)
        Me.gbLayout.Controls.Add(Me.cmDefaults)
        Me.gbLayout.Controls.Add(Me.tbYSize)
        Me.gbLayout.Controls.Add(Me.tbXsize)
        Me.gbLayout.Controls.Add(Me.tbYoff)
        Me.gbLayout.Controls.Add(Me.tbXoff)
        Me.gbLayout.Controls.Add(Me.Label7)
        Me.gbLayout.Controls.Add(Me.cboNoteSpace)
        Me.gbLayout.Controls.Add(Me.chkGUIMode)
        Me.gbLayout.Controls.Add(Me.Label5)
        Me.gbLayout.Controls.Add(Me.cmSizeRefresh)
        Me.gbLayout.Controls.Add(Me.cboLayoutX)
        Me.gbLayout.Controls.Add(Me.Label3)
        Me.gbLayout.Controls.Add(Me.Label6)
        Me.gbLayout.Controls.Add(Me.cboLayoutY)
        Me.gbLayout.Controls.Add(Me.Label4)
        Me.gbLayout.Location = New System.Drawing.Point(335, 0)
        Me.gbLayout.Name = "gbLayout"
        Me.gbLayout.Size = New System.Drawing.Size(194, 195)
        Me.gbLayout.TabIndex = 76
        Me.gbLayout.TabStop = False
        Me.gbLayout.Text = "Stats Layout"
        '
        'cmStatsModeHelp
        '
        Me.cmStatsModeHelp.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmStatsModeHelp.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmStatsModeHelp.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmStatsModeHelp.ForeColor = System.Drawing.Color.Black
        Me.cmStatsModeHelp.Location = New System.Drawing.Point(67, 165)
        Me.cmStatsModeHelp.Name = "cmStatsModeHelp"
        Me.cmStatsModeHelp.Size = New System.Drawing.Size(56, 23)
        Me.cmStatsModeHelp.TabIndex = 26
        Me.cmStatsModeHelp.Text = "Help"
        Me.cmStatsModeHelp.UseVisualStyleBackColor = False
        '
        'cmDefaults
        '
        Me.cmDefaults.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmDefaults.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmDefaults.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmDefaults.ForeColor = System.Drawing.Color.Black
        Me.cmDefaults.Location = New System.Drawing.Point(7, 165)
        Me.cmDefaults.Name = "cmDefaults"
        Me.cmDefaults.Size = New System.Drawing.Size(58, 23)
        Me.cmDefaults.TabIndex = 25
        Me.cmDefaults.Text = "Defaults"
        Me.cmDefaults.UseVisualStyleBackColor = False
        '
        'tbYSize
        '
        Me.tbYSize.Location = New System.Drawing.Point(126, 15)
        Me.tbYSize.Name = "tbYSize"
        Me.tbYSize.Size = New System.Drawing.Size(60, 20)
        Me.tbYSize.TabIndex = 19
        Me.tbYSize.Text = "180"
        '
        'tbXsize
        '
        Me.tbXsize.Location = New System.Drawing.Point(60, 15)
        Me.tbXsize.Name = "tbXsize"
        Me.tbXsize.Size = New System.Drawing.Size(60, 20)
        Me.tbXsize.TabIndex = 18
        Me.tbXsize.Text = "990"
        '
        'tbYoff
        '
        Me.tbYoff.Location = New System.Drawing.Point(126, 40)
        Me.tbYoff.Name = "tbYoff"
        Me.tbYoff.Size = New System.Drawing.Size(60, 20)
        Me.tbYoff.TabIndex = 21
        '
        'tbXoff
        '
        Me.tbXoff.Location = New System.Drawing.Point(60, 40)
        Me.tbXoff.Name = "tbXoff"
        Me.tbXoff.Size = New System.Drawing.Size(60, 20)
        Me.tbXoff.TabIndex = 20
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.ForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.Label7.Location = New System.Drawing.Point(5, 45)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(52, 13)
        Me.Label7.TabIndex = 77
        Me.Label7.Text = "XY Offset"
        '
        'cboNoteSpace
        '
        Me.cboNoteSpace.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.cboNoteSpace.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboNoteSpace.ForeColor = System.Drawing.Color.White
        Me.cboNoteSpace.FormattingEnabled = True
        Me.cboNoteSpace.Location = New System.Drawing.Point(90, 115)
        Me.cboNoteSpace.Name = "cboNoteSpace"
        Me.cboNoteSpace.Size = New System.Drawing.Size(96, 21)
        Me.cboNoteSpace.TabIndex = 24
        '
        'chkGUIMode
        '
        Me.chkGUIMode.AutoSize = True
        Me.chkGUIMode.Location = New System.Drawing.Point(8, 145)
        Me.chkGUIMode.Name = "chkGUIMode"
        Me.chkGUIMode.Size = New System.Drawing.Size(108, 17)
        Me.chkGUIMode.TabIndex = 100
        Me.chkGUIMode.Text = "Toggle GUI Color"
        Me.chkGUIMode.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.ForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.Label5.Location = New System.Drawing.Point(5, 120)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(72, 13)
        Me.Label5.TabIndex = 73
        Me.Label5.Text = "Note Spacing"
        '
        'cmSizeRefresh
        '
        Me.cmSizeRefresh.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmSizeRefresh.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmSizeRefresh.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmSizeRefresh.ForeColor = System.Drawing.Color.Black
        Me.cmSizeRefresh.Location = New System.Drawing.Point(125, 165)
        Me.cmSizeRefresh.Name = "cmSizeRefresh"
        Me.cmSizeRefresh.Size = New System.Drawing.Size(58, 23)
        Me.cmSizeRefresh.TabIndex = 27
        Me.cmSizeRefresh.Text = "Refresh"
        Me.cmSizeRefresh.UseVisualStyleBackColor = False
        '
        'cboLayoutX
        '
        Me.cboLayoutX.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.cboLayoutX.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboLayoutX.ForeColor = System.Drawing.Color.White
        Me.cboLayoutX.FormattingEnabled = True
        Me.cboLayoutX.Location = New System.Drawing.Point(60, 65)
        Me.cboLayoutX.Name = "cboLayoutX"
        Me.cboLayoutX.Size = New System.Drawing.Size(126, 21)
        Me.cboLayoutX.TabIndex = 22
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.ForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.Label6.Location = New System.Drawing.Point(5, 70)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(49, 13)
        Me.Label6.TabIndex = 72
        Me.Label6.Text = "X Layout"
        '
        'pbStats
        '
        Me.pbStats.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.pbStats.Cursor = System.Windows.Forms.Cursors.Default
        Me.pbStats.Location = New System.Drawing.Point(10, 200)
        Me.pbStats.Name = "pbStats"
        Me.pbStats.Size = New System.Drawing.Size(990, 180)
        Me.pbStats.TabIndex = 77
        Me.pbStats.TabStop = False
        '
        'cmTestData
        '
        Me.cmTestData.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmTestData.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmTestData.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmTestData.ForeColor = System.Drawing.Color.Black
        Me.cmTestData.Location = New System.Drawing.Point(880, 95)
        Me.cmTestData.Name = "cmTestData"
        Me.cmTestData.Size = New System.Drawing.Size(105, 23)
        Me.cmTestData.TabIndex = 5
        Me.cmTestData.Text = "Show Test Data"
        Me.cmTestData.UseVisualStyleBackColor = False
        '
        'cmLastMatch
        '
        Me.cmLastMatch.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmLastMatch.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmLastMatch.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmLastMatch.ForeColor = System.Drawing.Color.Black
        Me.cmLastMatch.Location = New System.Drawing.Point(880, 70)
        Me.cmLastMatch.Name = "cmLastMatch"
        Me.cmLastMatch.Size = New System.Drawing.Size(105, 23)
        Me.cmLastMatch.TabIndex = 4
        Me.cmLastMatch.Text = "Last Match Stats"
        Me.cmLastMatch.UseVisualStyleBackColor = False
        '
        'gbFX
        '
        Me.gbFX.Controls.Add(Me.cmRID)
        Me.gbFX.Controls.Add(Me.chkFX)
        Me.gbFX.Controls.Add(Me.Label1)
        Me.gbFX.Controls.Add(Me.cmFXModeHelp)
        Me.gbFX.Controls.Add(Me.cboFXVar1)
        Me.gbFX.Controls.Add(Me.lbFXVar1)
        Me.gbFX.Controls.Add(Me.cboFxVar3)
        Me.gbFX.Controls.Add(Me.lbFXVar3)
        Me.gbFX.Controls.Add(Me.cboFxVar4)
        Me.gbFX.Controls.Add(Me.cmFX3DC)
        Me.gbFX.Controls.Add(Me.cboFXVar2)
        Me.gbFX.Controls.Add(Me.lbFXVar2)
        Me.gbFX.Controls.Add(Me.lbFXVar4)
        Me.gbFX.Controls.Add(Me.chkMismatch)
        Me.gbFX.Location = New System.Drawing.Point(535, 0)
        Me.gbFX.Name = "gbFX"
        Me.gbFX.Size = New System.Drawing.Size(145, 195)
        Me.gbFX.TabIndex = 80
        Me.gbFX.TabStop = False
        Me.gbFX.Text = "Stats FX"
        '
        'cmRID
        '
        Me.cmRID.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmRID.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmRID.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmRID.ForeColor = System.Drawing.Color.Black
        Me.cmRID.Location = New System.Drawing.Point(9, 165)
        Me.cmRID.Name = "cmRID"
        Me.cmRID.Size = New System.Drawing.Size(50, 23)
        Me.cmRID.TabIndex = 95
        Me.cmRID.Text = "RID"
        Me.cmRID.UseVisualStyleBackColor = False
        Me.cmRID.Visible = False
        '
        'chkFX
        '
        Me.chkFX.AutoSize = True
        Me.chkFX.Enabled = False
        Me.chkFX.Location = New System.Drawing.Point(66, 42)
        Me.chkFX.Name = "chkFX"
        Me.chkFX.Size = New System.Drawing.Size(56, 17)
        Me.chkFX.TabIndex = 88
        Me.chkFX.Text = "Active"
        Me.chkFX.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.Label1.Location = New System.Drawing.Point(6, 45)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(34, 13)
        Me.Label1.TabIndex = 89
        Me.Label1.Text = "Mode"
        '
        'cmFXModeHelp
        '
        Me.cmFXModeHelp.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmFXModeHelp.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmFXModeHelp.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmFXModeHelp.ForeColor = System.Drawing.Color.Black
        Me.cmFXModeHelp.Location = New System.Drawing.Point(65, 165)
        Me.cmFXModeHelp.Name = "cmFXModeHelp"
        Me.cmFXModeHelp.Size = New System.Drawing.Size(71, 23)
        Me.cmFXModeHelp.TabIndex = 93
        Me.cmFXModeHelp.Text = "Help"
        Me.cmFXModeHelp.UseVisualStyleBackColor = False
        '
        'cboFXVar1
        '
        Me.cboFXVar1.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.cboFXVar1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboFXVar1.ForeColor = System.Drawing.Color.White
        Me.cboFXVar1.FormattingEnabled = True
        Me.cboFXVar1.Location = New System.Drawing.Point(65, 15)
        Me.cboFXVar1.Name = "cboFXVar1"
        Me.cboFXVar1.Size = New System.Drawing.Size(71, 21)
        Me.cboFXVar1.TabIndex = 87
        '
        'lbFXVar1
        '
        Me.lbFXVar1.AutoSize = True
        Me.lbFXVar1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.lbFXVar1.Location = New System.Drawing.Point(6, 21)
        Me.lbFXVar1.Name = "lbFXVar1"
        Me.lbFXVar1.Size = New System.Drawing.Size(34, 13)
        Me.lbFXVar1.TabIndex = 86
        Me.lbFXVar1.Text = "Mode"
        '
        'cboFxVar3
        '
        Me.cboFxVar3.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.cboFxVar3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboFxVar3.Enabled = False
        Me.cboFxVar3.ForeColor = System.Drawing.Color.White
        Me.cboFxVar3.FormattingEnabled = True
        Me.cboFxVar3.Location = New System.Drawing.Point(65, 89)
        Me.cboFxVar3.Name = "cboFxVar3"
        Me.cboFxVar3.Size = New System.Drawing.Size(71, 21)
        Me.cboFxVar3.TabIndex = 91
        '
        'lbFXVar3
        '
        Me.lbFXVar3.AutoSize = True
        Me.lbFXVar3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.lbFXVar3.Location = New System.Drawing.Point(6, 91)
        Me.lbFXVar3.Name = "lbFXVar3"
        Me.lbFXVar3.Size = New System.Drawing.Size(13, 13)
        Me.lbFXVar3.TabIndex = 84
        Me.lbFXVar3.Text = "--"
        '
        'cboFxVar4
        '
        Me.cboFxVar4.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.cboFxVar4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboFxVar4.Enabled = False
        Me.cboFxVar4.ForeColor = System.Drawing.Color.White
        Me.cboFxVar4.FormattingEnabled = True
        Me.cboFxVar4.Location = New System.Drawing.Point(65, 113)
        Me.cboFxVar4.Name = "cboFxVar4"
        Me.cboFxVar4.Size = New System.Drawing.Size(71, 21)
        Me.cboFxVar4.TabIndex = 92
        '
        'cmFX3DC
        '
        Me.cmFX3DC.Enabled = False
        Me.cmFX3DC.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmFX3DC.Location = New System.Drawing.Point(65, 65)
        Me.cmFX3DC.Name = "cmFX3DC"
        Me.cmFX3DC.Size = New System.Drawing.Size(21, 21)
        Me.cmFX3DC.TabIndex = 89
        Me.cmFX3DC.Text = "1"
        Me.cmFX3DC.UseVisualStyleBackColor = True
        '
        'cboFXVar2
        '
        Me.cboFXVar2.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.cboFXVar2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboFXVar2.Enabled = False
        Me.cboFXVar2.ForeColor = System.Drawing.Color.White
        Me.cboFXVar2.FormattingEnabled = True
        Me.cboFXVar2.Location = New System.Drawing.Point(90, 65)
        Me.cboFXVar2.Name = "cboFXVar2"
        Me.cboFXVar2.Size = New System.Drawing.Size(46, 21)
        Me.cboFXVar2.TabIndex = 90
        '
        'lbFXVar2
        '
        Me.lbFXVar2.AutoSize = True
        Me.lbFXVar2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.lbFXVar2.Location = New System.Drawing.Point(6, 68)
        Me.lbFXVar2.Name = "lbFXVar2"
        Me.lbFXVar2.Size = New System.Drawing.Size(13, 13)
        Me.lbFXVar2.TabIndex = 66
        Me.lbFXVar2.Text = "--"
        '
        'lbFXVar4
        '
        Me.lbFXVar4.AutoSize = True
        Me.lbFXVar4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.lbFXVar4.Location = New System.Drawing.Point(6, 115)
        Me.lbFXVar4.Name = "lbFXVar4"
        Me.lbFXVar4.Size = New System.Drawing.Size(13, 13)
        Me.lbFXVar4.TabIndex = 70
        Me.lbFXVar4.Text = "--"
        '
        'chkMismatch
        '
        Me.chkMismatch.AutoSize = True
        Me.chkMismatch.Checked = True
        Me.chkMismatch.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkMismatch.Location = New System.Drawing.Point(9, 143)
        Me.chkMismatch.Name = "chkMismatch"
        Me.chkMismatch.Size = New System.Drawing.Size(102, 17)
        Me.chkMismatch.TabIndex = 11
        Me.chkMismatch.Text = "Show Bad Stats"
        Me.chkMismatch.UseVisualStyleBackColor = True
        Me.chkMismatch.Visible = False
        '
        'lbError1
        '
        Me.lbError1.BackColor = System.Drawing.Color.Silver
        Me.lbError1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lbError1.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbError1.ForeColor = System.Drawing.Color.White
        Me.lbError1.Location = New System.Drawing.Point(10, 70)
        Me.lbError1.Name = "lbError1"
        Me.lbError1.Size = New System.Drawing.Size(111, 18)
        Me.lbError1.TabIndex = 81
        Me.lbError1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lbError2
        '
        Me.lbError2.BackColor = System.Drawing.Color.Silver
        Me.lbError2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lbError2.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbError2.ForeColor = System.Drawing.Color.White
        Me.lbError2.Location = New System.Drawing.Point(10, 90)
        Me.lbError2.Name = "lbError2"
        Me.lbError2.Size = New System.Drawing.Size(111, 18)
        Me.lbError2.TabIndex = 82
        Me.lbError2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'chkTips
        '
        Me.chkTips.AutoSize = True
        Me.chkTips.Location = New System.Drawing.Point(991, 42)
        Me.chkTips.Name = "chkTips"
        Me.chkTips.Size = New System.Drawing.Size(100, 17)
        Me.chkTips.TabIndex = 10
        Me.chkTips.Text = "Show Tool Tips"
        Me.chkTips.UseVisualStyleBackColor = True
        '
        'pbNote1
        '
        Me.pbNote1.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.pbNote1.Cursor = System.Windows.Forms.Cursors.Default
        Me.pbNote1.Location = New System.Drawing.Point(11, 386)
        Me.pbNote1.Name = "pbNote1"
        Me.pbNote1.Size = New System.Drawing.Size(500, 60)
        Me.pbNote1.TabIndex = 91
        Me.pbNote1.TabStop = False
        '
        'timNote1
        '
        Me.timNote1.Enabled = True
        Me.timNote1.Interval = 30
        '
        'gbSound
        '
        Me.gbSound.Controls.Add(Me.cmAudioStop)
        Me.gbSound.Controls.Add(Me.lbVolume)
        Me.gbSound.Controls.Add(Me.scrVolume)
        Me.gbSound.Controls.Add(Me.cmSound15)
        Me.gbSound.Controls.Add(Me.cmSound14)
        Me.gbSound.Controls.Add(Me.cmSound13)
        Me.gbSound.Controls.Add(Me.cmSound12)
        Me.gbSound.Controls.Add(Me.cmSound11)
        Me.gbSound.Controls.Add(Me.lbSoundCurrent)
        Me.gbSound.Controls.Add(Me.cmSound10)
        Me.gbSound.Controls.Add(Me.cmSound09)
        Me.gbSound.Controls.Add(Me.cmSound08)
        Me.gbSound.Controls.Add(Me.cmSound07)
        Me.gbSound.Controls.Add(Me.cmSound06)
        Me.gbSound.Controls.Add(Me.cmSound05)
        Me.gbSound.Controls.Add(Me.cmSound04)
        Me.gbSound.Controls.Add(Me.cmSound03)
        Me.gbSound.Controls.Add(Me.cmSound02)
        Me.gbSound.Controls.Add(Me.cmSound01)
        Me.gbSound.Location = New System.Drawing.Point(685, 0)
        Me.gbSound.Name = "gbSound"
        Me.gbSound.Size = New System.Drawing.Size(190, 195)
        Me.gbSound.TabIndex = 94
        Me.gbSound.TabStop = False
        Me.gbSound.Text = "Sound"
        '
        'cmAudioStop
        '
        Me.cmAudioStop.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmAudioStop.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmAudioStop.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmAudioStop.ForeColor = System.Drawing.Color.Black
        Me.cmAudioStop.Location = New System.Drawing.Point(145, 170)
        Me.cmAudioStop.Name = "cmAudioStop"
        Me.cmAudioStop.Size = New System.Drawing.Size(35, 18)
        Me.cmAudioStop.TabIndex = 34
        Me.cmAudioStop.Text = "▀"
        Me.cmAudioStop.UseVisualStyleBackColor = False
        '
        'lbVolume
        '
        Me.lbVolume.BackColor = System.Drawing.Color.Silver
        Me.lbVolume.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lbVolume.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbVolume.ForeColor = System.Drawing.Color.Black
        Me.lbVolume.Location = New System.Drawing.Point(105, 170)
        Me.lbVolume.Name = "lbVolume"
        Me.lbVolume.Size = New System.Drawing.Size(35, 18)
        Me.lbVolume.TabIndex = 33
        Me.lbVolume.Text = "100"
        Me.lbVolume.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'scrVolume
        '
        Me.scrVolume.Location = New System.Drawing.Point(5, 170)
        Me.scrVolume.Maximum = 109
        Me.scrVolume.Name = "scrVolume"
        Me.scrVolume.Size = New System.Drawing.Size(95, 18)
        Me.scrVolume.TabIndex = 32
        Me.scrVolume.TabStop = True
        Me.scrVolume.Value = 100
        '
        'cmSound15
        '
        Me.cmSound15.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmSound15.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmSound15.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmSound15.ForeColor = System.Drawing.Color.Black
        Me.cmSound15.Location = New System.Drawing.Point(125, 115)
        Me.cmSound15.Name = "cmSound15"
        Me.cmSound15.Size = New System.Drawing.Size(55, 23)
        Me.cmSound15.TabIndex = 31
        Me.cmSound15.Text = "ALERT"
        Me.cmSound15.UseVisualStyleBackColor = False
        '
        'cmSound14
        '
        Me.cmSound14.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmSound14.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmSound14.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmSound14.ForeColor = System.Drawing.Color.Black
        Me.cmSound14.Location = New System.Drawing.Point(65, 115)
        Me.cmSound14.Name = "cmSound14"
        Me.cmSound14.Size = New System.Drawing.Size(55, 23)
        Me.cmSound14.TabIndex = 30
        Me.cmSound14.Text = "> 14"
        Me.cmSound14.UseVisualStyleBackColor = False
        '
        'cmSound13
        '
        Me.cmSound13.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmSound13.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmSound13.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmSound13.ForeColor = System.Drawing.Color.Black
        Me.cmSound13.Location = New System.Drawing.Point(5, 115)
        Me.cmSound13.Name = "cmSound13"
        Me.cmSound13.Size = New System.Drawing.Size(55, 23)
        Me.cmSound13.TabIndex = 29
        Me.cmSound13.Text = "> 13"
        Me.cmSound13.UseVisualStyleBackColor = False
        '
        'cmSound12
        '
        Me.cmSound12.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmSound12.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmSound12.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmSound12.ForeColor = System.Drawing.Color.Black
        Me.cmSound12.Location = New System.Drawing.Point(125, 90)
        Me.cmSound12.Name = "cmSound12"
        Me.cmSound12.Size = New System.Drawing.Size(55, 23)
        Me.cmSound12.TabIndex = 28
        Me.cmSound12.Text = "> 12"
        Me.cmSound12.UseVisualStyleBackColor = False
        '
        'cmSound11
        '
        Me.cmSound11.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmSound11.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmSound11.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmSound11.ForeColor = System.Drawing.Color.Black
        Me.cmSound11.Location = New System.Drawing.Point(65, 90)
        Me.cmSound11.Name = "cmSound11"
        Me.cmSound11.Size = New System.Drawing.Size(55, 23)
        Me.cmSound11.TabIndex = 27
        Me.cmSound11.Text = "> 11"
        Me.cmSound11.UseVisualStyleBackColor = False
        '
        'lbSoundCurrent
        '
        Me.lbSoundCurrent.BackColor = System.Drawing.Color.Silver
        Me.lbSoundCurrent.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lbSoundCurrent.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbSoundCurrent.ForeColor = System.Drawing.Color.Black
        Me.lbSoundCurrent.Location = New System.Drawing.Point(5, 150)
        Me.lbSoundCurrent.Name = "lbSoundCurrent"
        Me.lbSoundCurrent.Size = New System.Drawing.Size(175, 18)
        Me.lbSoundCurrent.TabIndex = 26
        Me.lbSoundCurrent.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'cmSound10
        '
        Me.cmSound10.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmSound10.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmSound10.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmSound10.ForeColor = System.Drawing.Color.Black
        Me.cmSound10.Location = New System.Drawing.Point(5, 90)
        Me.cmSound10.Name = "cmSound10"
        Me.cmSound10.Size = New System.Drawing.Size(55, 23)
        Me.cmSound10.TabIndex = 17
        Me.cmSound10.Text = "> 10"
        Me.cmSound10.UseVisualStyleBackColor = False
        '
        'cmSound09
        '
        Me.cmSound09.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmSound09.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmSound09.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmSound09.ForeColor = System.Drawing.Color.Black
        Me.cmSound09.Location = New System.Drawing.Point(125, 65)
        Me.cmSound09.Name = "cmSound09"
        Me.cmSound09.Size = New System.Drawing.Size(55, 23)
        Me.cmSound09.TabIndex = 16
        Me.cmSound09.Text = "> 09"
        Me.cmSound09.UseVisualStyleBackColor = False
        '
        'cmSound08
        '
        Me.cmSound08.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmSound08.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmSound08.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmSound08.ForeColor = System.Drawing.Color.Black
        Me.cmSound08.Location = New System.Drawing.Point(65, 65)
        Me.cmSound08.Name = "cmSound08"
        Me.cmSound08.Size = New System.Drawing.Size(55, 23)
        Me.cmSound08.TabIndex = 15
        Me.cmSound08.Text = "> 08"
        Me.cmSound08.UseVisualStyleBackColor = False
        '
        'cmSound07
        '
        Me.cmSound07.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmSound07.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmSound07.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmSound07.ForeColor = System.Drawing.Color.Black
        Me.cmSound07.Location = New System.Drawing.Point(5, 65)
        Me.cmSound07.Name = "cmSound07"
        Me.cmSound07.Size = New System.Drawing.Size(55, 23)
        Me.cmSound07.TabIndex = 14
        Me.cmSound07.Text = "> 07"
        Me.cmSound07.UseVisualStyleBackColor = False
        '
        'cmSound06
        '
        Me.cmSound06.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmSound06.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmSound06.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmSound06.ForeColor = System.Drawing.Color.Black
        Me.cmSound06.Location = New System.Drawing.Point(125, 40)
        Me.cmSound06.Name = "cmSound06"
        Me.cmSound06.Size = New System.Drawing.Size(55, 23)
        Me.cmSound06.TabIndex = 13
        Me.cmSound06.Text = "> 06"
        Me.cmSound06.UseVisualStyleBackColor = False
        '
        'cmSound05
        '
        Me.cmSound05.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmSound05.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmSound05.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmSound05.ForeColor = System.Drawing.Color.Black
        Me.cmSound05.Location = New System.Drawing.Point(65, 40)
        Me.cmSound05.Name = "cmSound05"
        Me.cmSound05.Size = New System.Drawing.Size(55, 23)
        Me.cmSound05.TabIndex = 12
        Me.cmSound05.Text = "> 05"
        Me.cmSound05.UseVisualStyleBackColor = False
        '
        'cmSound04
        '
        Me.cmSound04.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmSound04.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmSound04.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmSound04.ForeColor = System.Drawing.Color.Black
        Me.cmSound04.Location = New System.Drawing.Point(5, 40)
        Me.cmSound04.Name = "cmSound04"
        Me.cmSound04.Size = New System.Drawing.Size(55, 23)
        Me.cmSound04.TabIndex = 11
        Me.cmSound04.Text = "> 04"
        Me.cmSound04.UseVisualStyleBackColor = False
        '
        'cmSound03
        '
        Me.cmSound03.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmSound03.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmSound03.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmSound03.ForeColor = System.Drawing.Color.Black
        Me.cmSound03.Location = New System.Drawing.Point(125, 15)
        Me.cmSound03.Name = "cmSound03"
        Me.cmSound03.Size = New System.Drawing.Size(55, 23)
        Me.cmSound03.TabIndex = 10
        Me.cmSound03.Text = "> 03"
        Me.cmSound03.UseVisualStyleBackColor = False
        '
        'cmSound02
        '
        Me.cmSound02.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmSound02.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmSound02.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmSound02.ForeColor = System.Drawing.Color.Black
        Me.cmSound02.Location = New System.Drawing.Point(65, 15)
        Me.cmSound02.Name = "cmSound02"
        Me.cmSound02.Size = New System.Drawing.Size(55, 23)
        Me.cmSound02.TabIndex = 9
        Me.cmSound02.Text = "> 02"
        Me.cmSound02.UseVisualStyleBackColor = False
        '
        'cmSound01
        '
        Me.cmSound01.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmSound01.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmSound01.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmSound01.ForeColor = System.Drawing.Color.Black
        Me.cmSound01.Location = New System.Drawing.Point(5, 15)
        Me.cmSound01.Name = "cmSound01"
        Me.cmSound01.Size = New System.Drawing.Size(55, 23)
        Me.cmSound01.TabIndex = 8
        Me.cmSound01.Text = "> 01"
        Me.cmSound01.UseVisualStyleBackColor = False
        '
        'pbNote3
        '
        Me.pbNote3.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.pbNote3.Cursor = System.Windows.Forms.Cursors.Default
        Me.pbNote3.Location = New System.Drawing.Point(11, 516)
        Me.pbNote3.Name = "pbNote3"
        Me.pbNote3.Size = New System.Drawing.Size(500, 60)
        Me.pbNote3.TabIndex = 96
        Me.pbNote3.TabStop = False
        '
        'pbNote4
        '
        Me.pbNote4.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.pbNote4.Cursor = System.Windows.Forms.Cursors.Default
        Me.pbNote4.Location = New System.Drawing.Point(11, 581)
        Me.pbNote4.Name = "pbNote4"
        Me.pbNote4.Size = New System.Drawing.Size(500, 60)
        Me.pbNote4.TabIndex = 97
        Me.pbNote4.TabStop = False
        '
        'pbNote2
        '
        Me.pbNote2.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.pbNote2.Cursor = System.Windows.Forms.Cursors.Default
        Me.pbNote2.Location = New System.Drawing.Point(11, 451)
        Me.pbNote2.Name = "pbNote2"
        Me.pbNote2.Size = New System.Drawing.Size(500, 60)
        Me.pbNote2.TabIndex = 98
        Me.pbNote2.TabStop = False
        '
        'chkPosition
        '
        Me.chkPosition.AutoSize = True
        Me.chkPosition.Location = New System.Drawing.Point(991, 59)
        Me.chkPosition.Name = "chkPosition"
        Me.chkPosition.Size = New System.Drawing.Size(114, 17)
        Me.chkPosition.TabIndex = 12
        Me.chkPosition.Text = "Save Window Pos"
        Me.chkPosition.UseVisualStyleBackColor = True
        '
        'tsmPlayer
        '
        Me.tsmPlayer.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsmPlayer_Relic, Me.tsmPlayer_OrgAT, Me.tsmPlayer_OrgFaction, Me.tsmPlayer_OrgPlayercard, Me.tsmPlayer_Google, Me.tsmPlayer_Steam})
        Me.tsmPlayer.Name = "tsmPlayer"
        Me.tsmPlayer.Size = New System.Drawing.Size(290, 136)
        '
        'tsmPlayer_Relic
        '
        Me.tsmPlayer_Relic.Image = CType(resources.GetObject("tsmPlayer_Relic.Image"), System.Drawing.Image)
        Me.tsmPlayer_Relic.Name = "tsmPlayer_Relic"
        Me.tsmPlayer_Relic.Size = New System.Drawing.Size(289, 22)
        Me.tsmPlayer_Relic.Text = "&1 - Open Relic Stats webpage"
        '
        'tsmPlayer_OrgAT
        '
        Me.tsmPlayer_OrgAT.Image = CType(resources.GetObject("tsmPlayer_OrgAT.Image"), System.Drawing.Image)
        Me.tsmPlayer_OrgAT.Name = "tsmPlayer_OrgAT"
        Me.tsmPlayer_OrgAT.Size = New System.Drawing.Size(289, 22)
        Me.tsmPlayer_OrgAT.Text = "&2 - Open Coh2.Org AT stats webpage"
        '
        'tsmPlayer_OrgFaction
        '
        Me.tsmPlayer_OrgFaction.Image = CType(resources.GetObject("tsmPlayer_OrgFaction.Image"), System.Drawing.Image)
        Me.tsmPlayer_OrgFaction.Name = "tsmPlayer_OrgFaction"
        Me.tsmPlayer_OrgFaction.Size = New System.Drawing.Size(289, 22)
        Me.tsmPlayer_OrgFaction.Text = "3 - Open Coh2.Org Faction webpage"
        '
        'tsmPlayer_OrgPlayercard
        '
        Me.tsmPlayer_OrgPlayercard.Image = CType(resources.GetObject("tsmPlayer_OrgPlayercard.Image"), System.Drawing.Image)
        Me.tsmPlayer_OrgPlayercard.Name = "tsmPlayer_OrgPlayercard"
        Me.tsmPlayer_OrgPlayercard.Size = New System.Drawing.Size(289, 22)
        Me.tsmPlayer_OrgPlayercard.Text = "&4 - Open Coh2.Org Playercard webpage"
        '
        'tsmPlayer_Google
        '
        Me.tsmPlayer_Google.Image = CType(resources.GetObject("tsmPlayer_Google.Image"), System.Drawing.Image)
        Me.tsmPlayer_Google.Name = "tsmPlayer_Google"
        Me.tsmPlayer_Google.Size = New System.Drawing.Size(289, 22)
        Me.tsmPlayer_Google.Text = "&5 - Send player name to Google Translate"
        '
        'tsmPlayer_Steam
        '
        Me.tsmPlayer_Steam.Image = CType(resources.GetObject("tsmPlayer_Steam.Image"), System.Drawing.Image)
        Me.tsmPlayer_Steam.Name = "tsmPlayer_Steam"
        Me.tsmPlayer_Steam.Size = New System.Drawing.Size(289, 22)
        Me.tsmPlayer_Steam.Text = "&6 - Open player Steam page"
        '
        'chkPopUp
        '
        Me.chkPopUp.AutoSize = True
        Me.chkPopUp.Location = New System.Drawing.Point(1029, 201)
        Me.chkPopUp.Name = "chkPopUp"
        Me.chkPopUp.Size = New System.Drawing.Size(106, 17)
        Me.chkPopUp.TabIndex = 13
        Me.chkPopUp.Text = "Use Stats Popup"
        Me.chkPopUp.UseVisualStyleBackColor = True
        Me.chkPopUp.Visible = False
        '
        'tsmAudio
        '
        Me.tsmAudio.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsmSetVolTo100, Me.tsmSetVolTo90, Me.tsmSetVolTo80, Me.tsmSetVolTo70, Me.tsmSetVolTo60, Me.tsmSetVolTo50, Me.tsmSetVolTo40, Me.tsmSetVolTo30, Me.tsmSetVolTo20, Me.tsmSetVolTo10, Me.ToolStripMenuItem1, Me.tsmSelectFile})
        Me.tsmAudio.Name = "tsmAudio"
        Me.tsmAudio.Size = New System.Drawing.Size(216, 252)
        '
        'tsmSetVolTo100
        '
        Me.tsmSetVolTo100.Name = "tsmSetVolTo100"
        Me.tsmSetVolTo100.Size = New System.Drawing.Size(215, 22)
        Me.tsmSetVolTo100.Text = "&0 - Set Vol to 100%"
        '
        'tsmSetVolTo90
        '
        Me.tsmSetVolTo90.Name = "tsmSetVolTo90"
        Me.tsmSetVolTo90.Size = New System.Drawing.Size(215, 22)
        Me.tsmSetVolTo90.Text = "9 - Set Vol to 90%"
        '
        'tsmSetVolTo80
        '
        Me.tsmSetVolTo80.Name = "tsmSetVolTo80"
        Me.tsmSetVolTo80.Size = New System.Drawing.Size(215, 22)
        Me.tsmSetVolTo80.Text = "8 - Set Vol to 80%"
        '
        'tsmSetVolTo70
        '
        Me.tsmSetVolTo70.Name = "tsmSetVolTo70"
        Me.tsmSetVolTo70.Size = New System.Drawing.Size(215, 22)
        Me.tsmSetVolTo70.Text = "7 - Set Vol to 70%"
        '
        'tsmSetVolTo60
        '
        Me.tsmSetVolTo60.Name = "tsmSetVolTo60"
        Me.tsmSetVolTo60.Size = New System.Drawing.Size(215, 22)
        Me.tsmSetVolTo60.Text = "6 - Set Vol to 60%"
        '
        'tsmSetVolTo50
        '
        Me.tsmSetVolTo50.Name = "tsmSetVolTo50"
        Me.tsmSetVolTo50.Size = New System.Drawing.Size(215, 22)
        Me.tsmSetVolTo50.Text = "5 - Set Vol to 50%"
        '
        'tsmSetVolTo40
        '
        Me.tsmSetVolTo40.Name = "tsmSetVolTo40"
        Me.tsmSetVolTo40.Size = New System.Drawing.Size(215, 22)
        Me.tsmSetVolTo40.Text = "4 - Set Vol to 40%"
        '
        'tsmSetVolTo30
        '
        Me.tsmSetVolTo30.Name = "tsmSetVolTo30"
        Me.tsmSetVolTo30.Size = New System.Drawing.Size(215, 22)
        Me.tsmSetVolTo30.Text = "3 - Set Vol to 30%"
        '
        'tsmSetVolTo20
        '
        Me.tsmSetVolTo20.Name = "tsmSetVolTo20"
        Me.tsmSetVolTo20.Size = New System.Drawing.Size(215, 22)
        Me.tsmSetVolTo20.Text = "2 - Set Vol to 20%"
        '
        'tsmSetVolTo10
        '
        Me.tsmSetVolTo10.Name = "tsmSetVolTo10"
        Me.tsmSetVolTo10.Size = New System.Drawing.Size(215, 22)
        Me.tsmSetVolTo10.Text = "1 - Set Vol to 10%"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(212, 6)
        '
        'tsmSelectFile
        '
        Me.tsmSelectFile.Name = "tsmSelectFile"
        Me.tsmSelectFile.Size = New System.Drawing.Size(215, 22)
        Me.tsmSelectFile.Text = "F - Select Audio file to play"
        '
        'chkSmoothAni
        '
        Me.chkSmoothAni.AutoSize = True
        Me.chkSmoothAni.Location = New System.Drawing.Point(991, 93)
        Me.chkSmoothAni.Name = "chkSmoothAni"
        Me.chkSmoothAni.Size = New System.Drawing.Size(111, 17)
        Me.chkSmoothAni.TabIndex = 14
        Me.chkSmoothAni.Text = "Smooth Animation"
        Me.chkSmoothAni.UseVisualStyleBackColor = True
        '
        'chkFoundSound
        '
        Me.chkFoundSound.AutoSize = True
        Me.chkFoundSound.Location = New System.Drawing.Point(991, 110)
        Me.chkFoundSound.Name = "chkFoundSound"
        Me.chkFoundSound.Size = New System.Drawing.Size(113, 17)
        Me.chkFoundSound.TabIndex = 101
        Me.chkFoundSound.Text = "Match Found Alert"
        Me.chkFoundSound.UseVisualStyleBackColor = True
        '
        'lbTime
        '
        Me.lbTime.AutoSize = True
        Me.lbTime.ForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.lbTime.Location = New System.Drawing.Point(8, 170)
        Me.lbTime.Name = "lbTime"
        Me.lbTime.Size = New System.Drawing.Size(56, 13)
        Me.lbTime.TabIndex = 102
        Me.lbTime.Text = "Time (sec)"
        '
        'cboDelay
        '
        Me.cboDelay.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.cboDelay.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboDelay.ForeColor = System.Drawing.Color.White
        Me.cboDelay.FormattingEnabled = True
        Me.cboDelay.Location = New System.Drawing.Point(70, 165)
        Me.cboDelay.Name = "cboDelay"
        Me.cboDelay.Size = New System.Drawing.Size(51, 21)
        Me.cboDelay.TabIndex = 103
        '
        'chkHideMissing
        '
        Me.chkHideMissing.AutoSize = True
        Me.chkHideMissing.Location = New System.Drawing.Point(991, 127)
        Me.chkHideMissing.Name = "chkHideMissing"
        Me.chkHideMissing.Size = New System.Drawing.Size(123, 17)
        Me.chkHideMissing.TabIndex = 104
        Me.chkHideMissing.Text = "Hide Missing Players"
        Me.chkHideMissing.UseVisualStyleBackColor = True
        '
        'chkShowELO
        '
        Me.chkShowELO.AutoSize = True
        Me.chkShowELO.Location = New System.Drawing.Point(991, 144)
        Me.chkShowELO.Name = "chkShowELO"
        Me.chkShowELO.Size = New System.Drawing.Size(99, 17)
        Me.chkShowELO.TabIndex = 105
        Me.chkShowELO.Text = "Cycle ELO Vals"
        Me.chkShowELO.UseVisualStyleBackColor = True
        '
        'timELOCycle
        '
        Me.timELOCycle.Enabled = True
        Me.timELOCycle.Interval = 3000
        '
        'scrStats
        '
        Me.scrStats.LargeChange = 90
        Me.scrStats.Location = New System.Drawing.Point(1003, 201)
        Me.scrStats.Name = "scrStats"
        Me.scrStats.Size = New System.Drawing.Size(23, 178)
        Me.scrStats.TabIndex = 107
        '
        'chkSpeech
        '
        Me.chkSpeech.AutoSize = True
        Me.chkSpeech.Location = New System.Drawing.Point(991, 161)
        Me.chkSpeech.Name = "chkSpeech"
        Me.chkSpeech.Size = New System.Drawing.Size(116, 17)
        Me.chkSpeech.TabIndex = 108
        Me.chkSpeech.Text = "Read Ranks Aloud"
        Me.chkSpeech.UseVisualStyleBackColor = True
        '
        'chkGetTeams
        '
        Me.chkGetTeams.AutoSize = True
        Me.chkGetTeams.Location = New System.Drawing.Point(991, 178)
        Me.chkGetTeams.Name = "chkGetTeams"
        Me.chkGetTeams.Size = New System.Drawing.Size(110, 17)
        Me.chkGetTeams.TabIndex = 109
        Me.chkGetTeams.Text = "Find Team Ranks"
        Me.chkGetTeams.UseVisualStyleBackColor = True
        '
        'lstLog
        '
        Me.lstLog.FormattingEnabled = True
        Me.lstLog.Location = New System.Drawing.Point(790, 393)
        Me.lstLog.Name = "lstLog"
        Me.lstLog.Size = New System.Drawing.Size(288, 277)
        Me.lstLog.TabIndex = 110
        Me.lstLog.Visible = False
        '
        'cmErrLog
        '
        Me.cmErrLog.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmErrLog.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.cmErrLog.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmErrLog.ForeColor = System.Drawing.Color.Black
        Me.cmErrLog.Location = New System.Drawing.Point(880, 170)
        Me.cmErrLog.Name = "cmErrLog"
        Me.cmErrLog.Size = New System.Drawing.Size(105, 23)
        Me.cmErrLog.TabIndex = 111
        Me.cmErrLog.Text = "View Web Log"
        Me.cmErrLog.UseVisualStyleBackColor = False
        '
        'chkCountry
        '
        Me.chkCountry.AutoSize = True
        Me.chkCountry.Location = New System.Drawing.Point(991, 76)
        Me.chkCountry.Name = "chkCountry"
        Me.chkCountry.Size = New System.Drawing.Size(120, 17)
        Me.chkCountry.TabIndex = 112
        Me.chkCountry.Text = "Show Country Flags"
        Me.chkCountry.UseVisualStyleBackColor = True
        '
        'SS1
        '
        Me.SS1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SS1_Version, Me.SS1_Sep1, Me.SS1_Filename, Me.SS1_Sep2, Me.SS1_Time, Me.SS1_Sep3})
        Me.SS1.Location = New System.Drawing.Point(0, 638)
        Me.SS1.Name = "SS1"
        Me.SS1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional
        Me.SS1.Size = New System.Drawing.Size(1130, 22)
        Me.SS1.TabIndex = 113
        '
        'SS1_Version
        '
        Me.SS1_Version.AutoSize = False
        Me.SS1_Version.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken
        Me.SS1_Version.Name = "SS1_Version"
        Me.SS1_Version.Size = New System.Drawing.Size(35, 17)
        Me.SS1_Version.Text = "v4.50"
        Me.SS1_Version.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'SS1_Sep1
        '
        Me.SS1_Sep1.AutoSize = False
        Me.SS1_Sep1.Name = "SS1_Sep1"
        Me.SS1_Sep1.Size = New System.Drawing.Size(10, 17)
        Me.SS1_Sep1.Text = "|"
        '
        'SS1_Filename
        '
        Me.SS1_Filename.AutoSize = False
        Me.SS1_Filename.BorderStyle = System.Windows.Forms.Border3DStyle.RaisedOuter
        Me.SS1_Filename.Name = "SS1_Filename"
        Me.SS1_Filename.Size = New System.Drawing.Size(250, 17)
        Me.SS1_Filename.Text = "default.mcs"
        Me.SS1_Filename.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'SS1_Sep2
        '
        Me.SS1_Sep2.AutoSize = False
        Me.SS1_Sep2.Name = "SS1_Sep2"
        Me.SS1_Sep2.Size = New System.Drawing.Size(10, 17)
        Me.SS1_Sep2.Text = "|"
        '
        'SS1_Time
        '
        Me.SS1_Time.AutoSize = False
        Me.SS1_Time.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken
        Me.SS1_Time.Name = "SS1_Time"
        Me.SS1_Time.Size = New System.Drawing.Size(180, 17)
        Me.SS1_Time.Text = "Match found:"
        Me.SS1_Time.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'SS1_Sep3
        '
        Me.SS1_Sep3.AutoSize = False
        Me.SS1_Sep3.Name = "SS1_Sep3"
        Me.SS1_Sep3.Size = New System.Drawing.Size(10, 17)
        Me.SS1_Sep3.Text = "|"
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1130, 660)
        Me.Controls.Add(Me.SS1)
        Me.Controls.Add(Me.chkCountry)
        Me.Controls.Add(Me.cmErrLog)
        Me.Controls.Add(Me.lstLog)
        Me.Controls.Add(Me.chkGetTeams)
        Me.Controls.Add(Me.chkSpeech)
        Me.Controls.Add(Me.scrStats)
        Me.Controls.Add(Me.chkShowELO)
        Me.Controls.Add(Me.chkHideMissing)
        Me.Controls.Add(Me.cboDelay)
        Me.Controls.Add(Me.lbTime)
        Me.Controls.Add(Me.chkFoundSound)
        Me.Controls.Add(Me.chkSmoothAni)
        Me.Controls.Add(Me.chkPopUp)
        Me.Controls.Add(Me.chkPosition)
        Me.Controls.Add(Me.cmCopy)
        Me.Controls.Add(Me.cmSave)
        Me.Controls.Add(Me.pbNote2)
        Me.Controls.Add(Me.pbNote4)
        Me.Controls.Add(Me.pbNote3)
        Me.Controls.Add(Me.gbSound)
        Me.Controls.Add(Me.pbNote1)
        Me.Controls.Add(Me.chkTips)
        Me.Controls.Add(Me.lbError2)
        Me.Controls.Add(Me.lbError1)
        Me.Controls.Add(Me.gbFX)
        Me.Controls.Add(Me.cmLastMatch)
        Me.Controls.Add(Me.cmTestData)
        Me.Controls.Add(Me.pbStats)
        Me.Controls.Add(Me.gbLayout)
        Me.Controls.Add(Me.gbRank)
        Me.Controls.Add(Me.cmAbout)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.cmScanLog)
        Me.Controls.Add(Me.cmFindLog)
        Me.Controls.Add(Me.lbSteam08)
        Me.Controls.Add(Me.lbSteam07)
        Me.Controls.Add(Me.lbSteam06)
        Me.Controls.Add(Me.lbSteam05)
        Me.Controls.Add(Me.lbSteam04)
        Me.Controls.Add(Me.lbSteam03)
        Me.Controls.Add(Me.lbSteam02)
        Me.Controls.Add(Me.lbSteam01)
        Me.Controls.Add(Me.pbFact05)
        Me.Controls.Add(Me.pbFact04)
        Me.Controls.Add(Me.pbFact03)
        Me.Controls.Add(Me.pbFact02)
        Me.Controls.Add(Me.pbFact01)
        Me.Controls.Add(Me.lbStatus)
        Me.Controls.Add(Me.cmCheckLog)
        Me.DoubleBuffered = True
        Me.ForeColor = System.Drawing.Color.Black
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmMain"
        Me.Text = "MakoCelo"
        CType(Me.pbFact01, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbFact02, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbFact03, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbFact04, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbFact05, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gbRank.ResumeLayout(False)
        Me.gbRank.PerformLayout()
        Me.gbLayout.ResumeLayout(False)
        Me.gbLayout.PerformLayout()
        CType(Me.pbStats, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gbFX.ResumeLayout(False)
        Me.gbFX.PerformLayout()
        CType(Me.pbNote1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gbSound.ResumeLayout(False)
        CType(Me.pbNote3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbNote4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbNote2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tsmPlayer.ResumeLayout(False)
        Me.tsmAudio.ResumeLayout(False)
        Me.SS1.ResumeLayout(False)
        Me.SS1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents cmCheckLog As System.Windows.Forms.Button
    Friend WithEvents lbStatus As System.Windows.Forms.Label
    Friend WithEvents pbFact01 As System.Windows.Forms.PictureBox
    Friend WithEvents pbFact02 As System.Windows.Forms.PictureBox
    Friend WithEvents pbFact03 As System.Windows.Forms.PictureBox
    Friend WithEvents pbFact04 As System.Windows.Forms.PictureBox
    Friend WithEvents pbFact05 As System.Windows.Forms.PictureBox
    Friend WithEvents lbSteam01 As System.Windows.Forms.Label
    Friend WithEvents lbSteam02 As System.Windows.Forms.Label
    Friend WithEvents lbSteam03 As System.Windows.Forms.Label
    Friend WithEvents lbSteam04 As System.Windows.Forms.Label
    Friend WithEvents lbSteam05 As System.Windows.Forms.Label
    Friend WithEvents lbSteam06 As System.Windows.Forms.Label
    Friend WithEvents lbSteam07 As System.Windows.Forms.Label
    Friend WithEvents lbSteam08 As System.Windows.Forms.Label
    Friend WithEvents ColorDialog1 As System.Windows.Forms.ColorDialog
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents cmFindLog As System.Windows.Forms.Button
    Friend WithEvents cmScanLog As System.Windows.Forms.Button
    Friend WithEvents cmCopy As System.Windows.Forms.Button
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents FontDialog1 As System.Windows.Forms.FontDialog
    Friend WithEvents cmAbout As System.Windows.Forms.Button
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents cboLayoutY As System.Windows.Forms.ComboBox
    Friend WithEvents gbRank As System.Windows.Forms.GroupBox
    Friend WithEvents gbLayout As System.Windows.Forms.GroupBox
    Friend WithEvents cboLayoutX As System.Windows.Forms.ComboBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents cmSizeRefresh As System.Windows.Forms.Button
    Friend WithEvents pbStats As System.Windows.Forms.PictureBox
    Friend WithEvents cmTestData As System.Windows.Forms.Button
    Friend WithEvents cmLastMatch As System.Windows.Forms.Button
    Friend WithEvents gbFX As System.Windows.Forms.GroupBox
    Friend WithEvents lbFXVar2 As System.Windows.Forms.Label
    Friend WithEvents lbFXVar4 As System.Windows.Forms.Label
    Friend WithEvents cmFX3DC As System.Windows.Forms.Button
    Friend WithEvents cboFXVar2 As System.Windows.Forms.ComboBox
    Friend WithEvents cboFxVar4 As System.Windows.Forms.ComboBox
    Friend WithEvents cboFxVar3 As System.Windows.Forms.ComboBox
    Friend WithEvents lbFXVar3 As System.Windows.Forms.Label
    Friend WithEvents cboFXVar1 As System.Windows.Forms.ComboBox
    Friend WithEvents lbFXVar1 As System.Windows.Forms.Label
    Friend WithEvents cmFXModeHelp As Button
    Friend WithEvents lbError1 As Label
    Friend WithEvents lbError2 As Label
    Friend WithEvents chkFX As CheckBox
    Friend WithEvents Label1 As Label
    Friend WithEvents cmSave As Button
    Friend WithEvents SaveFileDialog1 As SaveFileDialog
    Friend WithEvents chkMismatch As CheckBox
    Friend WithEvents ToolTip1 As ToolTip
    Friend WithEvents chkTips As CheckBox
    Friend WithEvents pbNote1 As PictureBox
    Friend WithEvents timNote1 As Timer
    Friend WithEvents gbSound As GroupBox
    Friend WithEvents cmSound02 As Button
    Friend WithEvents cmSound01 As Button
    Friend WithEvents lbSoundCurrent As Label
    Friend WithEvents cmSound10 As Button
    Friend WithEvents cmSound09 As Button
    Friend WithEvents cmSound08 As Button
    Friend WithEvents cmSound07 As Button
    Friend WithEvents cmSound06 As Button
    Friend WithEvents cmSound05 As Button
    Friend WithEvents cmSound04 As Button
    Friend WithEvents cmSound03 As Button
    Friend WithEvents cmRankSetup As Button
    Friend WithEvents cmNote3 As Button
    Friend WithEvents cmNote2 As Button
    Friend WithEvents cmNote1 As Button
    Friend WithEvents cmNote03Setup As Button
    Friend WithEvents cmNote02Setup As Button
    Friend WithEvents Label13 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents cmNote01Setup As Button
    Friend WithEvents Label11 As Label
    Friend WithEvents cmNameSetup As Button
    Friend WithEvents Label10 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents pbNote3 As PictureBox
    Friend WithEvents pbNote4 As PictureBox
    Friend WithEvents pbNote2 As PictureBox
    Friend WithEvents cmNote4 As Button
    Friend WithEvents cmNote04Setup As Button
    Friend WithEvents Label14 As Label
    Friend WithEvents cmNote04_Play As Button
    Friend WithEvents cmNote03_Play As Button
    Friend WithEvents cmNote02_Play As Button
    Friend WithEvents cmNote01_Play As Button
    Friend WithEvents cmSound15 As Button
    Friend WithEvents cmSound14 As Button
    Friend WithEvents cmSound13 As Button
    Friend WithEvents cmSound12 As Button
    Friend WithEvents cmSound11 As Button
    Friend WithEvents scrVolume As HScrollBar
    Friend WithEvents lbVolume As Label
    Friend WithEvents cmNote_PlayAll As Button
    Friend WithEvents cboNoteSpace As ComboBox
    Friend WithEvents Label5 As Label
    Friend WithEvents chkPosition As CheckBox
    Friend WithEvents tsmPlayer As ContextMenuStrip
    Friend WithEvents tsmPlayer_Relic As ToolStripMenuItem
    Friend WithEvents tsmPlayer_OrgAT As ToolStripMenuItem
    Friend WithEvents chkPopUp As CheckBox
    Friend WithEvents tsmPlayer_OrgFaction As ToolStripMenuItem
    Friend WithEvents tsmPlayer_OrgPlayercard As ToolStripMenuItem
    Friend WithEvents tsmPlayer_Google As ToolStripMenuItem
    Friend WithEvents tsmAudio As ContextMenuStrip
    Friend WithEvents tsmSetVolTo100 As ToolStripMenuItem
    Friend WithEvents tsmSetVolTo90 As ToolStripMenuItem
    Friend WithEvents tsmSetVolTo80 As ToolStripMenuItem
    Friend WithEvents tsmSetVolTo70 As ToolStripMenuItem
    Friend WithEvents tsmSetVolTo60 As ToolStripMenuItem
    Friend WithEvents tsmSetVolTo50 As ToolStripMenuItem
    Friend WithEvents tsmSetVolTo40 As ToolStripMenuItem
    Friend WithEvents tsmSetVolTo30 As ToolStripMenuItem
    Friend WithEvents tsmSetVolTo20 As ToolStripMenuItem
    Friend WithEvents tsmSetVolTo10 As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem1 As ToolStripSeparator
    Friend WithEvents tsmSelectFile As ToolStripMenuItem
    Friend WithEvents cmAudioStop As Button
    Friend WithEvents Label7 As Label
    Friend WithEvents tbYoff As TextBox
    Friend WithEvents tbXoff As TextBox
    Friend WithEvents tbYSize As TextBox
    Friend WithEvents tbXsize As TextBox
    Friend WithEvents cmDefaults As Button
    Friend WithEvents cmStatsModeHelp As Button
    Friend WithEvents chkSmoothAni As CheckBox
    Friend WithEvents cmSetupLoad As Button
    Friend WithEvents cmSetupSave As Button
    Friend WithEvents chkGUIMode As CheckBox
    Friend WithEvents chkFoundSound As CheckBox
    Friend WithEvents lbTime As Label
    Friend WithEvents cboDelay As ComboBox
    Friend WithEvents chkHideMissing As CheckBox
    Friend WithEvents tsmPlayer_Steam As ToolStripMenuItem
    Friend WithEvents cmELO As Button
    Friend WithEvents chkShowELO As CheckBox
    Friend WithEvents cmRID As Button
    Friend WithEvents timELOCycle As Timer
    Friend WithEvents scrStats As VScrollBar
    Friend WithEvents chkSpeech As CheckBox
    Friend WithEvents chkGetTeams As CheckBox
    Friend WithEvents lstLog As ListBox
    Friend WithEvents cmErrLog As Button
    Friend WithEvents chkCountry As CheckBox
    Friend WithEvents SS1 As StatusStrip
    Friend WithEvents SS1_Version As ToolStripStatusLabel
    Friend WithEvents SS1_Filename As ToolStripStatusLabel
    Friend WithEvents SS1_Sep1 As ToolStripStatusLabel
    Friend WithEvents SS1_Sep2 As ToolStripStatusLabel
    Friend WithEvents SS1_Time As ToolStripStatusLabel
    Friend WithEvents SS1_Sep3 As ToolStripStatusLabel
End Class
